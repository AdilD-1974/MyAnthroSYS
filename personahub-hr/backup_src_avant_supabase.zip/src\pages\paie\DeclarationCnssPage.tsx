/**
 * DeclarationCnssPage – Déclaration CNSS en 4 étapes
 * RG-DECL-CNSS-01 : Import du fichier préétabli (CSV/Excel ou XML)
 * RG-DECL-CNSS-02 : Alimentation automatique des salaires et jours, mise à jour statut
 * RG-DECL-CNSS-03 : Contrôle CIN, détection entrants et collaborateurs sans N°CNSS
 * RG-DECL-CNSS-04 : Génération du fichier XML Damancom
 */
import React, { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Shield, FileText, Upload, CheckCircle2, AlertTriangle, Download,
  Loader2, ArrowRight, ArrowLeft, Users, RefreshCw, Search, Eye, X,
  FileUp, Calendar, Info, Pencil, Save, Settings
} from "lucide-react";

const MOIS_LABELS = [
  "", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
  "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"
];

interface DeclarationLigne {
  id?: string;
  collaborateur_id?: string;
  matricule: string;
  cin: string;
  num_cnss: string;
  nom: string;
  prenom: string;
  salaire_brut: number;
  nombre_jours: number;
  statut_salarie: string;
  observations: string;
  est_valide: boolean;
  erreurs?: any;
}

interface Declaration {
  id?: string;
  mois: number;
  annee: number;
  statut: string;
  nombre_lignes: number;
  total_salaires: number;
  total_jours: number;
}

const DeclarationCnssPage: React.FC = () => {
  const [step, setStep] = useState(1);
  const [mois, setMois] = useState(new Date().getMonth() + 1);
  const [annee, setAnnee] = useState(new Date().getFullYear());
  const [declaration, setDeclaration] = useState<Declaration | null>(null);
  const [lignes, setLignes] = useState<DeclarationLigne[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatut, setFilterStatut] = useState("TOUS");
  const [importMode, setImportMode] = useState<"file" | "auto">("auto");
  const [editingIdx, setEditingIdx] = useState<number | null>(null);
  const [editRow, setEditRow] = useState<Partial<DeclarationLigne>>({});
  // RG-DECL-CNSS-PARAM : Paramètres système CNSS depuis ref_constante_paie
  const [paramsCnss, setParamsCnss] = useState({
    plafondJours: 26,
    plafondBase: 6000,
    tauxSalarial: 4.48,
    tauxPatronal: 8.98,
    deadlineJour: 10,
    rubriqueSalaireBrut: "",
    rubriqueNbrJours: "",
  });
  const [paramsLoaded, setParamsLoaded] = useState(false);
  // Rubriques disponibles pour la sélection source
  const [rubriquesDisponibles, setRubriquesDisponibles] = useState<{
    code: string; libelle: string; zone_fixe_key: string | null; code_type: string | null;
    alimentations: { code_attribut: string; source_type: string }[];
  }[]>([]);
  // Résolution des sources configurées
  const [sourceSalaire, setSourceSalaire] = useState<{ code: string; libelle: string; zone_fixe_key: string | null } | null>(null);
  const [sourceJours, setSourceJours] = useState<{ code: string; libelle: string; zone_fixe_key: string | null } | null>(null);
  // Attribut et type sélectionnés pour les sources
  const [salaireSrcAttribut, setSalaireSrcAttribut] = useState("");
  const [salaireSrcType, setSalaireSrcType] = useState("");
  const [joursSrcAttribut, setJoursSrcAttribut] = useState("");
  const [joursSrcType, setJoursSrcType] = useState("");
  // Référentiel des statuts CNSS
  const [statutsCnss, setStatutsCnss] = useState<{ code: string; libelle: string; description: string | null }[]>([
    { code: "ACTIF", libelle: "Actif", description: null },
    { code: "ENTRANT", libelle: "Entrant", description: null },
    { code: "SORTANT", libelle: "Sortant", description: null },
  ]);

  // Attributs et types standards (comme dans la valorisation des rubriques)
  const ATTRIBUTS_STANDARD = [
    { code: "BASE", label: "Nombre" },
    { code: "TAUX", label: "Taux" },
    { code: "MONT", label: "Montant" },
    { code: "DATE", label: "Date" },
    { code: "TEXT", label: "Texte" },
  ];
  const TYPES_SOURCE_STANDARD = [
    { code: "TABLE", label: "Table" },
    { code: "RUBRIQUE", label: "Périodique" },
    { code: "RUBRIQUE_CUMUL", label: "Cumulée" },
    { code: "CONSTANTE", label: "Constante" },
  ];

  useEffect(() => {
    const loadStatuts = async () => {
      const data = []; const error = null; // Supabase desactive
      if (data && (data as any[]).length > 0) {
        setStatutsCnss((data as any[]).map((d: any) => ({ code: d.code, libelle: d.libelle, description: d.description || null })));
      }
    };
    loadStatuts();
  }, []);

  // Charger les rubriques disponibles avec type et alimentations
  useEffect(() => {
    const loadRubriques = async () => {
      const data = []; const error = null; // Supabase desactive
      const data = []; const error = null; // Supabase desactive
      const alimMap: Record<string, { code_attribut: string; source_type: string }[]> = {};
      ((alims || []) as any[]).forEach((a: any) => {
        if (!alimMap[a.code_rubrique]) alimMap[a.code_rubrique] = [];
        alimMap[a.code_rubrique].push({ code_attribut: a.code_attribut, source_type: a.source_type });
      });
      if (rubs) {
        setRubriquesDisponibles((rubs as any[]).map((r: any) => ({
          code: r.code,
          libelle: r.libelle,
          zone_fixe_key: r.zone_fixe_key || null,
          code_type: r.code_type || null,
          alimentations: alimMap[r.code] || [],
        })));
      }
    };
    loadRubriques();
  }, []);

  useEffect(() => {
    const loadParams = async () => {
      const data = []; const error = null; // Supabase desactive

      if (data && data.length > 0) {
        const map: Record<string, string> = {};
        data.forEach((d: any) => { map[d.code] = d.valeur || ""; });
        setParamsCnss({
          plafondJours: parseFloat(map["CNSS_PLAFOND_JOURS"]) || 26,
          plafondBase: parseFloat(map["CNSS_PLAFOND_BASE"]) || 6000,
          tauxSalarial: parseFloat(map["CNSS_TAUX_SALARIAL"]) || 4.48,
          tauxPatronal: parseFloat(map["CNSS_TAUX_PATRONAL"]) || 8.98,
          deadlineJour: parseFloat(map["CNSS_DEADLINE_JOUR"]) || 10,
          rubriqueSalaireBrut: map["CNSS_RUBRIQUE_SALAIRE_BRUT"] || "",
          rubriqueNbrJours: map["CNSS_RUBRIQUE_NBR_JOURS"] || "",
        });
      }
      setParamsLoaded(true);
    };
    loadParams();
  }, []);

  // Résoudre les rubriques sources quand params et rubriques sont chargés
  useEffect(() => {
    if (!paramsLoaded || rubriquesDisponibles.length === 0) return;
    if (paramsCnss.rubriqueSalaireBrut) {
      const found = rubriquesDisponibles.find(r => r.code === paramsCnss.rubriqueSalaireBrut);
      setSourceSalaire(found || null);
    } else {
      setSourceSalaire(null);
    }
    if (paramsCnss.rubriqueNbrJours) {
      const found = rubriquesDisponibles.find(r => r.code === paramsCnss.rubriqueNbrJours);
      setSourceJours(found || null);
    } else {
      setSourceJours(null);
    }
  }, [paramsLoaded, paramsCnss.rubriqueSalaireBrut, paramsCnss.rubriqueNbrJours, rubriquesDisponibles]);

  // Sauvegarder le choix d'une rubrique source
  const saveSourceRubrique = async (constCode: string, rubriqueCode: string) => {
    try {
      const { error } = await supabase
        .from("ref_constante_paie")
        .update({ valeur: rubriqueCode } as any)
        .eq("code", constCode);
      if (error) throw error;
      setParamsCnss(prev => ({
        ...prev,
        [constCode === "CNSS_RUBRIQUE_SALAIRE_BRUT" ? "rubriqueSalaireBrut" : "rubriqueNbrJours"]: rubriqueCode,
      }));
      toast.success(`Source ${constCode === "CNSS_RUBRIQUE_SALAIRE_BRUT" ? "salaire brut" : "nombre de jours"} mise à jour`);
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  // Sauvegarder un paramètre numérique CNSS
  const saveParamCnss = async (constCode: string, value: string) => {
    try {
      const { error } = await supabase
        .from("ref_constante_paie")
        .update({ valeur: value } as any)
        .eq("code", constCode);
      if (error) throw error;
      const numVal = parseFloat(value) || 0;
      const keyMap: Record<string, string> = {
        CNSS_PLAFOND_JOURS: "plafondJours",
        CNSS_PLAFOND_BASE: "plafondBase",
        CNSS_TAUX_SALARIAL: "tauxSalarial",
        CNSS_TAUX_PATRONAL: "tauxPatronal",
        CNSS_DEADLINE_JOUR: "deadlineJour",
      };
      if (keyMap[constCode]) {
        setParamsCnss(prev => ({ ...prev, [keyMap[constCode]]: numVal }));
      }
      toast.success("Paramètre mis à jour");
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  // ─── Étape 1 : Initialiser ou charger une déclaration ───
  const initDeclaration = async () => {
    setLoading(true);
    try {
      // Vérifier si une déclaration existe déjà
      const data = []; const error = null; // Supabase desactive

      if (existing) {
        setDeclaration(existing as any);
        // Charger les lignes
        const data = []; const error = null; // Supabase desactive
        setLignes((l || []) as any);
        toast.info(`Déclaration ${MOIS_LABELS[mois]} ${annee} chargée (${l?.length || 0} lignes)`);
      } else {
        setDeclaration(null);
        setLignes([]);
      }
    } catch (e: any) {
      toast.error(e.message);
    }
    setLoading(false);
  };

  // ─── Étape 1 : Import fichier préétabli ───
  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    try {
      const text = await file.text();
      const ext = file.name.split(".").pop()?.toLowerCase();
      let importedLines: DeclarationLigne[] = [];

      if (ext === "xml") {
        // Parse XML préétabli Damancom
        const parser = new DOMParser();
        const xml = parser.parseFromString(text, "text/xml");
        const salaries = xml.querySelectorAll("Salarie, salarie, SALARIE");
        salaries.forEach(s => {
          importedLines.push({
            matricule: s.querySelector("Matricule, matricule")?.textContent || "",
            cin: s.querySelector("CIN, cin, Cin")?.textContent || "",
            num_cnss: s.querySelector("NumCNSS, numcnss, NumCnss, numeroCNSS")?.textContent || "",
            nom: s.querySelector("Nom, nom")?.textContent || "",
            prenom: s.querySelector("Prenom, prenom")?.textContent || "",
            salaire_brut: 0,
            nombre_jours: 0,
            statut_salarie: "ACTIF",
            observations: "",
            est_valide: true,
          });
        });
      } else {
        // CSV / TSV
        const sep = text.includes("\t") ? "\t" : text.includes(";") ? ";" : ",";
        const rows = text.trim().split("\n").map(r => r.split(sep).map(c => c.trim().replace(/^"|"$/g, "")));
        const header = rows[0].map(h => h.toLowerCase());
        for (let i = 1; i < rows.length; i++) {
          const row = rows[i];
          if (row.length < 3) continue;
          const get = (keys: string[]) => {
            const idx = header.findIndex(h => keys.some(k => h.includes(k)));
            return idx >= 0 ? row[idx] : "";
          };
          importedLines.push({
            matricule: get(["matricule", "mat"]),
            cin: get(["cin", "cine", "carte"]),
            num_cnss: get(["cnss", "immatriculation"]),
            nom: get(["nom", "name"]),
            prenom: get(["prenom", "prénom", "firstname"]),
            salaire_brut: 0,
            nombre_jours: 0,
            statut_salarie: "ACTIF",
            observations: "Importé depuis fichier préétabli",
            est_valide: true,
          });
        }
      }

      if (importedLines.length === 0) {
        toast.error("Aucune ligne détectée dans le fichier");
        setLoading(false);
        return;
      }

      setLignes(importedLines);
      toast.success(`RG-DECL-CNSS-01 : ${importedLines.length} salariés importés depuis le fichier préétabli`);
      setImportMode("file");
    } catch (err: any) {
      toast.error("Erreur de lecture : " + err.message);
    }
    setLoading(false);
    e.target.value = "";
  };

  // ─── Étape 2 : Alimentation automatique ───
  const alimenterAuto = async () => {
    setLoading(true);
    try {
      // RG-DECL-CNSS-02 : Récupérer les collaborateurs actifs avec contrat en cours
      // RG-DECL-CNSS-SOURCE : Récupérer dynamiquement les champs configurés via rubriques
      const zfKeySalaire = sourceSalaire?.zone_fixe_key || null;
      const zfKeyJours = sourceJours?.zone_fixe_key || null;

      // Construire la sélection dynamique des champs salaires_fixes
      const sfFields = ["salaire_base", "date_debut", "date_fin", "archive"];
      if (zfKeySalaire && !sfFields.includes(zfKeySalaire)) sfFields.push(zfKeySalaire);
      if (zfKeyJours && !sfFields.includes(zfKeyJours)) sfFields.push(zfKeyJours);

      const data = []; const error = null; // Supabase desactive

      if (error) throw error;

      const periodeDebut = new Date(annee, mois - 1, 1);
      const periodeFin = new Date(annee, mois, 0);
      const joursOuvres = calculerJoursOuvres(periodeDebut, periodeFin);

      const newLignes: DeclarationLigne[] = (collabs || []).map((c: any) => {
        // Contrat actif
        const contratActif = c.collaborateur_contrats?.find((ct: any) =>
          !ct.archive && ct.code_statut_contrat !== "CLOTURE" &&
          !ct.date_sortie && new Date(ct.date_debut) <= periodeFin
        );

        // Salaire en cours
        const salaireActif = c.collaborateur_salaires_fixes?.find((s: any) =>
          !s.archive && new Date(s.date_debut) <= periodeFin &&
          (!s.date_fin || new Date(s.date_fin) >= periodeDebut)
        );

        // RG-DECL-CNSS-02 : Statut du salarié
        let statut = "ACTIF";
        if (contratActif && new Date(contratActif.date_debut).getMonth() + 1 === mois &&
            new Date(contratActif.date_debut).getFullYear() === annee) {
          statut = "ENTRANT";
        }
        if (c.statut_collaborateur === "EN_DEPART") {
          statut = "SORTANT";
        }

        // RG-DECL-CNSS-SOURCE : Résolution dynamique du nombre de jours
        let jours: number;
        if (zfKeyJours && salaireActif && salaireActif[zfKeyJours] != null) {
          // Source configurée via rubrique → zone fixe
          jours = Math.min(Number(salaireActif[zfKeyJours]) || 0, paramsCnss.plafondJours);
        } else {
          // Fallback : calcul automatique des jours ouvrés
          jours = Math.min(joursOuvres, paramsCnss.plafondJours);
          if (statut === "ENTRANT" && contratActif) {
            const dateEntree = new Date(contratActif.date_debut);
            jours = Math.min(calculerJoursOuvres(dateEntree, periodeFin), paramsCnss.plafondJours);
          }
        }

        // RG-DECL-CNSS-SOURCE : Résolution dynamique du salaire brut
        let salaireBase: number;
        if (zfKeySalaire && salaireActif && salaireActif[zfKeySalaire] != null) {
          // Source configurée via rubrique → zone fixe
          salaireBase = Number(salaireActif[zfKeySalaire]) || 0;
        } else {
          // Fallback : salaire_base
          salaireBase = salaireActif?.salaire_base || 0;
        }
        const salairePlafonne = Math.min(salaireBase, paramsCnss.plafondBase);

        const obs: string[] = [];
        if (!c.num_cnss) obs.push("⚠ Pas de N°CNSS");
        if (salaireBase > paramsCnss.plafondBase) obs.push(`Base plafonnée : ${salaireBase.toFixed(2)} → ${salairePlafonne.toFixed(2)}`);

        return {
          collaborateur_id: c.id,
          matricule: c.matricule,
          cin: c.cin || "",
          num_cnss: c.num_cnss || "",
          nom: c.nom,
          prenom: c.prenom,
          salaire_brut: salairePlafonne,
          nombre_jours: jours,
          statut_salarie: statut,
          observations: obs.join(" | "),
          est_valide: true,
        };
      });

      // Si on avait importé un fichier préétabli, fusionner avec les données réelles
      if (importMode === "file" && lignes.length > 0) {
        // Enrichir les lignes importées avec les salaires/jours réels
        const merged = lignes.map(l => {
          const match = newLignes.find(n =>
            (l.cin && n.cin && l.cin === n.cin) ||
            (l.num_cnss && n.num_cnss && l.num_cnss === n.num_cnss) ||
            (l.matricule && n.matricule && l.matricule === n.matricule)
          );
          if (match) {
            return {
              ...l,
              collaborateur_id: match.collaborateur_id,
              salaire_brut: match.salaire_brut,
              nombre_jours: match.nombre_jours,
              statut_salarie: match.statut_salarie,
              observations: match.observations || l.observations,
            };
          }
          return { ...l, observations: "⚠ Non trouvé dans le système", est_valide: false };
        });
        // Ajouter les nouveaux qui ne sont pas dans le fichier préétabli (entrants)
        const entrants = newLignes.filter(n =>
          !lignes.some(l =>
            (l.cin && n.cin && l.cin === n.cin) ||
            (l.num_cnss && n.num_cnss && l.num_cnss === n.num_cnss)
          ) && n.statut_salarie === "ENTRANT"
        );
        setLignes([...merged, ...entrants.map(e => ({ ...e, observations: "Nouvelle recrue (ENTRANT)" }))]);
      } else {
        setLignes(newLignes);
      }

      toast.success(`RG-DECL-CNSS-02 : ${newLignes.length} collaborateurs alimentés (${joursOuvres} jours ouvrés)`);
    } catch (err: any) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  // ─── Étape 3 : Contrôle de cohérence ───
  const getDeadlineInfo = () => {
    const deadlineDate = new Date(mois === 12 ? annee + 1 : annee, mois === 12 ? 0 : mois, paramsCnss.deadlineJour);
    const now = new Date();
    const diffJours = Math.ceil((deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return { deadlineDate, diffJours, isExpired: diffJours < 0 };
  };

  const controler = () => {
    // RG-DECL-CNSS-DEADLINE : Vérification du deadline
    const { diffJours, isExpired } = getDeadlineInfo();
    if (isExpired) {
      toast.warning(`RG-DECL-CNSS-DEADLINE : Deadline dépassé de ${Math.abs(diffJours)} jour(s). La génération sera bloquée.`);
    } else if (diffJours <= 5) {
      toast.warning(`RG-DECL-CNSS-DEADLINE : Attention, il reste ${diffJours} jour(s) avant le deadline.`);
    }
    let erreurs = 0;
    const updated = lignes.map(l => {
      const errs: string[] = [];
      // RG-DECL-CNSS-03 : Contrôle CIN obligatoire
      if (!l.cin || l.cin.trim().length < 4) {
        errs.push("CIN manquante ou invalide");
      }
      // RG-DECL-CNSS-03 : Pas de N°CNSS → statut ENTRANT
      if (!l.num_cnss || l.num_cnss.trim() === "") {
        if (l.statut_salarie !== "ENTRANT") {
          errs.push("N°CNSS manquant – Statut basculé en ENTRANT");
        }
        l.statut_salarie = "ENTRANT";
      }
      // RG-DECL-CNSS-PARAM-02 : Contrôle base plafonnée (0 est autorisé)
      if (l.salaire_brut < 0) {
        errs.push("Salaire brut négatif");
      }
      if (l.salaire_brut > paramsCnss.plafondBase) {
        errs.push(`Salaire (${l.salaire_brut.toFixed(2)}) dépasse le plafond CNSS (${paramsCnss.plafondBase.toFixed(2)})`);
      }
      // RG-DECL-CNSS-PARAM-01 : Contrôle plafond jours (0 est autorisé)
      if (l.nombre_jours < 0 || l.nombre_jours > paramsCnss.plafondJours) {
        errs.push(`Jours (${l.nombre_jours}) hors limite [0-${paramsCnss.plafondJours}]`);
      }
      if (errs.length > 0) erreurs++;
      return {
        ...l,
        est_valide: errs.length === 0,
        erreurs: errs.length > 0 ? errs : undefined,
        observations: errs.length > 0 ? errs.join(" | ") : l.observations
      };
    });
    setLignes(updated);
    if (erreurs === 0) {
      toast.success("RG-DECL-CNSS-03 : Contrôle réussi – Aucune anomalie détectée");
    } else {
      toast.warning(`RG-DECL-CNSS-03 : ${erreurs} anomalie(s) détectée(s) – Veuillez corriger`);
    }
  };

  // ─── Sauvegarder la déclaration en base ───
  const sauvegarder = async (statut: string) => {
    setLoading(true);
    try {
      const totalSalaires = lignes.reduce((s, l) => s + (l.salaire_brut || 0), 0);
      const totalJours = lignes.reduce((s, l) => s + (l.nombre_jours || 0), 0);

      let declId = declaration?.id;
      if (!declId) {
        const data = []; const error = null; // Supabase desactive
        if (error) throw error;
        declId = data.id;
      } else {
        await supabase
          .from("cnss_declarations")
          .update({
            statut,
            nombre_lignes: lignes.length,
            total_salaires: totalSalaires,
            total_jours: totalJours,
          })
          .eq("id", declId);
      }

      // Supprimer les anciennes lignes et insérer les nouvelles
      await supabase.from("cnss_declaration_lignes").delete().eq("declaration_id", declId);

      const rows = lignes.map(l => ({
        declaration_id: declId,
        collaborateur_id: l.collaborateur_id || null,
        matricule: l.matricule,
        cin: l.cin,
        num_cnss: l.num_cnss,
        nom: l.nom,
        prenom: l.prenom,
        salaire_brut: l.salaire_brut,
        nombre_jours: l.nombre_jours,
        statut_salarie: l.statut_salarie,
        observations: l.observations,
        est_valide: l.est_valide,
        erreurs: l.erreurs || null,
      }));

      // Insérer par lots de 100
      for (let i = 0; i < rows.length; i += 100) {
        const { error } = await supabase.from("cnss_declaration_lignes").insert(rows.slice(i, i + 100));
        if (error) throw error;
      }

      setDeclaration({ id: declId, mois, annee, statut, nombre_lignes: lignes.length, total_salaires: totalSalaires, total_jours: totalJours });
      toast.success(`Déclaration sauvegardée (${statut})`);
    } catch (err: any) {
      toast.error(err.message);
    }
    setLoading(false);
  };

  // ─── Étape 4 : Générer XML Damancom ───
  const genererXML = () => {
    const lignesValides = lignes.filter(l => l.est_valide);
    if (lignesValides.length === 0) {
      toast.error("Aucune ligne valide pour générer le XML");
      return;
    }

    // RG-DECL-CNSS-DEADLINE : Bloquer la génération si deadline dépassé
    const { isExpired, diffJours } = getDeadlineInfo();
    if (isExpired) {
      const forcer = confirm(`⚠ Le deadline est dépassé de ${Math.abs(diffJours)} jour(s).\nVoulez-vous forcer la génération malgré le retard ?`);
      if (!forcer) return;
    }

    const totalSalaires = lignesValides.reduce((s, l) => s + l.salaire_brut, 0);
    const totalJours = lignesValides.reduce((s, l) => s + l.nombre_jours, 0);

    // RG-DECL-CNSS-04 : Format XML Damancom standard
    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    xml += `<DeclarationCNSS>\n`;
    xml += `  <Entete>\n`;
    xml += `    <Mois>${String(mois).padStart(2, "0")}</Mois>\n`;
    xml += `    <Annee>${annee}</Annee>\n`;
    xml += `    <NombreSalaries>${lignesValides.length}</NombreSalaries>\n`;
    xml += `    <TotalSalaires>${totalSalaires.toFixed(2)}</TotalSalaires>\n`;
    xml += `    <TotalJours>${totalJours}</TotalJours>\n`;
    xml += `    <DateGeneration>${new Date().toISOString().split("T")[0]}</DateGeneration>\n`;
    xml += `  </Entete>\n`;
    xml += `  <Salaries>\n`;

    lignesValides.forEach(l => {
      xml += `    <Salarie>\n`;
      xml += `      <NumCNSS>${escapeXml(l.num_cnss)}</NumCNSS>\n`;
      xml += `      <CIN>${escapeXml(l.cin)}</CIN>\n`;
      xml += `      <Nom>${escapeXml(l.nom)}</Nom>\n`;
      xml += `      <Prenom>${escapeXml(l.prenom)}</Prenom>\n`;
      xml += `      <Matricule>${escapeXml(l.matricule)}</Matricule>\n`;
      xml += `      <SalaireBrut>${l.salaire_brut.toFixed(2)}</SalaireBrut>\n`;
      xml += `      <NombreJours>${l.nombre_jours}</NombreJours>\n`;
      xml += `      <StatutSalarie>${l.statut_salarie}</StatutSalarie>\n`;
      xml += `    </Salarie>\n`;
    });

    xml += `  </Salaries>\n`;
    xml += `</DeclarationCNSS>`;

    // Télécharger
    const blob = new Blob([xml], { type: "application/xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `CNSS_${annee}_${String(mois).padStart(2, "0")}.xml`;
    a.click();
    URL.revokeObjectURL(url);

    sauvegarder("GENEREE");
    toast.success(`RG-DECL-CNSS-04 : Fichier XML généré (${lignesValides.length} salariés)`);
  };

  // ─── Helpers ───
  const escapeXml = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  const calculerJoursOuvres = (debut: Date, fin: Date): number => {
    let jours = 0;
    const d = new Date(debut);
    while (d <= fin) {
      const day = d.getDay();
      if (day !== 0) jours++; // Dimanche exclu
      d.setDate(d.getDate() + 1);
    }
    return Math.min(jours, paramsCnss.plafondJours);
  };

  const filteredLignes = lignes.filter(l => {
    const matchSearch = !searchTerm ||
      l.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.prenom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.cin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.matricule.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatut = filterStatut === "TOUS" || l.statut_salarie === filterStatut;
    return matchSearch && matchStatut;
  });

  const stats = {
    total: lignes.length,
    actifs: lignes.filter(l => l.statut_salarie === "ACTIF").length,
    entrants: lignes.filter(l => l.statut_salarie === "ENTRANT").length,
    sortants: lignes.filter(l => l.statut_salarie === "SORTANT").length,
    erreurs: lignes.filter(l => !l.est_valide).length,
    sansCnss: lignes.filter(l => !l.num_cnss).length,
    totalSalaires: lignes.reduce((s, l) => s + l.salaire_brut, 0),
  };

  const steps = [
    { num: 0, label: "Paramétrage", icon: <Settings size={16} /> },
    { num: 1, label: "Fichier préétabli", icon: <Upload size={16} /> },
    { num: 2, label: "Alimentation", icon: <RefreshCw size={16} /> },
    { num: 3, label: "Contrôle", icon: <CheckCircle2 size={16} /> },
    { num: 4, label: "Génération XML", icon: <Download size={16} /> },
  ];

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <div className="p-2 rounded-xl bg-accent/10">
          <Shield size={20} className="text-accent" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-foreground">Déclaration CNSS</h1>
          <p className="text-xs text-muted-foreground">
            Paramétrage → Import → Alimentation → Contrôle → Génération XML
          </p>
        </div>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-1 mb-5 overflow-x-auto pb-2">
        {steps.map((s, i) => (
          <React.Fragment key={s.num}>
            <button
              onClick={() => setStep(s.num)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                step === s.num
                  ? "bg-primary text-primary-foreground shadow"
                  : step > s.num
                  ? "bg-emerald-500/10 text-emerald-600"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {step > s.num ? <CheckCircle2 size={14} /> : s.icon}
              <span className="hidden sm:inline">{s.label}</span>
              <span className="sm:hidden">{s.num}</span>
            </button>
            {i < steps.length - 1 && <ArrowRight size={14} className="text-muted-foreground flex-shrink-0" />}
          </React.Fragment>
        ))}
      </div>

      {/* Résumé paramètres (compact, visible sur toutes les étapes sauf paramétrage) */}
      {paramsLoaded && step !== 0 && (
        <div className="flex flex-wrap gap-2 mb-4 px-1">
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground bg-muted/50 px-2.5 py-1 rounded-full">
            <Shield size={10} className="text-primary" /> {paramsCnss.plafondJours}j / {paramsCnss.plafondBase.toLocaleString("fr-FR")} MAD
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground bg-muted/50 px-2.5 py-1 rounded-full">
            Tx sal. {paramsCnss.tauxSalarial}% | pat. {paramsCnss.tauxPatronal}%
          </div>
          {(() => {
            const deadlineDate = new Date(mois === 12 ? annee + 1 : annee, mois === 12 ? 0 : mois, paramsCnss.deadlineJour);
            const diffJours = Math.ceil((deadlineDate.getTime() - Date.now()) / 86400000);
            const isExpired = diffJours < 0;
            const isUrgent = diffJours >= 0 && diffJours <= 5;
            return (
              <div className={`flex items-center gap-1 text-[11px] px-2.5 py-1 rounded-full font-medium ${
                isExpired ? "bg-destructive/15 text-destructive" : isUrgent ? "bg-amber-500/15 text-amber-600" : "bg-emerald-500/10 text-emerald-600"
              }`}>
                {isExpired ? "⛔" : "📅"} J{isExpired ? diffJours : `+${diffJours}`}
              </div>
            );
          })()}
          <button onClick={() => setStep(0)} className="text-[11px] text-primary hover:underline ml-1">⚙ Paramétrage</button>
        </div>
      )}

      {/* ═══ ÉTAPE 0 : Paramétrage CNSS ═══ */}
      {step === 0 && (
        <div className="space-y-4">
          {/* Plafonds et taux */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <Shield size={16} className="text-primary" />
              Plafonds et taux CNSS
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-medium text-foreground mb-1 block">Plafond jours déclarés</label>
                <input type="number" defaultValue={paramsCnss.plafondJours}
                  onBlur={e => saveParamCnss("CNSS_PLAFOND_JOURS", e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-foreground mb-1 block">Plafond base (MAD)</label>
                <input type="number" defaultValue={paramsCnss.plafondBase}
                  onBlur={e => saveParamCnss("CNSS_PLAFOND_BASE", e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-foreground mb-1 block">Jour deadline mensuel</label>
                <input type="number" min={1} max={28} defaultValue={paramsCnss.deadlineJour}
                  onBlur={e => saveParamCnss("CNSS_DEADLINE_JOUR", e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-foreground mb-1 block">Taux salarial (%)</label>
                <input type="number" step="0.01" defaultValue={paramsCnss.tauxSalarial}
                  onBlur={e => saveParamCnss("CNSS_TAUX_SALARIAL", e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm" />
              </div>
              <div>
                <label className="text-xs font-medium text-foreground mb-1 block">Taux patronal (%)</label>
                <input type="number" step="0.01" defaultValue={paramsCnss.tauxPatronal}
                  onBlur={e => saveParamCnss("CNSS_TAUX_PATRONAL", e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm" />
              </div>
            </div>
          </div>

          {/* Sources de données */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Info size={16} className="text-primary" />
              Sources de données
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              RG-DECL-CNSS-SOURCE : Sélectionnez la rubrique, l'attribut (Nombre, Taux, Montant) et le type de récupération pour chaque donnée.
            </p>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Source Salaire Brut */}
              <div className="space-y-3 p-4 rounded-xl border border-border bg-muted/20">
                <p className="text-xs font-semibold text-foreground">📊 Salaire brut</p>
                <div>
                  <label className="text-[11px] text-muted-foreground mb-1 block">Rubrique</label>
                  <select value={paramsCnss.rubriqueSalaireBrut}
                    onChange={e => { saveSourceRubrique("CNSS_RUBRIQUE_SALAIRE_BRUT", e.target.value); setSalaireSrcAttribut(""); setSalaireSrcType(""); }}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-xs">
                    <option value="">— salaire_base (par défaut) —</option>
                    {rubriquesDisponibles.map(r => (
                      <option key={r.code} value={r.code}>
                        {r.code} – {r.libelle}{r.code_type ? ` [${r.code_type}]` : ""}{r.zone_fixe_key ? ` (${r.zone_fixe_key})` : ""}
                      </option>
                    ))}
                  </select>
                </div>
                {paramsCnss.rubriqueSalaireBrut && (() => {
                  const rub = rubriquesDisponibles.find(r => r.code === paramsCnss.rubriqueSalaireBrut);
                  const attrs = rub?.alimentations || [];
                  const uniqueAttrs = [...new Set(attrs.map(a => a.code_attribut))];
                  const uniqueTypes = [...new Set(attrs.map(a => a.source_type))];
                  return (
                    <>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] text-muted-foreground mb-1 block">Attribut</label>
                          <select value={salaireSrcAttribut} onChange={e => setSalaireSrcAttribut(e.target.value)}
                            className="w-full px-2 py-1.5 rounded-lg border border-input bg-background text-xs">
                            <option value="">—</option>
                            {ATTRIBUTS_STANDARD.map(a => <option key={a.code} value={a.code}>{a.label}</option>)}
                          </select>
                        </div>
                        <div>
                          <label className="text-[11px] text-muted-foreground mb-1 block">Type</label>
                          <select value={salaireSrcType} onChange={e => setSalaireSrcType(e.target.value)}
                            className="w-full px-2 py-1.5 rounded-lg border border-input bg-background text-xs">
                            <option value="">—</option>
                            {TYPES_SOURCE_STANDARD.map(t => <option key={t.code} value={t.code}>{t.label}</option>)}
                          </select>
                        </div>
                      </div>
                      {rub && !rub.zone_fixe_key && (
                        <p className="text-[11px] text-amber-600 mt-1">ℹ Cette rubrique n'a pas de zone fixe – le salaire_base sera utilisé par défaut.</p>
                      )}
                      {attrs.length === 0 && (
                        <p className="text-[11px] text-muted-foreground mt-1">Aucune alimentation configurée pour cette rubrique.</p>
                      )}
                    </>
                  );
                })()}
              </div>

              {/* Source Nombre de jours */}
              <div className="space-y-3 p-4 rounded-xl border border-border bg-muted/20">
                <p className="text-xs font-semibold text-foreground">📅 Nombre de jours</p>
                <div>
                  <label className="text-[11px] text-muted-foreground mb-1 block">Rubrique</label>
                  <select value={paramsCnss.rubriqueNbrJours}
                    onChange={e => { saveSourceRubrique("CNSS_RUBRIQUE_NBR_JOURS", e.target.value); setJoursSrcAttribut(""); setJoursSrcType(""); }}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-xs">
                    <option value="">— Jours ouvrés calculés (par défaut) —</option>
                    {rubriquesDisponibles.map(r => (
                      <option key={r.code} value={r.code}>
                        {r.code} – {r.libelle}{r.code_type ? ` [${r.code_type}]` : ""}{r.zone_fixe_key ? ` (${r.zone_fixe_key})` : ""}
                      </option>
                    ))}
                  </select>
                </div>
                {paramsCnss.rubriqueNbrJours && (() => {
                  const rub = rubriquesDisponibles.find(r => r.code === paramsCnss.rubriqueNbrJours);
                  const attrs = rub?.alimentations || [];
                  const uniqueAttrs = [...new Set(attrs.map(a => a.code_attribut))];
                  const uniqueTypes = [...new Set(attrs.map(a => a.source_type))];
                  return (
                    <>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[11px] text-muted-foreground mb-1 block">Attribut</label>
                          <select value={joursSrcAttribut} onChange={e => setJoursSrcAttribut(e.target.value)}
                            className="w-full px-2 py-1.5 rounded-lg border border-input bg-background text-xs">
                            <option value="">—</option>
                            {ATTRIBUTS_STANDARD.map(a => <option key={a.code} value={a.code}>{a.label}</option>)}
                          </select>
                        </div>
                        <div>
                          <label className="text-[11px] text-muted-foreground mb-1 block">Type</label>
                          <select value={joursSrcType} onChange={e => setJoursSrcType(e.target.value)}
                            className="w-full px-2 py-1.5 rounded-lg border border-input bg-background text-xs">
                            <option value="">—</option>
                            {TYPES_SOURCE_STANDARD.map(t => <option key={t.code} value={t.code}>{t.label}</option>)}
                          </select>
                        </div>
                      </div>
                      {rub && !rub.zone_fixe_key && (
                        <p className="text-[11px] text-amber-600 mt-1">ℹ Cette rubrique n'a pas de zone fixe – les jours ouvrés seront calculés.</p>
                      )}
                      {attrs.length === 0 && (
                        <p className="text-[11px] text-muted-foreground mt-1">Aucune alimentation configurée pour cette rubrique.</p>
                      )}
                    </>
                  );
                })()}
              </div>
            </div>
          </div>

          {/* Statuts CNSS */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Users size={16} className="text-primary" />
              Statuts des salariés CNSS
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                 <thead>
<tr className="bg-muted/40 border-b border-border">
                     <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground">Code</th>
                     <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground">Libellé</th>
                     <th className="px-3 py-2 text-left text-xs font-semibold text-muted-foreground">Description</th>
                   </tr>
                 </thead>
                 <tbody>
                   {statutsCnss.map(s => (
                     <tr key={s.code} className="border-b border-border">
                       <td className="px-3 py-2 font-mono text-xs text-accent font-semibold">{s.code}</td>
                       <td className="px-3 py-2 text-foreground">{s.libelle}</td>
                       <td className="px-3 py-2 text-xs text-muted-foreground">{s.description || "—"}</td>
                     </tr>
                   ))}
                 </tbody>
              </table>
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">
              Les statuts sont gérés via le référentiel des statuts CNSS (Référentiels → Paie & Rémunération).
            </p>
          </div>

          <div className="flex justify-end">
            <button onClick={() => setStep(1)}
              className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center gap-2">
              Commencer la déclaration <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}

      {/* ═══ ÉTAPE 1 : Fichier préétabli ═══ */}
      {step === 1 && (
        <div className="space-y-4">
          {/* Sélection période */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Calendar size={16} className="text-primary" />
              Période de déclaration
            </h3>
            <div className="flex flex-wrap gap-3">
              <select
                value={mois}
                onChange={e => setMois(Number(e.target.value))}
                className="px-3 py-2 rounded-lg border border-input bg-background text-sm"
              >
                {MOIS_LABELS.slice(1).map((m, i) => (
                  <option key={i + 1} value={i + 1}>{m}</option>
                ))}
              </select>
              <input
                type="number"
                value={annee}
                onChange={e => setAnnee(Number(e.target.value))}
                min={2020} max={2099}
                className="px-3 py-2 rounded-lg border border-input bg-background text-sm w-24"
              />
              <button
                onClick={initDeclaration}
                disabled={loading}
                className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 flex items-center gap-2"
              >
                {loading ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
                Charger
              </button>
            </div>
            {declaration && (
              <div className="mt-3 px-3 py-2 rounded-lg bg-emerald-500/10 text-emerald-700 text-xs flex items-center gap-2">
                <CheckCircle2 size={14} />
                Déclaration existante : {declaration.nombre_lignes} lignes – Statut : {declaration.statut}
              </div>
            )}
          </div>

          {/* Import fichier ou création auto */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-2xl border border-border bg-card p-5 hover:border-primary/30 transition-colors">
              <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
                <FileUp size={16} className="text-blue-600" />
                Importer le fichier préétabli
              </h3>
              <p className="text-xs text-muted-foreground mb-3">
                RG-DECL-CNSS-01 : Chargez le fichier CSV/Excel ou XML téléchargé depuis le portail Damancom.
              </p>
              <label className="flex items-center gap-2 px-4 py-2 rounded-lg border border-dashed border-primary/40 bg-primary/5 cursor-pointer hover:bg-primary/10 transition-colors text-sm font-medium text-primary">
                <Upload size={16} />
                Sélectionner un fichier
                <input
                  type="file"
                  accept=".csv,.txt,.xml,.xls,.xlsx"
                  onChange={handleFileImport}
                  className="hidden"
                />
              </label>
              {importMode === "file" && lignes.length > 0 && (
                <p className="mt-2 text-xs text-emerald-600">✓ {lignes.length} lignes importées</p>
              )}
            </div>

            <div className="rounded-2xl border border-border bg-card p-5 hover:border-primary/30 transition-colors">
              <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
                <Users size={16} className="text-violet-600" />
                Créer depuis les données système
              </h3>
              <p className="text-xs text-muted-foreground mb-3">
                Générer automatiquement la liste des salariés à déclarer à partir de la base collaborateurs.
              </p>
              <button
                onClick={() => { setImportMode("auto"); setStep(2); }}
                className="px-4 py-2 rounded-lg bg-violet-600 text-white text-sm font-medium hover:bg-violet-700 flex items-center gap-2"
              >
                <RefreshCw size={14} />
                Créer automatiquement
              </button>
            </div>
          </div>

          {/* Règles de gestion */}
          <div className="rounded-xl border border-blue-200 bg-blue-50/50 dark:bg-blue-950/20 dark:border-blue-800 p-4">
            <h4 className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-2 flex items-center gap-2">
              <Info size={14} /> Règles de gestion – Étape 1
            </h4>
            <ul className="text-xs text-blue-600 dark:text-blue-300 space-y-1 list-disc pl-4">
              <li><strong>RG-DECL-CNSS-01</strong> : Le fichier préétabli contient la liste des salariés telle que connue par la CNSS.</li>
              <li>Formats acceptés : CSV (séparateurs ; ou ,), TSV et XML Damancom.</li>
              <li>Si aucun fichier n'est importé, la déclaration est créée à partir des données internes.</li>
            </ul>
          </div>

          {lignes.length > 0 && (
            <div className="flex justify-end">
              <button
                onClick={() => setStep(2)}
                className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center gap-2"
              >
                Étape suivante <ArrowRight size={14} />
              </button>
            </div>
          )}
        </div>
      )}

      {/* ═══ ÉTAPE 2 : Alimentation automatique ═══ */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <RefreshCw size={16} className="text-primary" />
                Alimentation des salaires et jours – {MOIS_LABELS[mois]} {annee}
              </h3>
              <button
                onClick={alimenterAuto}
                disabled={loading}
                className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center gap-2 hover:opacity-90"
              >
                {loading ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
                Alimenter automatiquement
              </button>
            </div>

            {/* KPIs */}
            {lignes.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                <div className="rounded-xl bg-muted/50 p-3 text-center">
                  <p className="text-lg font-bold text-foreground">{stats.total}</p>
                  <p className="text-xs text-muted-foreground">Salariés</p>
                </div>
                <div className="rounded-xl bg-emerald-500/10 p-3 text-center">
                  <p className="text-lg font-bold text-emerald-600">{stats.actifs}</p>
                  <p className="text-xs text-muted-foreground">Actifs</p>
                </div>
                <div className="rounded-xl bg-blue-500/10 p-3 text-center">
                  <p className="text-lg font-bold text-blue-600">{stats.entrants}</p>
                  <p className="text-xs text-muted-foreground">Entrants</p>
                </div>
                <div className="rounded-xl bg-amber-500/10 p-3 text-center">
                  <p className="text-lg font-bold text-amber-600">{stats.sortants}</p>
                  <p className="text-xs text-muted-foreground">Sortants</p>
                </div>
              </div>
            )}

            {/* Tableau */}
            {lignes.length > 0 && renderTable()}
          </div>

          {/* Règles */}
          <div className="rounded-xl border border-blue-200 bg-blue-50/50 dark:bg-blue-950/20 dark:border-blue-800 p-4">
            <h4 className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-2 flex items-center gap-2">
              <Info size={14} /> Règles de gestion – Étape 2
            </h4>
            <ul className="text-xs text-blue-600 dark:text-blue-300 space-y-1 list-disc pl-4">
              <li><strong>RG-DECL-CNSS-02a</strong> : Le salaire brut est récupéré depuis le dernier salaire fixe actif.</li>
              <li><strong>RG-DECL-CNSS-02b</strong> : Le nombre de jours est calculé automatiquement (jours ouvrés, plafond 26j CNSS).</li>
              <li><strong>RG-DECL-CNSS-02c</strong> : Les nouvelles recrues du mois sont marquées ENTRANT avec jours au prorata.</li>
              <li><strong>RG-DECL-CNSS-02d</strong> : Les collaborateurs EN_DEPART sont marqués SORTANT.</li>
            </ul>
          </div>

          <div className="flex justify-between">
            <button onClick={() => setStep(1)} className="px-4 py-2 rounded-lg border border-border text-sm flex items-center gap-2">
              <ArrowLeft size={14} /> Retour
            </button>
            <button
              onClick={() => { if (lignes.length > 0) setStep(3); else toast.error("Veuillez alimenter les données"); }}
              className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center gap-2"
            >
              Étape suivante <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}

      {/* ═══ ÉTAPE 3 : Contrôle ═══ */}
      {step === 3 && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <CheckCircle2 size={16} className="text-primary" />
                Contrôle de cohérence
              </h3>
              <div className="flex gap-2">
                <button
                  onClick={controler}
                  className="px-4 py-2 rounded-lg bg-amber-600 text-white text-sm font-medium flex items-center gap-2 hover:bg-amber-700"
                >
                  <CheckCircle2 size={14} /> Lancer le contrôle
                </button>
                <button
                  onClick={() => sauvegarder("CONTROLEE")}
                  disabled={loading || stats.erreurs > 0}
                  className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium flex items-center gap-2 hover:bg-emerald-700 disabled:opacity-50"
                >
                  {loading ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                  Valider et sauvegarder
                </button>
              </div>
            </div>

            {/* KPIs contrôle */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="rounded-xl bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold text-foreground">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Total lignes</p>
              </div>
              <div className="rounded-xl bg-red-500/10 p-3 text-center">
                <p className="text-lg font-bold text-red-600">{stats.erreurs}</p>
                <p className="text-xs text-muted-foreground">Erreurs</p>
              </div>
              <div className="rounded-xl bg-amber-500/10 p-3 text-center">
                <p className="text-lg font-bold text-amber-600">{stats.sansCnss}</p>
                <p className="text-xs text-muted-foreground">Sans N°CNSS</p>
              </div>
              <div className="rounded-xl bg-emerald-500/10 p-3 text-center">
                <p className="text-lg font-bold text-emerald-600">
                  {stats.totalSalaires.toLocaleString("fr-FR", { minimumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground">Total salaires (MAD)</p>
              </div>
            </div>

            {/* Filtres */}
            <div className="flex flex-wrap gap-2 mb-3">
              <div className="relative flex-1 min-w-[180px]">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  placeholder="Rechercher (nom, CIN, matricule)…"
                  className="w-full pl-8 pr-3 py-2 rounded-lg border border-input bg-background text-sm"
                />
              </div>
              <select
                value={filterStatut}
                onChange={e => setFilterStatut(e.target.value)}
                className="px-3 py-2 rounded-lg border border-input bg-background text-sm"
              >
                <option value="TOUS">Tous les statuts</option>
                {statutsCnss.map(s => (
                  <option key={s.code} value={s.code}>{s.libelle}</option>
                ))}
              </select>
            </div>

            {renderTable()}
          </div>

          {/* Règles */}
          <div className="rounded-xl border border-blue-200 bg-blue-50/50 dark:bg-blue-950/20 dark:border-blue-800 p-4">
            <h4 className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-2 flex items-center gap-2">
              <Info size={14} /> Règles de gestion – Étape 3
            </h4>
            <ul className="text-xs text-blue-600 dark:text-blue-300 space-y-1 list-disc pl-4">
              <li><strong>RG-DECL-CNSS-03a</strong> : La CIN est obligatoire et vérifiée pour chaque salarié.</li>
              <li><strong>RG-DECL-CNSS-03b</strong> : Les collaborateurs sans N°CNSS sont automatiquement basculés en statut ENTRANT.</li>
              <li><strong>RG-DECL-CNSS-03c</strong> : Le salaire brut doit être strictement positif.</li>
              <li><strong>RG-DECL-CNSS-03d</strong> : Le nombre de jours doit être compris entre 1 et 26 (plafond CNSS).</li>
            </ul>
          </div>

          <div className="flex justify-between">
            <button onClick={() => setStep(2)} className="px-4 py-2 rounded-lg border border-border text-sm flex items-center gap-2">
              <ArrowLeft size={14} /> Retour
            </button>
            <button
              onClick={() => { if (stats.erreurs === 0) setStep(4); else toast.error("Corrigez les erreurs avant de continuer"); }}
              className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center gap-2"
            >
              Étape suivante <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}

      {/* ═══ ÉTAPE 4 : Génération XML ═══ */}
      {step === 4 && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-border bg-card p-5">
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <Download size={16} className="text-primary" />
              Génération du fichier XML – Format Damancom
            </h3>

            {/* Récapitulatif */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
              <div className="rounded-xl bg-muted/50 p-3 text-center">
                <p className="text-lg font-bold text-foreground">{MOIS_LABELS[mois]} {annee}</p>
                <p className="text-xs text-muted-foreground">Période</p>
              </div>
              <div className="rounded-xl bg-emerald-500/10 p-3 text-center">
                <p className="text-lg font-bold text-emerald-600">{lignes.filter(l => l.est_valide).length}</p>
                <p className="text-xs text-muted-foreground">Salariés déclarés</p>
              </div>
              <div className="rounded-xl bg-blue-500/10 p-3 text-center">
                <p className="text-lg font-bold text-blue-600">
                  {stats.totalSalaires.toLocaleString("fr-FR", { minimumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground">Total salaires (MAD)</p>
              </div>
              <div className="rounded-xl bg-violet-500/10 p-3 text-center">
                <p className="text-lg font-bold text-violet-600">
                  {lignes.reduce((s, l) => s + l.nombre_jours, 0)}
                </p>
                <p className="text-xs text-muted-foreground">Total jours</p>
              </div>
            </div>

            {/* Aperçu XML */}
            <div className="rounded-xl border border-border bg-muted/30 p-4 mb-4 max-h-48 overflow-y-auto">
              <pre className="text-xs text-muted-foreground font-mono whitespace-pre-wrap">
{`<?xml version="1.0" encoding="UTF-8"?>
<DeclarationCNSS>
  <Entete>
    <Mois>${String(mois).padStart(2, "0")}</Mois>
    <Annee>${annee}</Annee>
    <NombreSalaries>${lignes.filter(l => l.est_valide).length}</NombreSalaries>
    ...
  </Entete>
  <Salaries>
    ${lignes.filter(l => l.est_valide).slice(0, 3).map(l => `<Salarie>
      <NumCNSS>${l.num_cnss}</NumCNSS>
      <CIN>${l.cin}</CIN>
      <Nom>${l.nom}</Nom>
      <SalaireBrut>${l.salaire_brut.toFixed(2)}</SalaireBrut>
      <NombreJours>${l.nombre_jours}</NombreJours>
    </Salarie>`).join("\n    ")}
    ${lignes.filter(l => l.est_valide).length > 3 ? `... (${lignes.filter(l => l.est_valide).length - 3} autres)` : ""}
  </Salaries>
</DeclarationCNSS>`}
              </pre>
            </div>

            <button
              onClick={genererXML}
              disabled={loading}
              className="w-full px-4 py-3 rounded-lg bg-emerald-600 text-white text-sm font-semibold flex items-center justify-center gap-2 hover:bg-emerald-700"
            >
              {loading ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}
              Télécharger le fichier XML
            </button>
          </div>

          {/* Règles */}
          <div className="rounded-xl border border-blue-200 bg-blue-50/50 dark:bg-blue-950/20 dark:border-blue-800 p-4">
            <h4 className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-2 flex items-center gap-2">
              <Info size={14} /> Règles de gestion – Étape 4
            </h4>
            <ul className="text-xs text-blue-600 dark:text-blue-300 space-y-1 list-disc pl-4">
              <li><strong>RG-DECL-CNSS-04a</strong> : Seules les lignes valides (contrôle passé) sont incluses dans le XML.</li>
              <li><strong>RG-DECL-CNSS-04b</strong> : Le format respecte la structure Damancom (balises normalisées).</li>
              <li><strong>RG-DECL-CNSS-04c</strong> : Le fichier est nommé CNSS_AAAA_MM.xml.</li>
              <li><strong>RG-DECL-CNSS-04d</strong> : La déclaration est sauvegardée avec le statut GENEREE après téléchargement.</li>
            </ul>
          </div>

          <div className="flex justify-start">
            <button onClick={() => setStep(3)} className="px-4 py-2 rounded-lg border border-border text-sm flex items-center gap-2">
              <ArrowLeft size={14} /> Retour au contrôle
            </button>
          </div>
        </div>
      )}
    </div>
  );

  // ─── Table réutilisable ───
  // RG-DECL-CNSS-EDIT : Modification inline des lignes – Adil DAIA
  function startEdit(idx: number) {
    const realIdx = lignes.indexOf(filteredLignes[idx]);
    setEditingIdx(realIdx);
    setEditRow({ ...lignes[realIdx] });
  }

  function saveEdit() {
    if (editingIdx === null) return;
    // RG-DECL-CNSS-03-CIN : CIN obligatoire
    if (!editRow.cin || editRow.cin.trim().length < 4) {
      toast.error("La CIN est obligatoire (minimum 4 caractères)");
      return;
    }
    const updated = [...lignes];
    updated[editingIdx] = { ...updated[editingIdx], ...editRow } as DeclarationLigne;
    // Recalculer la validité
    const errs: string[] = [];
    const r = updated[editingIdx];
    if (!r.cin || r.cin.trim().length < 4) errs.push("CIN manquante ou invalide");
    if (!r.num_cnss && r.statut_salarie !== "ENTRANT") errs.push("N°CNSS manquant");
    if (r.salaire_brut <= 0) errs.push("Salaire brut nul ou négatif");
    if (r.salaire_brut > paramsCnss.plafondBase) errs.push(`Salaire dépasse le plafond (${paramsCnss.plafondBase})`);
    if (r.nombre_jours <= 0 || r.nombre_jours > paramsCnss.plafondJours) errs.push(`Jours hors limite [1-${paramsCnss.plafondJours}]`);
    updated[editingIdx].est_valide = errs.length === 0;
    updated[editingIdx].erreurs = errs.length > 0 ? errs : undefined;
    updated[editingIdx].observations = errs.length > 0 ? errs.join(" | ") : "";
    setLignes(updated);
    setEditingIdx(null);
    setEditRow({});
    toast.success("Ligne mise à jour");
  }

  function cancelEdit() {
    setEditingIdx(null);
    setEditRow({});
  }

  function renderTable() {
    const isEditing = (idx: number) => editingIdx === lignes.indexOf(filteredLignes[idx]);

    return (
      <div className="overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-muted/50">
              <th className="px-2 py-2 text-left font-medium text-muted-foreground">Matricule</th>
              <th className="px-2 py-2 text-left font-medium text-muted-foreground">CIN *</th>
              <th className="px-2 py-2 text-left font-medium text-muted-foreground">N°CNSS</th>
              <th className="px-2 py-2 text-left font-medium text-muted-foreground">Nom & Prénom</th>
              <th className="px-2 py-2 text-right font-medium text-muted-foreground">Salaire brut</th>
              <th className="px-2 py-2 text-center font-medium text-muted-foreground">Jours</th>
              <th className="px-2 py-2 text-center font-medium text-muted-foreground">Statut</th>
              <th className="px-2 py-2 text-left font-medium text-muted-foreground">Observations</th>
              <th className="px-2 py-2 text-center font-medium text-muted-foreground w-16">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredLignes.length === 0 && (
              <tr><td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">Aucune donnée</td></tr>
            )}
            {filteredLignes.map((l, i) => {
              const editing = isEditing(i);
              return (
                <tr key={i} className={`border-t border-border ${!l.est_valide ? "bg-red-500/5" : "hover:bg-muted/30"}`}>
                  <td className="px-2 py-1.5 font-mono">{l.matricule}</td>
                  <td className="px-2 py-1.5">
                    {editing ? (
                      <input
                        value={editRow.cin || ""}
                        onChange={e => setEditRow({ ...editRow, cin: e.target.value })}
                        className={`w-24 px-1.5 py-0.5 rounded border text-xs font-mono ${
                          !editRow.cin || editRow.cin.trim().length < 4
                            ? "border-red-400 bg-red-50 dark:bg-red-950/30"
                            : "border-input bg-background"
                        }`}
                        placeholder="CIN obligatoire"
                        autoFocus
                      />
                    ) : (
                      <span className={`font-mono ${!l.cin || l.cin.trim().length < 4 ? "text-red-500 font-semibold" : ""}`}>
                        {l.cin || <span className="text-red-500">⚠ Manquante</span>}
                      </span>
                    )}
                  </td>
                  <td className="px-2 py-1.5">
                    {editing ? (
                      <input
                        value={editRow.num_cnss || ""}
                        onChange={e => setEditRow({ ...editRow, num_cnss: e.target.value })}
                        className="w-28 px-1.5 py-0.5 rounded border border-input bg-background text-xs font-mono"
                        placeholder="N°CNSS"
                      />
                    ) : (
                      <span className="font-mono">{l.num_cnss || <span className="text-amber-500 font-medium">Non immatriculé</span>}</span>
                    )}
                  </td>
                  <td className="px-2 py-1.5 font-medium">{l.nom} {l.prenom}</td>
                  <td className="px-2 py-1.5 text-right">
                    {editing ? (
                      <input
                        type="number"
                        value={editRow.salaire_brut ?? 0}
                        onChange={e => setEditRow({ ...editRow, salaire_brut: parseFloat(e.target.value) || 0 })}
                        className="w-24 px-1.5 py-0.5 rounded border border-input bg-background text-xs font-mono text-right"
                        step="0.01" min="0"
                      />
                    ) : (
                      <span className="font-mono">{l.salaire_brut.toLocaleString("fr-FR", { minimumFractionDigits: 2 })}</span>
                    )}
                  </td>
                  <td className="px-2 py-1.5 text-center">
                    {editing ? (
                      <input
                        type="number"
                        value={editRow.nombre_jours ?? 0}
                        onChange={e => setEditRow({ ...editRow, nombre_jours: parseInt(e.target.value) || 0 })}
                        className="w-14 px-1.5 py-0.5 rounded border border-input bg-background text-xs text-center"
                        min="0" max={paramsCnss.plafondJours}
                      />
                    ) : (
                      l.nombre_jours
                    )}
                  </td>
                  <td className="px-2 py-1.5 text-center">
                    {editing ? (
                      <select
                        value={editRow.statut_salarie || "ACTIF"}
                        onChange={e => setEditRow({ ...editRow, statut_salarie: e.target.value })}
                        className="px-1.5 py-0.5 rounded border border-input bg-background text-xs"
                      >
                        {statutsCnss.map(s => (
                          <option key={s.code} value={s.code}>{s.libelle}</option>
                        ))}
                      </select>
                    ) : (
                      <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-semibold ${
                        l.statut_salarie === "ENTRANT" ? "bg-blue-500/10 text-blue-600" :
                        l.statut_salarie === "SORTANT" ? "bg-red-500/10 text-red-600" :
                        "bg-emerald-500/10 text-emerald-600"
                      }`}>
                        {statutsCnss.find(s => s.code === l.statut_salarie)?.libelle || l.statut_salarie}
                      </span>
                    )}
                  </td>
                  <td className="px-2 py-1.5 text-muted-foreground max-w-[200px] truncate" title={l.observations}>
                    {l.observations}
                  </td>
                  <td className="px-2 py-1.5 text-center">
                    {editing ? (
                      <div className="flex items-center gap-1 justify-center">
                        <button onClick={saveEdit} className="p-1 rounded hover:bg-emerald-500/10 text-emerald-600" title="Sauvegarder">
                          <Save size={13} />
                        </button>
                        <button onClick={cancelEdit} className="p-1 rounded hover:bg-red-500/10 text-red-500" title="Annuler">
                          <X size={13} />
                        </button>
                      </div>
                    ) : (
                      <button onClick={() => startEdit(i)} className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground" title="Modifier">
                        <Pencil size={13} />
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }
};

export default DeclarationCnssPage;
