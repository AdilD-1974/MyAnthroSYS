import React, { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Save, Users, ToggleRight } from "lucide-react";
import { toast } from "sonner";

interface Props {
  collaborateurId: string;
}

interface CollabOption {
  id: string;
  nom: string;
  prenom: string;
  matricule: string;
}

const WorkflowManagerForm: React.FC<Props> = ({ collaborateurId }) => {
  const [managerN1, setManagerN1] = useState<string | null>(null);
  const [managerN2, setManagerN2] = useState<string | null>(null);
  const [actif, setActif] = useState(false);
  const [commentaire, setCommentaire] = useState("");
  const [existingId, setExistingId] = useState<string | null>(null);
  const [collabs, setCollabs] = useState<CollabOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchN1, setSearchN1] = useState("");
  const [searchN2, setSearchN2] = useState("");

  useEffect(() => {
    const loadAll = async () => {
      setLoading(true);
      const [wfRes, collabRes] = await Promise.all([
        supabase.from("collaborateur_workflow_managers" as any)
          .select("*").eq("collaborateur_id", collaborateurId).limit(1),
        supabase.from("collaborateurs")
          .select("id, nom, prenom, matricule")
          .eq("archive", false)
          .neq("id", collaborateurId)
          .order("nom"),
      ]);
      const wf = (wfRes.data as any[])?.[0];
      if (wf) {
        setExistingId(wf.id);
        setManagerN1(wf.manager_n1_id);
        setManagerN2(wf.manager_n2_id);
        setActif(wf.actif);
        setCommentaire(wf.commentaire || "");
      }
      setCollabs((collabRes.data as CollabOption[]) || []);
      setLoading(false);
    };
    loadAll();
  }, [collaborateurId]);

  const save = async () => {
    setSaving(true);
    const payload: any = {
      collaborateur_id: collaborateurId,
      manager_n1_id: managerN1 || null,
      manager_n2_id: managerN2 || null,
      actif,
      commentaire: commentaire || null,
      updated_at: new Date().toISOString(),
    };

    if (existingId) {
      const { error } = await supabase.from("collaborateur_workflow_managers" as any)
        .update(payload).eq("id", existingId);
      if (error) { toast.error(error.message); setSaving(false); return; }
    } else {
      const data = []; const error = null; // Supabase desactive
      if (error) { toast.error(error.message); setSaving(false); return; }
      setExistingId((data as any[])?.[0]?.id || null);
    }
    toast.success("Forçage workflow enregistré");
    setSaving(false);
  };

  const labelStyle: React.CSSProperties = { fontSize: 11, fontWeight: 600, color: "hsl(var(--muted-foreground))", marginBottom: 2 };
  const inputStyle: React.CSSProperties = {
    width: "100%", padding: "6px 10px", borderRadius: 8, fontSize: 13,
    border: "1px solid hsl(var(--border))", background: "hsl(var(--background))",
    color: "hsl(var(--foreground))",
  };

  const filterCollabs = (search: string) => {
    if (!search) return collabs;
    const s = search.toLowerCase();
    return collabs.filter(c =>
      `${c.nom} ${c.prenom} ${c.matricule}`.toLowerCase().includes(s)
    );
  };

  const getCollabLabel = (id: string | null) => {
    if (!id) return "";
    const c = collabs.find(c => c.id === id);
    return c ? `${c.prenom} ${c.nom} (${c.matricule})` : id;
  };

  if (loading) return <p className="text-xs text-muted-foreground py-4 text-center">Chargement…</p>;

  return (
    <div>
      <div className="flex items-center gap-3 mb-3">
        <label className="flex items-center gap-2 cursor-pointer">
          <div
            className="relative w-9 h-5 rounded-full transition-colors"
            style={{ background: actif ? "hsl(var(--accent))" : "hsl(var(--muted))" }}
            onClick={() => setActif(!actif)}
          >
            <div
              className="absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform"
              style={{ left: actif ? 18 : 2 }}
            />
          </div>
          <span className="text-xs font-semibold" style={{ color: "hsl(var(--foreground))" }}>
            {actif ? "Forçage actif" : "Forçage inactif"}
          </span>
        </label>
        <p className="text-[10px]" style={{ color: "hsl(var(--muted-foreground))" }}>
          Quand actif, les managers ci-dessous remplacent la hiérarchie UO pour le workflow de validation
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <p style={labelStyle}>Manager N+1</p>
          <select
            style={{ ...inputStyle, opacity: actif ? 1 : 0.5 }}
            disabled={!actif}
            value={managerN1 || ""}
            onChange={e => setManagerN1(e.target.value || null)}
          >
            <option value="">— Aucun —</option>
            {collabs.map(c => (
              <option key={c.id} value={c.id}>{c.prenom} {c.nom} ({c.matricule})</option>
            ))}
          </select>
          {managerN1 && (
            <p className="text-[10px] mt-1" style={{ color: "hsl(var(--accent))" }}>
              ✓ {getCollabLabel(managerN1)}
            </p>
          )}
        </div>
        <div>
          <p style={labelStyle}>Manager N+2</p>
          <select
            style={{ ...inputStyle, opacity: actif ? 1 : 0.5 }}
            disabled={!actif}
            value={managerN2 || ""}
            onChange={e => setManagerN2(e.target.value || null)}
          >
            <option value="">— Aucun —</option>
            {collabs.map(c => (
              <option key={c.id} value={c.id}>{c.prenom} {c.nom} ({c.matricule})</option>
            ))}
          </select>
          {managerN2 && (
            <p className="text-[10px] mt-1" style={{ color: "hsl(var(--accent))" }}>
              ✓ {getCollabLabel(managerN2)}
            </p>
          )}
        </div>
      </div>

      <div className="mt-3">
        <p style={labelStyle}>Commentaire</p>
        <textarea
          style={{ ...inputStyle, minHeight: 50, opacity: actif ? 1 : 0.5 }}
          disabled={!actif}
          value={commentaire}
          onChange={e => setCommentaire(e.target.value)}
          placeholder="Raison du forçage…"
        />
      </div>

      <div className="flex justify-end mt-3">
        <Button size="sm" onClick={save} disabled={saving}>
          <Save size={13} className="mr-1" />{saving ? "Enregistrement…" : "Enregistrer"}
        </Button>
      </div>
    </div>
  );
};

export default WorkflowManagerForm;
