import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

// =====================================================
// Hook : useManagerPopulation
// RG-MGR-POP-01 (Adil DAIA) :
//   La population gérée par un manager comprend les collaborateurs
//   affectés aux UOs dont il est responsable, de 3 façons :
//   1. Via unites_organisationnelles.responsable_id = son collaborateur_id
//   2. Via unites_organisationnelles.poste_responsable_code = son code_poste actif
//   3. Via les UOs subalternes (hiérarchie descendante récursive)
// =====================================================

interface UseManagerPopulationResult {
  collaborateurIds: string[];
  uoIds: string[];
  loading: boolean;
}

export function useManagerPopulation(): UseManagerPopulationResult {
  const { user, role } = useAuth();
  const [collaborateurIds, setCollaborateurIds] = useState<string[]>([]);
  const [uoIds, setUoIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || role !== "manager") {
      setLoading(false);
      return;
    }
    loadPopulation();
  }, [user?.id, role]);

  const loadPopulation = async () => {
    if (!user) return;
    setLoading(true);

    try {
      // 1. Récupérer collaborateur_id depuis le profil
      const { data: profile } = await supabase
        .from("profiles")
        .select("collaborateur_id, email")
        .eq("user_id", user.id)
        .maybeSingle();

      let collaborateurId = (profile as any)?.collaborateur_id as string | null;

      // Fallback : chercher via l'email professionnel
      if (!collaborateurId && (profile as any)?.email) {
        const { data: collabByEmail } = await supabase
          .from("collaborateurs")
          .select("id")
          .eq("email_professionnel", (profile as any).email)
          .maybeSingle();

        collaborateurId = (collabByEmail as any)?.id ?? null;

        if (collaborateurId) {
          await supabase
            .from("profiles")
            .update({ collaborateur_id: collaborateurId } as any)
            .eq("user_id", user.id);
        }
      }

      if (!collaborateurId) {
        console.warn("[useManagerPopulation] Aucun collaborateur lié à cet utilisateur manager");
        setCollaborateurIds([]);
        setUoIds([]);
        return;
      }

      // 2a. UOs dont ce collaborateur est directement responsable_id
      const { data: uosDirectes } = await supabase
        .from("unites_organisationnelles" as never)
        .select("id")
        .eq("responsable_id" as never, collaborateurId)
        .eq("actif" as never, true);

      // 2b. Postes actifs de ce collaborateur (date_fin_uo IS NULL ou >= today)
      const today = new Date().toISOString().slice(0, 10);
      const { data: affectationsManager } = await supabase
        .from("collaborateur_affectations")
        .select("code_poste, unite_id")
        .eq("collaborateur_id", collaborateurId)
        .eq("archive", false)
        .or(`date_fin_uo.is.null,date_fin_uo.gte.${today}`);

      const postesManager = [...new Set(
        ((affectationsManager || []) as any[])
          .map((a: any) => a.code_poste)
          .filter(Boolean)
      )];

      // 2c. UOs dont le poste_responsable_code correspond à un poste du manager
      let uosViaPoste: any[] = [];
      if (postesManager.length > 0) {
        const { data: uosPoste } = await supabase
          .from("unites_organisationnelles" as never)
          .select("id")
          .in("poste_responsable_code" as never, postesManager)
          .eq("actif" as never, true);
        uosViaPoste = (uosPoste || []) as any[];
      }

      const directUoIds = [
        ...new Set([
          ...((uosDirectes || []) as any[]).map((u: any) => u.id),
          ...uosViaPoste.map((u: any) => u.id),
        ])
      ];

      console.log("[useManagerPopulation] collaborateurId:", collaborateurId);
      console.log("[useManagerPopulation] postesManager:", postesManager);
      console.log("[useManagerPopulation] UOs directes:", directUoIds.length, directUoIds);

      if (directUoIds.length === 0) {
        // Dernier recours : l'utilisateur voit au moins lui-même
        setCollaborateurIds([collaborateurId]);
        setUoIds([]);
        return;
      }

      // 3. Descendre récursivement dans la hiérarchie UO
      const allUoIds = await getUoSubtree(directUoIds);
      console.log("[useManagerPopulation] Toutes les UOs (arbre):", allUoIds.length, allUoIds);

      // 4. Affectations actives
      const [{ data: affNulles }, { data: affActives }] = await Promise.all([
        supabase
          .from("collaborateur_affectations")
          .select("collaborateur_id")
          .in("unite_id", allUoIds)
          .eq("archive", false)
          .is("date_fin_uo", null),
        supabase
          .from("collaborateur_affectations")
          .select("collaborateur_id")
          .in("unite_id", allUoIds)
          .eq("archive", false)
          .gte("date_fin_uo" as never, today),
      ]);

      const collabIds = [
        ...new Set([
          ...((affNulles || []) as any[]).map((a: any) => a.collaborateur_id),
          ...((affActives || []) as any[]).map((a: any) => a.collaborateur_id),
        ].filter(Boolean)),
      ];

      console.log("[useManagerPopulation] Population finale:", collabIds.length, collabIds);

      setUoIds(allUoIds);
      setCollaborateurIds(collabIds);
    } catch (err) {
      console.error("[useManagerPopulation] Erreur:", err);
      setCollaborateurIds([]);
      setUoIds([]);
    } finally {
      setLoading(false);
    }
  };

  return { collaborateurIds, uoIds, loading };
}

// Parcours récursif de l'arbre UO
async function getUoSubtree(rootIds: string[]): Promise<string[]> {
  const visited = new Set<string>(rootIds);
  const toProcess = [...rootIds];

  while (toProcess.length > 0) {
    const current = toProcess.splice(0, toProcess.length);
    const { data: children } = await supabase
      .from("unites_organisationnelles" as never)
      .select("id")
      .in("parent_id" as never, current)
      .eq("actif" as never, true);

    for (const child of (children || []) as any[]) {
      if (!visited.has(child.id)) {
        visited.add(child.id);
        toProcess.push(child.id);
      }
    }
  }

  return Array.from(visited);
}
