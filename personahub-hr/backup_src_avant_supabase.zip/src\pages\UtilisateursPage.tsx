import React, { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Search, Shield, Mail, User, X, Plus, Check, UserPlus, Send,
  KeyRound, Eye, EyeOff, LayoutDashboard, Users, Calculator,
  Briefcase, UserCircle, Building2
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

type AppRole = "administrateur" | "gestionnaire_rh" | "gestionnaire_paie" | "manager" | "collaborateur";

const ROLES: { value: AppRole; label: string; color: string }[] = [
  { value: "administrateur",    label: "Administrateur",   color: "hsl(213 73% 16%)" },
  { value: "gestionnaire_rh",   label: "Gestionnaire RH",  color: "hsl(197 100% 42%)" },
  { value: "gestionnaire_paie", label: "Gestionnaire Paie", color: "hsl(84 55% 45%)" },
  { value: "manager",           label: "Manager",          color: "hsl(39 95% 50%)" },
  { value: "collaborateur",     label: "Collaborateur",    color: "hsl(215 20% 55%)" },
];

// Workspace mapping per role
const WORKSPACE_MAP: Record<AppRole, { label: string; icon: React.ReactNode; color: string }[]> = {
  administrateur: [
    { label: "Administration",  icon: <LayoutDashboard size={9} />, color: "hsl(213 73% 16%)" },
    { label: "RH",              icon: <Users size={9} />,           color: "hsl(197 100% 42%)" },
    { label: "Paie",            icon: <Calculator size={9} />,      color: "hsl(84 55% 45%)" },
    { label: "Manager",         icon: <Briefcase size={9} />,       color: "hsl(39 95% 50%)" },
    { label: "Collaborateur",   icon: <UserCircle size={9} />,      color: "hsl(215 20% 55%)" },
  ],
  gestionnaire_rh: [
    { label: "RH",              icon: <Users size={9} />,           color: "hsl(197 100% 42%)" },
    { label: "Collaborateur",   icon: <UserCircle size={9} />,      color: "hsl(215 20% 55%)" },
  ],
  gestionnaire_paie: [
    { label: "Paie",            icon: <Calculator size={9} />,      color: "hsl(84 55% 45%)" },
    { label: "Collaborateur",   icon: <UserCircle size={9} />,      color: "hsl(215 20% 55%)" },
  ],
  manager: [
    { label: "Manager",         icon: <Briefcase size={9} />,       color: "hsl(39 95% 50%)" },
    { label: "Collaborateur",   icon: <UserCircle size={9} />,      color: "hsl(215 20% 55%)" },
  ],
  collaborateur: [
    { label: "Collaborateur",   icon: <UserCircle size={9} />,      color: "hsl(215 20% 55%)" },
  ],
};

interface UserRow {
  user_id: string;
  email: string;
  prenom: string;
  nom: string;
  poste: string;
  roles: AppRole[];
  created_at: string;
}

interface CollaborateurSansCompte {
  id: string;
  matricule: string;
  nom: string;
  prenom: string;
  email_professionnel: string | null;
  email_personnel: string | null;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function getWorkspaces(roles: AppRole[]) {
  const hierarchy: AppRole[] = ["administrateur","gestionnaire_rh","gestionnaire_paie","manager","collaborateur"];
  const dominated = hierarchy.find(r => roles.includes(r));
  if (!dominated) return [];
  // Admin gets all, others get their own set; deduplicate by label
  const all = roles.flatMap(r => WORKSPACE_MAP[r] ?? []);
  const seen = new Set<string>();
  return all.filter(w => {
    if (seen.has(w.label)) return false;
    seen.add(w.label);
    return true;
  });
}

// ── Role Badge ────────────────────────────────────────────────────────────────
const RoleBadge: React.FC<{
  role: AppRole;
  onRemove?: () => void;
  removing?: boolean;
}> = ({ role, onRemove, removing }) => {
  const info = ROLES.find(r => r.value === role);
  if (!info) return null;
  return (
    <span
      className="inline-flex items-center gap-1 pl-2 pr-1 py-0.5 rounded-full text-xs font-medium"
      style={{ background: `${info.color}20`, color: info.color, border: `1px solid ${info.color}40` }}
    >
      <Shield size={9} />
      {info.label}
      {onRemove && (
        <button
          onClick={onRemove}
          disabled={removing}
          className="ml-0.5 rounded-full p-0.5 transition-colors hover:opacity-70"
          style={{ color: info.color }}
          title="Supprimer ce rôle"
        >
          {removing ? (
            <div className="w-2.5 h-2.5 rounded-full border border-t-transparent animate-spin" style={{ borderColor: info.color, borderTopColor: "transparent" }} />
          ) : (
            <X size={9} />
          )}
        </button>
      )}
    </span>
  );
};

// ── Workspace Badge ───────────────────────────────────────────────────────────
const WorkspaceBadge: React.FC<{ label: string; icon: React.ReactNode; color: string }> = ({ label, icon, color }) => (
  <span
    className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-xs font-medium"
    style={{ background: `${color}15`, color, border: `1px solid ${color}30` }}
  >
    {icon}
    {label}
  </span>
);

// ── Add Role Dropdown ─────────────────────────────────────────────────────────
const AddRoleDropdown: React.FC<{
  userId: string;
  currentRoles: AppRole[];
  onAdded: () => void;
}> = ({ userId, currentRoles, onAdded }) => {
  const [open, setOpen] = useState(false);
  const [adding, setAdding] = useState<AppRole | null>(null);
  const ref = useRef<HTMLDivElement>(null);
  const available = ROLES.filter(r => !currentRoles.includes(r.value));

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  if (available.length === 0) return null;

  const handleAdd = async (role: AppRole) => {
    setAdding(role);
    await supabase.from("user_roles").insert({ user_id: userId, role });
    setAdding(null);
    setOpen(false);
    onAdded();
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(v => !v)}
        className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-xs font-medium border transition-all hover:opacity-80"
        style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground))", background: "hsl(var(--muted))" }}
        title="Ajouter un rôle"
      >
        <Plus size={10} /> Rôle
      </button>
      {open && (
        <div
          className="absolute z-50 top-full left-0 mt-1 rounded-lg shadow-lg border py-1 min-w-[170px]"
          style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}
        >
          {available.map(r => (
            <button
              key={r.value}
              onClick={() => handleAdd(r.value)}
              disabled={!!adding}
              className="w-full flex items-center gap-2 px-3 py-1.5 text-xs hover:bg-muted/50 transition-colors text-left"
              style={{ color: r.color }}
            >
              {adding === r.value ? (
                <div className="w-3 h-3 rounded-full border border-t-transparent animate-spin" style={{ borderColor: r.color, borderTopColor: "transparent" }} />
              ) : (
                <Shield size={10} />
              )}
              {r.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

// ── Change Password Dialog ────────────────────────────────────────────────────
const ChangePasswordDialog: React.FC<{
  user: UserRow | null;
  onClose: () => void;
}> = ({ user, onClose }) => {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);

  if (!user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) { toast.error("Le mot de passe doit contenir au moins 8 caractères"); return; }
    if (password !== confirm) { toast.error("Les mots de passe ne correspondent pas"); return; }
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke("change-user-password", {
        body: { target_user_id: user.user_id, new_password: password },
      });
      if (error) throw new Error(error.message);
      toast.success(`Mot de passe modifié pour ${user.prenom} ${user.nom}`);
      onClose();
    } catch (err: any) {
      toast.error(`Erreur : ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div
        className="relative rounded-xl shadow-2xl w-full max-w-sm mx-4"
        style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b" style={{ borderColor: "hsl(var(--border))" }}>
          <div>
            <h2 className="font-semibold text-base" style={{ color: "hsl(var(--foreground))" }}>
              Changer le mot de passe
            </h2>
            <p className="text-xs mt-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>
              {user.prenom} {user.nom} · {user.email}
            </p>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 hover:bg-muted/50 transition-colors" style={{ color: "hsl(var(--muted-foreground))" }}>
            <X size={16} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="text-xs font-medium mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
              Nouveau mot de passe
            </label>
            <div className="relative">
              <input
                type={showPwd ? "text" : "password"}
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Min. 8 caractères"
                required
                className="w-full pr-9 pl-3 py-2 rounded-lg text-sm border outline-none"
                style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted))", color: "hsl(var(--foreground))" }}
              />
              <button
                type="button"
                onClick={() => setShowPwd(v => !v)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2"
                style={{ color: "hsl(var(--muted-foreground))" }}
              >
                {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>

          <div>
            <label className="text-xs font-medium mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
              Confirmer le mot de passe
            </label>
            <input
              type={showPwd ? "text" : "password"}
              value={confirm}
              onChange={e => setConfirm(e.target.value)}
              placeholder="Répéter le mot de passe"
              required
              className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
              style={{
                borderColor: confirm && confirm !== password ? "hsl(0 84% 60%)" : "hsl(var(--border))",
                background: "hsl(var(--muted))",
                color: "hsl(var(--foreground))"
              }}
            />
            {confirm && confirm !== password && (
              <p className="text-xs mt-1" style={{ color: "hsl(0 84% 60%)" }}>Les mots de passe ne correspondent pas</p>
            )}
          </div>

          {/* Strength indicator */}
          {password.length > 0 && (
            <div className="space-y-1">
              <div className="flex gap-1">
                {[...Array(4)].map((_, i) => {
                  const strength = password.length >= 12 ? 4 : password.length >= 10 ? 3 : password.length >= 8 ? 2 : 1;
                  const colors = ["hsl(0 84% 60%)", "hsl(39 95% 50%)", "hsl(197 100% 42%)", "hsl(84 55% 45%)"];
                  return (
                    <div key={i} className="h-1 flex-1 rounded-full transition-all"
                      style={{ background: i < strength ? colors[strength - 1] : "hsl(var(--border))" }} />
                  );
                })}
              </div>
              <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                {password.length < 8 ? "Trop court" : password.length < 10 ? "Faible" : password.length < 12 ? "Moyen" : "Fort"}
              </p>
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 rounded-lg text-sm font-medium border transition-all hover:bg-muted/50"
              style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--foreground))" }}
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || password.length < 8 || password !== confirm}
              className="flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              style={{ background: "hsl(var(--accent))", color: "white" }}
            >
              {loading ? (
                <div className="w-4 h-4 rounded-full border-2 border-t-transparent animate-spin border-white" />
              ) : (
                <><KeyRound size={13} /> Enregistrer</>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ── Invitation Dialog ─────────────────────────────────────────────────────────
const InvitationDialog: React.FC<{
  open: boolean;
  onClose: () => void;
  existingEmails: string[];
}> = ({ open, onClose, existingEmails }) => {
  const [search, setSearch] = useState("");
  const [sending, setSending] = useState<string | null>(null);
  const [sent, setSent] = useState<Set<string>>(new Set());
  const [emailOverrides, setEmailOverrides] = useState<Record<string, string>>({});

  const { data: collaborateurs = [] } = useQuery({
    queryKey: ["collaborateurs-sans-compte"],
    queryFn: async () => {
      const data = []; const error = null; // Supabase desactive
      return (data ?? []) as CollaborateurSansCompte[];
    },
    enabled: open,
  });

  const sans_compte = collaborateurs.filter(c => {
    const email = emailOverrides[c.id] ?? c.email_professionnel ?? c.email_personnel ?? "";
    return !existingEmails.includes(email.toLowerCase());
  });

  const filtered = sans_compte.filter(c =>
    `${c.prenom} ${c.nom} ${c.matricule}`.toLowerCase().includes(search.toLowerCase())
  );

  const handleInvite = async (collab: CollaborateurSansCompte) => {
    const email = emailOverrides[collab.id] ?? collab.email_professionnel ?? collab.email_personnel ?? "";
    if (!email) { toast.error(`Aucun email défini pour ${collab.prenom} ${collab.nom}`); return; }
    setSending(collab.id);
    try {
      const { error } = await supabase.functions.invoke("invite-user", {
        body: { email, prenom: collab.prenom, nom: collab.nom },
      });
      if (error) throw new Error(error.message);
      setSent(prev => new Set([...prev, collab.id]));
      toast.success(`Invitation envoyée à ${email}`);
    } catch (err: any) {
      toast.error(`Erreur : ${err.message}`);
    } finally {
      setSending(null);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div
        className="relative rounded-xl shadow-2xl w-full max-w-lg mx-4 flex flex-col max-h-[80vh]"
        style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}
      >
        <div className="flex items-center justify-between p-5 border-b" style={{ borderColor: "hsl(var(--border))" }}>
          <div>
            <h2 className="font-semibold text-base" style={{ color: "hsl(var(--foreground))" }}>Inviter des collaborateurs</h2>
            <p className="text-xs mt-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>{sans_compte.length} collaborateur(s) sans compte</p>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 hover:bg-muted/50 transition-colors" style={{ color: "hsl(var(--muted-foreground))" }}>
            <X size={16} />
          </button>
        </div>

        <div className="p-4 border-b" style={{ borderColor: "hsl(var(--border))" }}>
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "hsl(var(--muted-foreground))" }} />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Rechercher un collaborateur…"
              className="pl-9 pr-4 py-2 rounded-lg text-sm border outline-none w-full"
              style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted))", color: "hsl(var(--foreground))" }}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 gap-2">
              <Check size={32} style={{ color: "hsl(var(--accent))" }} />
              <p className="text-sm font-medium" style={{ color: "hsl(var(--foreground))" }}>
                {sans_compte.length === 0 ? "Tous les collaborateurs ont déjà un compte" : "Aucun résultat"}
              </p>
            </div>
          ) : filtered.map(c => {
            const emailKey = emailOverrides[c.id] ?? c.email_professionnel ?? c.email_personnel ?? "";
            const isSent = sent.has(c.id);
            const isSending = sending === c.id;
            return (
              <div key={c.id} className="flex items-center gap-3 px-4 py-3 border-b hover:bg-muted/20 transition-colors" style={{ borderColor: "hsl(var(--border))" }}>
                <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                  style={{ background: "hsl(var(--accent) / 0.15)", color: "hsl(var(--accent))" }}>
                  {c.prenom?.[0]?.toUpperCase() ?? <User size={14} />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate" style={{ color: "hsl(var(--foreground))" }}>
                    {c.prenom} {c.nom}
                    <span className="ml-1.5 text-xs font-normal" style={{ color: "hsl(var(--muted-foreground))" }}>{c.matricule}</span>
                  </p>
                  {emailKey ? (
                    <p className="text-xs truncate" style={{ color: "hsl(var(--muted-foreground))" }}>{emailKey}</p>
                  ) : (
                    <input
                      type="email"
                      placeholder="Saisir un email…"
                      value={emailOverrides[c.id] ?? ""}
                      onChange={e => setEmailOverrides(prev => ({ ...prev, [c.id]: e.target.value }))}
                      className="text-xs border rounded px-2 py-0.5 w-full outline-none mt-0.5"
                      style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--foreground))", background: "hsl(var(--muted))" }}
                      onClick={e => e.stopPropagation()}
                    />
                  )}
                </div>
                {isSent ? (
                  <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full"
                    style={{ background: "hsl(84 55% 45% / 0.15)", color: "hsl(84 55% 45%)" }}>
                    <Check size={11} /> Envoyé
                  </span>
                ) : (
                  <button
                    onClick={() => handleInvite(c)}
                    disabled={isSending || (!emailKey && !emailOverrides[c.id])}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all disabled:opacity-50"
                    style={{ background: "hsl(var(--accent))", color: "white" }}
                  >
                    {isSending ? <div className="w-3 h-3 rounded-full border border-t-transparent animate-spin border-white" /> : <Send size={11} />}
                    Inviter
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <div className="p-4 border-t flex justify-end" style={{ borderColor: "hsl(var(--border))" }}>
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm font-medium border transition-all hover:bg-muted/50"
            style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--foreground))" }}>
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};

// ── Main page ─────────────────────────────────────────────────────────────────
const UtilisateursPage: React.FC = () => {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState<AppRole | "all">("all");
  const [removingRole, setRemovingRole] = useState<{ userId: string; role: AppRole } | null>(null);
  const [showInvite, setShowInvite] = useState(false);
  const [changePwdUser, setChangePwdUser] = useState<UserRow | null>(null);

  const loadUsers = async () => {
    setLoading(true);
    const data = []; const error = null; // Supabase desactive
    const data = []; const error = null; // Supabase desactive
    if (profiles) {
      const merged: UserRow[] = profiles.map(p => ({
        user_id: p.user_id,
        email: p.email || "",
        prenom: p.prenom || "",
        nom: p.nom || "",
        poste: p.poste || "",
        roles: (rolesData?.filter(r => r.user_id === p.user_id).map(r => r.role as AppRole)) || ["collaborateur"],
        created_at: p.created_at,
      }));
      setUsers(merged);
    }
    setLoading(false);
  };

  useEffect(() => { loadUsers(); }, []);

  const handleRemoveRole = async (userId: string, role: AppRole, currentRoles: AppRole[]) => {
    if (currentRoles.length <= 1) return;
    setRemovingRole({ userId, role });
    await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
    setRemovingRole(null);
    loadUsers();
  };

  const filtered = users.filter(u => {
    const matchSearch = `${u.prenom} ${u.nom} ${u.email}`.toLowerCase().includes(search.toLowerCase());
    const matchRole = filterRole === "all" || u.roles.includes(filterRole);
    return matchSearch && matchRole;
  });

  const existingEmails = users.map(u => u.email.toLowerCase()).filter(Boolean);

  return (
    <div className="p-6">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="page-title">Gestion des Utilisateurs</h1>
            <p className="page-subtitle">{users.length} utilisateur(s) enregistré(s)</p>
          </div>
          <button
            onClick={() => setShowInvite(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all"
            style={{ background: "hsl(var(--accent))", color: "white" }}
          >
            <UserPlus size={15} />
            Inviter un collaborateur
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-5 flex-wrap">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "hsl(var(--muted-foreground))" }} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher un utilisateur…"
            className="pl-9 pr-4 py-2 rounded-lg text-sm border outline-none w-64"
            style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--card))", color: "hsl(var(--foreground))" }}
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {[{ value: "all", label: "Tous", color: "hsl(var(--muted-foreground))" }, ...ROLES].map(r => (
            <button
              key={r.value}
              onClick={() => setFilterRole(r.value as AppRole | "all")}
              className="px-3 py-1.5 rounded-lg text-xs font-medium border transition-all"
              style={{
                background: filterRole === r.value ? r.color : "transparent",
                borderColor: filterRole === r.value ? r.color : "hsl(var(--border))",
                color: filterRole === r.value ? "white" : "hsl(var(--foreground))",
              }}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl overflow-hidden" style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", boxShadow: "var(--shadow-md)" }}>
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <div className="w-6 h-6 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: "hsl(var(--accent))", borderTopColor: "transparent" }} />
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: "hsl(var(--muted))", borderBottom: "1px solid hsl(var(--border))" }}>
                <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "hsl(var(--muted-foreground))" }}>Utilisateur</th>
                <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "hsl(var(--muted-foreground))" }}>Email</th>
                <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "hsl(var(--muted-foreground))" }}>Rôles</th>
                <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "hsl(var(--muted-foreground))" }}>Espaces de travail</th>
                <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "hsl(var(--muted-foreground))" }}>Depuis</th>
                <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "hsl(var(--muted-foreground))" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>
                    Aucun utilisateur trouvé
                  </td>
                </tr>
              ) : filtered.map(u => {
                const primaryRole = ROLES.find(r => r.value === u.roles[0]);
                const workspaces = getWorkspaces(u.roles);
                return (
                  <tr key={u.user_id} className="border-b hover:bg-muted/20 transition-all" style={{ borderColor: "hsl(var(--border))" }}>
                    {/* Utilisateur */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                          style={{ background: `${primaryRole?.color}20`, color: primaryRole?.color }}>
                          {u.prenom?.[0]?.toUpperCase() || <User size={12} />}
                        </div>
                        <div>
                          <p className="font-medium">{u.prenom} {u.nom}</p>
                          {u.poste && <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{u.poste}</p>}
                          {u.user_id === currentUser?.id && (
                            <span className="text-xs" style={{ color: "hsl(var(--accent))" }}>(moi)</span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Email */}
                    <td className="py-3 px-4" style={{ color: "hsl(var(--muted-foreground))" }}>
                      <div className="flex items-center gap-1.5"><Mail size={12} />{u.email}</div>
                    </td>

                    {/* Rôles */}
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {u.roles.map(role => (
                          <RoleBadge
                            key={role}
                            role={role}
                            onRemove={u.roles.length > 1 ? () => handleRemoveRole(u.user_id, role, u.roles) : undefined}
                            removing={removingRole?.userId === u.user_id && removingRole?.role === role}
                          />
                        ))}
                        <AddRoleDropdown userId={u.user_id} currentRoles={u.roles} onAdded={loadUsers} />
                      </div>
                    </td>

                    {/* Espaces de travail */}
                    <td className="py-3 px-4">
                      <div className="flex flex-wrap gap-1">
                        {workspaces.map(ws => (
                          <WorkspaceBadge key={ws.label} label={ws.label} icon={ws.icon} color={ws.color} />
                        ))}
                      </div>
                    </td>

                    {/* Depuis */}
                    <td className="py-3 px-4 text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                      {new Date(u.created_at).toLocaleDateString("fr-FR")}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4">
                      <button
                        onClick={() => setChangePwdUser(u)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-all hover:bg-muted/50"
                        style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground))" }}
                        title="Changer le mot de passe"
                      >
                        <KeyRound size={12} />
                        Mot de passe
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Dialogs */}
      <InvitationDialog open={showInvite} onClose={() => setShowInvite(false)} existingEmails={existingEmails} />
      <ChangePasswordDialog user={changePwdUser} onClose={() => setChangePwdUser(null)} />
    </div>
  );
};

export default UtilisateursPage;
