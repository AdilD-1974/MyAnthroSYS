import React, { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { useManagerPopulation } from "@/hooks/useManagerPopulation";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import {
  Search, TrendingUp, AlertTriangle, BarChart3,
  RefreshCw, List,
} from "lucide-react";

const EXERCICE_COURANT = new Date().getFullYear();

interface SoldeItem {
  id: string;
  collaborateur_id: string;
  code_type_conge: string;
  exercice: number;
  solde_acquis: number;
  solde_pris: number;
  solde_en_attente: number;
  reliquat_reporte: number;
  solde_restant: number;
  collaborateurs?: { nom: string; prenom: string; matricule: string; statut_collaborateur: string };
}

interface DrillDown {
  solde: SoldeItem;
  typeLibelle: string;
}

export default function SuiviCongesPage() {
  const { role } = useAuth();
  const isManager = role === "manager";
  const { collaborateurIds: managerCollabIds, loading: popLoading } = useManagerPopulation();

  const [search, setSearch] = useState("");
  const [filterExercice, setFilterExercice] = useState(String(EXERCICE_COURANT));
  const [filterType, setFilterType] = useState("ALL");
  const [drillDown, setDrillDown] = useState<DrillDown | null>(null);

  const exercices = Array.from({ length: 5 }, (_, i) => String(EXERCICE_COURANT - 2 + i));

  const { data: typesConge = [] } = useQuery({
    queryKey: ["ref-type-conge-actifs"],
    queryFn: async () => {
      const data = []; const error = null; // Supabase desactive
      return data || [];
    },
  });

  const { data: soldes = [], isLoading: soldesLoading } = useQuery({
    queryKey: ["cong-suivi-soldes", filterExercice, filterType, search, managerCollabIds, isManager],
    enabled: !isManager || !popLoading,
    queryFn: async () => {
      let q = supabase
        .from("cong_solde")
        .select("*, collaborateurs(nom, prenom, matricule, statut_collaborateur)")
        .eq("exercice", Number(filterExercice))
        .eq("archive", false);
      if (filterType !== "ALL") q = q.eq("code_type_conge", filterType);
      if (isManager) {
        if (managerCollabIds.length === 0) return [];
        q = q.in("collaborateur_id", managerCollabIds);
      }
      const { data, error } = await q.order("collaborateur_id");
      if (error) throw error;
      return (data || []).filter((s: any) => {
        if (!search) return true;
        const c = s.collaborateurs;
        const t = search.toLowerCase();
        return c?.nom?.toLowerCase().includes(t) || c?.prenom?.toLowerCase().includes(t) || c?.matricule?.toLowerCase().includes(t);
      });
    },
  });

  const { data: reliquats = [], isLoading: reliquatsLoading } = useQuery({
    queryKey: ["cong-reliquats", filterExercice, managerCollabIds, isManager],
    enabled: !isManager || !popLoading,
    queryFn: async () => {
      let q = supabase
        .from("cong_reliquat")
        .select("*, collaborateurs(nom, prenom, matricule)")
        .eq("exercice_report", Number(filterExercice))
        .eq("archive", false)
        .order("date_butoir");
      if (isManager) {
        if (managerCollabIds.length === 0) return [];
        q = q.in("collaborateur_id", managerCollabIds);
      }
      const { data, error } = await q;
      if (error) throw error;
      return data || [];
    },
  });

  const { data: consommations = [], isLoading: consoLoading } = useQuery({
    queryKey: ["cong-consommations-suivi", filterExercice, filterType, search, managerCollabIds, isManager],
    enabled: !isManager || !popLoading,
    queryFn: async () => {
      let q = supabase
        .from("cong_consommation")
        .select("*, collaborateurs(nom, prenom, matricule)")
        .eq("exercice", Number(filterExercice))
        .eq("est_annulee", false)
        .eq("archive", false);
      if (filterType !== "ALL") q = q.eq("code_type_conge", filterType);
      if (isManager) {
        if (managerCollabIds.length === 0) return [];
        q = q.in("collaborateur_id", managerCollabIds);
      }
      const { data, error } = await q.order("date_debut", { ascending: false });
      if (error) throw error;
      return (data || []).filter((c: any) => {
        if (!search) return true;
        const col = c.collaborateurs;
        const t = search.toLowerCase();
        return col?.nom?.toLowerCase().includes(t) || col?.prenom?.toLowerCase().includes(t) || col?.matricule?.toLowerCase().includes(t);
      });
    },
  });

  // Drill-down : demandes liées à un compteur spécifique
  const { data: drillDemandes = [], isLoading: drillLoading } = useQuery({
    queryKey: ["cong-drill-demandes", drillDown?.solde.collaborateur_id, drillDown?.solde.code_type_conge, drillDown?.solde.exercice],
    enabled: !!drillDown,
    queryFn: async () => {
      if (!drillDown) return [];
      const data = []; const error = null; // Supabase desactive
      if (error) throw error;
      return data || [];
    },
  });

  const getTypeLibelle = (code: string) => (typesConge as any[]).find(t => t.code === code)?.libelle || code;

  const totalCollabs = new Set(soldes.map((s: any) => s.collaborateur_id)).size;
  const soldeMoyen = soldes.length ? (soldes.reduce((acc: number, s: any) => acc + Number(s.solde_restant), 0) / soldes.length).toFixed(1) : "0";
  const reliquatsActifs = reliquats.filter((r: any) => r.statut === "ACTIF").length;
  const reliquatsExpires = reliquats.filter((r: any) => {
    const b = new Date(r.date_butoir);
    return r.statut === "ACTIF" && b <= new Date();
  }).length;

  const getReliquatColor = (r: any) => {
    const daysLeft = Math.ceil((new Date(r.date_butoir).getTime() - Date.now()) / 86400000);
    if (daysLeft < 0) return "hsl(0 72% 51%)";
    if (daysLeft < 30) return "hsl(38 92% 50%)";
    return "hsl(142 71% 45%)";
  };

  const getStatutDemandeColor = (statut: string) => {
    switch (statut) {
      case "APPROUVEE": return { bg: "hsl(142 71% 45%/0.1)", color: "hsl(142 71% 45%)" };
      case "EN_ATTENTE": return { bg: "hsl(38 92% 50%/0.1)", color: "hsl(38 92% 50%)" };
      case "BROUILLON": return { bg: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" };
      case "REFUSEE": return { bg: "hsl(0 72% 51%/0.1)", color: "hsl(0 72% 51%)" };
      case "ANNULEE": return { bg: "hsl(0 72% 51%/0.1)", color: "hsl(0 72% 51%)" };
      default: return { bg: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" };
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold" style={{ color: "hsl(var(--foreground))" }}>Suivi des Congés</h1>
        <p className="text-sm mt-1" style={{ color: "hsl(var(--muted-foreground))" }}>
          Vue consolidée des soldes, consommations et reliquats
        </p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Collaborateurs suivis", value: totalCollabs, icon: <BarChart3 size={18} />, color: "hsl(var(--primary))" },
          { label: "Solde moyen restant", value: `${soldeMoyen} j`, icon: <TrendingUp size={18} />, color: "hsl(142 71% 45%)" },
          { label: "Reliquats actifs", value: reliquatsActifs, icon: <RefreshCw size={18} />, color: "hsl(38 92% 50%)" },
          { label: "Reliquats expirés/à risque", value: reliquatsExpires, icon: <AlertTriangle size={18} />, color: "hsl(0 72% 51%)" },
        ].map(k => (
          <Card key={k.label}>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 rounded-lg" style={{ background: `${k.color}20`, color: k.color }}>{k.icon}</div>
              <div>
                <p className="text-2xl font-bold" style={{ color: "hsl(var(--foreground))" }}>{k.value}</p>
                <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{k.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filtres */}
      <Card>
        <CardContent className="p-4 flex gap-3 flex-wrap">
          <div className="relative flex-1 min-w-48">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "hsl(var(--muted-foreground))" }} />
            <Input placeholder="Rechercher un collaborateur…" className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Select value={filterExercice} onValueChange={setFilterExercice}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>{exercices.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Type de congé" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Tous les types</SelectItem>
              {(typesConge as any[]).map((t: any) => <SelectItem key={t.code} value={t.code}>{t.libelle}</SelectItem>)}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Tabs defaultValue="soldes">
        <TabsList>
          <TabsTrigger value="soldes">Soldes ({soldes.length})</TabsTrigger>
          <TabsTrigger value="reliquats">Reliquats ({reliquats.length})</TabsTrigger>
          <TabsTrigger value="consommations">Historique ({consommations.length})</TabsTrigger>
        </TabsList>

        {/* ─── Soldes ─── */}
        <TabsContent value="soldes">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Collaborateur</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Acquis</TableHead>
                    <TableHead className="text-right">Pris</TableHead>
                    <TableHead className="text-right">En attente</TableHead>
                    <TableHead className="text-right">Reliquat</TableHead>
                    <TableHead className="text-right">Restant</TableHead>
                    <TableHead className="min-w-32">Progression</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {soldesLoading && (
                    <TableRow><TableCell colSpan={9} className="text-center py-8">Chargement…</TableCell></TableRow>
                  )}
                  {!soldesLoading && soldes.length === 0 && (
                    <TableRow><TableCell colSpan={9} className="text-center py-8" style={{ color: "hsl(var(--muted-foreground))" }}>
                      Aucun solde
                    </TableCell></TableRow>
                  )}
                  {soldes.map((s: any) => {
                    const total = Number(s.solde_acquis) + Number(s.reliquat_reporte);
                    const pct = total > 0 ? Math.min(100, Math.round((Number(s.solde_pris) / total) * 100)) : 0;
                    const restant = Number(s.solde_restant);
                    const restantColor = restant < 0 ? "hsl(0 72% 51%)" : restant < 3 ? "hsl(38 92% 50%)" : "hsl(142 71% 45%)";
                    return (
                      <TableRow key={s.id} className="hover:bg-muted/30">
                        <TableCell>
                          <div className="font-medium">{s.collaborateurs?.nom} {s.collaborateurs?.prenom}</div>
                          <div className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{s.collaborateurs?.matricule}</div>
                        </TableCell>
                        <TableCell><Badge variant="outline" className="text-xs">{getTypeLibelle(s.code_type_conge)}</Badge></TableCell>
                        <TableCell className="text-right">{Number(s.solde_acquis).toFixed(1)}</TableCell>
                        <TableCell className="text-right">{Number(s.solde_pris).toFixed(1)}</TableCell>
                        <TableCell className="text-right">
                          {Number(s.solde_en_attente) > 0 ? <span style={{ color: "hsl(38 92% 50%)" }}>{Number(s.solde_en_attente).toFixed(1)}</span> : "—"}
                        </TableCell>
                        <TableCell className="text-right">
                          {Number(s.reliquat_reporte) > 0 ? <span style={{ color: "hsl(var(--primary))" }}>{Number(s.reliquat_reporte).toFixed(1)}</span> : "—"}
                        </TableCell>
                        <TableCell className="text-right">
                          <span className="font-bold" style={{ color: restantColor }}>{restant.toFixed(1)}</span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={pct} className="h-2 flex-1" />
                            <span className="text-xs w-8" style={{ color: "hsl(var(--muted-foreground))" }}>{pct}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            title="Voir les demandes liées"
                            onClick={() => setDrillDown({ solde: s, typeLibelle: getTypeLibelle(s.code_type_conge) })}
                          >
                            <List size={14} />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Reliquats ─── */}
        <TabsContent value="reliquats">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Collaborateur</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Exercice origine</TableHead>
                    <TableHead className="text-right">Jours reliquat</TableHead>
                    <TableHead className="text-right">Consommés</TableHead>
                    <TableHead className="text-right">Restants</TableHead>
                    <TableHead>Date butoir</TableHead>
                    <TableHead>Statut</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reliquatsLoading && (
                    <TableRow><TableCell colSpan={8} className="text-center py-8">Chargement…</TableCell></TableRow>
                  )}
                  {!reliquatsLoading && reliquats.length === 0 && (
                    <TableRow><TableCell colSpan={8} className="text-center py-8" style={{ color: "hsl(var(--muted-foreground))" }}>
                      Aucun reliquat
                    </TableCell></TableRow>
                  )}
                  {(reliquats as any[]).map((r: any) => {
                    const col = getReliquatColor(r);
                    const daysLeft = Math.ceil((new Date(r.date_butoir).getTime() - Date.now()) / 86400000);
                    const restants = Number(r.jours_reliquat) - Number(r.jours_consommes);
                    return (
                      <TableRow key={r.id}>
                        <TableCell>
                          <div className="font-medium">{r.collaborateurs?.nom} {r.collaborateurs?.prenom}</div>
                          <div className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{r.collaborateurs?.matricule}</div>
                        </TableCell>
                        <TableCell><Badge variant="outline" className="text-xs">{getTypeLibelle(r.code_type_conge)}</Badge></TableCell>
                        <TableCell>{r.exercice_origine}</TableCell>
                        <TableCell className="text-right">{Number(r.jours_reliquat).toFixed(1)}</TableCell>
                        <TableCell className="text-right">{Number(r.jours_consommes).toFixed(1)}</TableCell>
                        <TableCell className="text-right font-bold" style={{ color: col }}>{restants.toFixed(1)}</TableCell>
                        <TableCell>
                          <div style={{ color: col }}>
                            {new Date(r.date_butoir).toLocaleDateString("fr-FR")}
                            {r.statut === "ACTIF" && (
                              <div className="text-xs">
                                {daysLeft < 0 ? "Expiré" : `Dans ${daysLeft} j`}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
                            style={{ background: `${col}20`, color: col }}>
                            {r.statut}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Historique consommations ─── */}
        <TabsContent value="consommations">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Collaborateur</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Début absence</TableHead>
                    <TableHead>Retour</TableHead>
                    <TableHead className="text-right">Jours cal.</TableHead>
                    <TableHead className="text-right">Jours déduits</TableHead>
                    <TableHead>Statut</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {consoLoading && (
                    <TableRow><TableCell colSpan={7} className="text-center py-8">Chargement…</TableCell></TableRow>
                  )}
                  {!consoLoading && consommations.length === 0 && (
                    <TableRow><TableCell colSpan={7} className="text-center py-8" style={{ color: "hsl(var(--muted-foreground))" }}>
                      Aucune consommation
                    </TableCell></TableRow>
                  )}
                  {(consommations as any[]).map((c: any) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <div className="font-medium">{c.collaborateurs?.nom} {c.collaborateurs?.prenom}</div>
                        <div className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{c.collaborateurs?.matricule}</div>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="text-xs">{getTypeLibelle(c.code_type_conge)}</Badge></TableCell>
                      <TableCell>{new Date(c.date_debut).toLocaleDateString("fr-FR")}</TableCell>
                      <TableCell>{new Date(c.date_retour).toLocaleDateString("fr-FR")}</TableCell>
                      <TableCell className="text-right">{Number(c.nbr_jours_calendaires).toFixed(1)}</TableCell>
                      <TableCell className="text-right font-bold">{Number(c.nbr_jours_decomptes).toFixed(1)}</TableCell>
                      <TableCell>
                        {c.est_annulee ? (
                          <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "hsl(0 72% 51%/0.1)", color: "hsl(0 72% 51%)" }}>Annulée</span>
                        ) : (
                          <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "hsl(142 71% 45%/0.1)", color: "hsl(142 71% 45%)" }}>Validée</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ─── Sheet détail demandes par compteur ─── */}
      <Sheet open={!!drillDown} onOpenChange={open => { if (!open) setDrillDown(null); }}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          {drillDown && (
            <>
              <SheetHeader className="mb-4">
                <SheetTitle>
                  Demandes — {drillDown.solde.collaborateurs?.prenom} {drillDown.solde.collaborateurs?.nom}
                </SheetTitle>
                <div className="flex gap-2 items-center flex-wrap">
                  <Badge variant="outline">{drillDown.typeLibelle}</Badge>
                  <Badge variant="secondary">Exercice {drillDown.solde.exercice}</Badge>
                  <span className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                    {drillDown.solde.collaborateurs?.matricule}
                  </span>
                </div>

                {/* Récap solde */}
                <div className="grid grid-cols-4 gap-2 mt-3">
                  {[
                    { label: "Acquis", value: Number(drillDown.solde.solde_acquis).toFixed(1), color: "hsl(var(--foreground))" },
                    { label: "Pris", value: Number(drillDown.solde.solde_pris).toFixed(1), color: "hsl(var(--foreground))" },
                    { label: "En attente", value: Number(drillDown.solde.solde_en_attente).toFixed(1), color: "hsl(38 92% 50%)" },
                    {
                      label: "Restant",
                      value: Number(drillDown.solde.solde_restant).toFixed(1),
                      color: Number(drillDown.solde.solde_restant) < 0 ? "hsl(0 72% 51%)" : Number(drillDown.solde.solde_restant) < 3 ? "hsl(38 92% 50%)" : "hsl(142 71% 45%)",
                    },
                  ].map(k => (
                    <div key={k.label} className="rounded-lg border p-3 text-center">
                      <p className="text-lg font-bold" style={{ color: k.color }}>{k.value}</p>
                      <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{k.label}</p>
                    </div>
                  ))}
                </div>
              </SheetHeader>

              <div className="mt-2">
                <p className="text-sm font-semibold mb-2" style={{ color: "hsl(var(--foreground))" }}>
                  Historique des demandes ({drillDemandes.length})
                </p>

                {drillLoading && (
                  <p className="text-center py-8 text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>Chargement…</p>
                )}
                {!drillLoading && drillDemandes.length === 0 && (
                  <p className="text-center py-8 text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>Aucune demande pour ce compteur</p>
                )}

                <div className="space-y-2">
                  {(drillDemandes as any[]).map((d: any) => {
                    const sc = getStatutDemandeColor(d.statut);
                    return (
                      <div key={d.id} className="rounded-lg border p-3 flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-medium">
                              {new Date(d.date_debut).toLocaleDateString("fr-FR")} → {new Date(d.date_retour).toLocaleDateString("fr-FR")}
                            </span>
                            <span className="text-xs px-2 py-0.5 rounded-full"
                              style={{ background: sc.bg, color: sc.color }}>
                              {d.statut.replace("_", " ")}
                            </span>
                          </div>
                          <div className="text-xs mt-1 flex gap-4" style={{ color: "hsl(var(--muted-foreground))" }}>
                            <span>{Number(d.nbr_jours_decomptes ?? 0).toFixed(1)} j déduits</span>
                            <span>{Number(d.nbr_jours_calendaires ?? 0).toFixed(1)} j calendaires</span>
                            {d.motif_refus && <span className="text-red-500">Motif : {d.motif_refus}</span>}
                          </div>
                          {d.commentaire_collaborateur && (
                            <p className="text-xs mt-1 italic" style={{ color: "hsl(var(--muted-foreground))" }}>
                              « {d.commentaire_collaborateur} »
                            </p>
                          )}
                        </div>
                        {d.date_validation && (
                          <div className="text-xs text-right shrink-0" style={{ color: "hsl(var(--muted-foreground))" }}>
                            Validé le<br />{new Date(d.date_validation).toLocaleDateString("fr-FR")}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
