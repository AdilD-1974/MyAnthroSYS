import React, { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { ArrowRightLeft, Search, AlertCircle, ExternalLink, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import MouvementForm from "@/components/mouvement/MouvementForm";

interface MouvementRow {
  id: string;
  collaborateur_id: string;
  code_type_mouvement: string;
  date_effet: string;
  date_fin_prevue: string | null;
  date_fin_effective: string | null;
  ancien_poste: string | null;
  nouveau_poste: string | null;
  ancienne_unite_id: string | null;
  nouvelle_unite_id: string | null;
  reference_decision: string | null;
  statut: string;
  commentaire: string | null;
}

const MouvementsPage: React.FC = () => {
  const [rows, setRows] = useState<MouvementRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatut, setFilterStatut] = useState("ALL");
  const [filterType, setFilterType] = useState("ALL");
  const [collabMap, setCollabMap] = useState<Record<string, { nom: string; prenom: string; matricule: string }>>({});
  const [typeMap, setTypeMap] = useState<Record<string, { libelle: string; est_temporaire: boolean; est_definitif: boolean }>>({});
  const [uoMap, setUoMap] = useState<Record<string, string>>({});
  const navigate = useNavigate();

  const [posteMap, setPosteMap] = useState<Record<string, string>>({});
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [selectedCollabId, setSelectedCollabId] = useState<string | null>(null);
  const [collabSearch, setCollabSearch] = useState("");
  const [collabList, setCollabList] = useState<{ id: string; nom: string; prenom: string; matricule: string }[]>([]);

  const loadAll = async () => {
    setLoading(true);
    const [mvts, collabs, types, uos, postes] = await Promise.all([
      supabase.from("collaborateur_mouvements" as any).select("*").eq("archive", false).order("date_effet", { ascending: false }),
      supabase.from("collaborateurs").select("id, nom, prenom, matricule, statut_collaborateur").eq("archive", false),
      supabase.from("ref_type_mouvement" as any).select("code, libelle, est_temporaire, est_definitif"),
      supabase.from("unites_organisationnelles" as any).select("id, libelle"),
      supabase.from("ref_poste" as any).select("code, libelle"),
    ]);
    setRows((mvts.data as any[]) || []);
    const collabArr = ((collabs.data as any[]) || []).filter((c: any) => c.statut_collaborateur !== "SORTI");
    const cm: Record<string, { nom: string; prenom: string; matricule: string }> = {};
    collabArr.forEach((c: any) => { cm[c.id] = { nom: c.nom, prenom: c.prenom, matricule: c.matricule }; });
    setCollabMap(cm);
    setCollabList(collabArr.map((c: any) => ({ id: c.id, nom: c.nom, prenom: c.prenom, matricule: c.matricule })));
    const tm: Record<string, { libelle: string; est_temporaire: boolean; est_definitif: boolean }> = {};
    ((types.data as any[]) || []).forEach((t: any) => { tm[t.code] = { libelle: t.libelle, est_temporaire: t.est_temporaire, est_definitif: !!t.est_definitif }; });
    setTypeMap(tm);
    const um: Record<string, string> = {};
    ((uos.data as any[]) || []).forEach((u: any) => { um[u.id] = u.libelle; });
    setUoMap(um);
    const pm: Record<string, string> = {};
    ((postes.data as any[]) || []).forEach((p: any) => { pm[p.code] = p.libelle; });
    setPosteMap(pm);
    setLoading(false);
  };

  useEffect(() => { loadAll(); }, []);

  const filtered = rows.filter(r => {
    if (filterStatut !== "ALL" && r.statut !== filterStatut) return false;
    if (filterType !== "ALL" && r.code_type_mouvement !== filterType) return false;
    if (search) {
      const c = collabMap[r.collaborateur_id];
      const txt = `${c?.nom || ""} ${c?.prenom || ""} ${c?.matricule || ""} ${typeMap[r.code_type_mouvement]?.libelle || ""} ${r.nouveau_poste || ""} ${r.ancien_poste || ""}`.toLowerCase();
      if (!txt.includes(search.toLowerCase())) return false;
    }
    return true;
  });

  // Alertes temporaires
  const alertes = rows.filter(r => {
    if (r.statut !== "ACTIF" || !typeMap[r.code_type_mouvement]?.est_temporaire) return false;
    if (!r.date_fin_prevue) return true;
    const diff = (new Date(r.date_fin_prevue).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return diff <= 30;
  });

  const statutBadge = (s: string) => {
    const colors: Record<string, { bg: string; text: string }> = {
      ACTIF: { bg: "hsl(142 70% 45% / 0.12)", text: "hsl(142 70% 30%)" },
      CLOTURE: { bg: "hsl(220 15% 50% / 0.12)", text: "hsl(220 15% 40%)" },
      ANNULE: { bg: "hsl(0 70% 50% / 0.12)", text: "hsl(0 70% 35%)" },
    };
    const c = colors[s] || colors.ACTIF;
    return <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold" style={{ background: c.bg, color: c.text }}>{s}</span>;
  };

  const inputStyle: React.CSSProperties = {
    padding: "6px 10px", borderRadius: 8, fontSize: 13,
    border: "1px solid hsl(var(--border))", background: "hsl(var(--background))",
    color: "hsl(var(--foreground))",
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "hsl(var(--accent) / 0.12)" }}>
            <ArrowRightLeft size={20} style={{ color: "hsl(var(--accent))" }} />
          </div>
          <div>
            <h1 className="text-xl font-bold" style={{ color: "hsl(var(--foreground))" }}>Mouvements internes</h1>
            <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
              {filtered.length} mouvement(s) — {alertes.length} alerte(s)
            </p>
          </div>
        </div>
        <Button size="sm" onClick={() => { setShowNewDialog(true); setSelectedCollabId(null); setCollabSearch(""); }}>
          <Plus size={15} className="mr-1" /> Nouveau mouvement
        </Button>
      </div>

      {/* Dialog nouveau mouvement */}
      <Dialog open={showNewDialog} onOpenChange={(open) => { if (!open) { setShowNewDialog(false); setSelectedCollabId(null); loadAll(); } }}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Nouveau mouvement interne</DialogTitle>
          </DialogHeader>
          {!selectedCollabId ? (
            <div>
              <p className="text-sm text-muted-foreground mb-3">Sélectionnez un collaborateur :</p>
              <div className="relative mb-3">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-input bg-background text-sm"
                  placeholder="Rechercher par nom, prénom ou matricule…"
                  value={collabSearch}
                  onChange={e => setCollabSearch(e.target.value)}
                  autoFocus
                />
              </div>
              <div className="max-h-60 overflow-y-auto space-y-1">
                {collabList
                  .filter(c => {
                    if (!collabSearch) return true;
                    const txt = `${c.nom} ${c.prenom} ${c.matricule}`.toLowerCase();
                    return txt.includes(collabSearch.toLowerCase());
                  })
                  .slice(0, 50)
                  .map(c => (
                    <button
                      key={c.id}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-accent/10 text-sm flex justify-between items-center"
                      onClick={() => setSelectedCollabId(c.id)}
                    >
                      <span className="font-medium">{c.prenom} {c.nom}</span>
                      <span className="text-xs text-muted-foreground">{c.matricule}</span>
                    </button>
                  ))}
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Button variant="ghost" size="sm" onClick={() => setSelectedCollabId(null)}>
                  <X size={14} className="mr-1" /> Changer de collaborateur
                </Button>
                <span className="text-sm font-medium">
                  {collabMap[selectedCollabId]?.prenom} {collabMap[selectedCollabId]?.nom} — {collabMap[selectedCollabId]?.matricule}
                </span>
              </div>
              <MouvementForm collaborateurId={selectedCollabId} />
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Alertes */}
      {alertes.length > 0 && (
        <div className="flex items-start gap-2 px-4 py-3 rounded-xl mb-4" style={{ background: "hsl(45 100% 50% / 0.10)", border: "1px solid hsl(45 100% 50% / 0.25)" }}>
          <AlertCircle size={15} style={{ color: "hsl(45 100% 30%)", flexShrink: 0, marginTop: 2 }} />
          <div>
            <p className="text-xs font-semibold" style={{ color: "hsl(45 100% 30%)" }}>
              {alertes.length} mouvement(s) temporaire(s) nécessitant une action
            </p>
            {alertes.slice(0, 5).map(a => {
              const c = collabMap[a.collaborateur_id];
              return (
                <p key={a.id} className="text-[11px] mt-0.5" style={{ color: "hsl(45 100% 25%)" }}>
                  • {c ? `${c.prenom} ${c.nom}` : "—"} — {typeMap[a.code_type_mouvement]?.libelle}
                  {a.date_fin_prevue ? ` (fin prévue ${new Date(a.date_fin_prevue).toLocaleDateString("fr-FR")})` : " (pas de date de fin)"}
                </p>
              );
            })}
          </div>
        </div>
      )}

      {/* Filtres */}
      <div className="flex flex-wrap gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "hsl(var(--muted-foreground))" }} />
          <input
            style={{ ...inputStyle, paddingLeft: 32, width: "100%" }}
            placeholder="Rechercher collaborateur, type…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select style={inputStyle} value={filterStatut} onChange={e => setFilterStatut(e.target.value)}>
          <option value="ALL">Tous les statuts</option>
          <option value="ACTIF">Actif</option>
          <option value="CLOTURE">Clôturé</option>
          <option value="ANNULE">Annulé</option>
        </select>
        <select style={inputStyle} value={filterType} onChange={e => setFilterType(e.target.value)}>
          <option value="ALL">Tous les types</option>
          {Object.entries(typeMap).map(([code, { libelle }]) => (
            <option key={code} value={code}>{libelle}</option>
          ))}
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <p className="text-center text-sm text-muted-foreground py-12">Chargement…</p>
      ) : filtered.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground py-12">Aucun mouvement trouvé</p>
      ) : (
        <div className="rounded-xl border overflow-hidden" style={{ borderColor: "hsl(var(--border))" }}>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr style={{ background: "hsl(var(--muted) / 0.3)" }}>
                  <th className="text-left px-3 py-2.5 font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>Collaborateur</th>
                  <th className="text-left px-3 py-2.5 font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>Type</th>
                  <th className="text-left px-3 py-2.5 font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>Date effet</th>
                  <th className="text-left px-3 py-2.5 font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>De → Vers</th>
                  <th className="text-left px-3 py-2.5 font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>Statut</th>
                  <th className="px-3 py-2.5"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(row => {
                  const c = collabMap[row.collaborateur_id];
                  return (
                    <tr key={row.id} className="border-t" style={{ borderColor: "hsl(var(--border))" }}>
                      <td className="px-3 py-2.5">
                        <div>
                          <p className="font-medium" style={{ color: "hsl(var(--foreground))" }}>{c ? `${c.prenom} ${c.nom}` : "—"}</p>
                          <p style={{ color: "hsl(var(--muted-foreground))", fontSize: 10 }}>{c?.matricule || ""}</p>
                        </div>
                      </td>
                      <td className="px-3 py-2.5">
                        <span style={{ color: "hsl(var(--foreground))" }}>{typeMap[row.code_type_mouvement]?.libelle || row.code_type_mouvement}</span>
                        {typeMap[row.code_type_mouvement]?.est_temporaire && (
                          <span className="ml-1 px-1 py-0.5 rounded text-[9px]" style={{ background: "hsl(280 65% 50% / 0.12)", color: "hsl(280 65% 40%)" }}>Temp.</span>
                        )}
                        {typeMap[row.code_type_mouvement]?.est_definitif && (
                          <span className="ml-1 px-1 py-0.5 rounded text-[9px]" style={{ background: "hsl(210 70% 50% / 0.12)", color: "hsl(210 70% 35%)" }}>Déf.</span>
                        )}
                      </td>
                      <td className="px-3 py-2.5" style={{ color: "hsl(var(--foreground))" }}>
                        {row.date_effet ? new Date(row.date_effet).toLocaleDateString("fr-FR") : "—"}
                      </td>
                      <td className="px-3 py-2.5" style={{ color: "hsl(var(--muted-foreground))" }}>
                        {(() => {
                          const resolvePoste = (code: string | null) => {
                            if (!code) return null;
                            const parentCode = code.includes("-") ? code.split("-").slice(0, -1).join("-") : code;
                            return posteMap[parentCode] || posteMap[code] || code;
                          };
                          const ancien = resolvePoste(row.ancien_poste) || (row.ancienne_unite_id ? uoMap[row.ancienne_unite_id] : "—");
                          const nouveau = resolvePoste(row.nouveau_poste) || (row.nouvelle_unite_id ? uoMap[row.nouvelle_unite_id] : "—");
                          return <>{ancien} → {nouveau}</>;
                        })()}
                      </td>
                      <td className="px-3 py-2.5">{statutBadge(row.statut)}</td>
                      <td className="px-3 py-2.5">
                        <Button size="icon" variant="ghost" className="h-7 w-7" title="Voir la fiche"
                          onClick={() => navigate(`/collaborateurs/${row.collaborateur_id}`)}>
                          <ExternalLink size={13} />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default MouvementsPage;
