/**
 * SalaireFixeForm – Formulaire CRUD pour les éléments fixes du salaire d'un collaborateur.
 */
import React, { useEffect, useState, useCallback, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, X, Save, CreditCard, Loader2 } from "lucide-react";
import { useZoneFixeLabels } from "@/hooks/useZoneFixeLabels";

interface SalaireFixe {
  id: string;
  collaborateur_id: string;
  date_debut: string;
  date_fin: string | null;
  salaire_base: number;
  salaire_horaire: number | null;
  salaire_journalier: number | null;
  prime_anciennete: number | null;
  prime_logement: number | null;
  prime_transport: number | null;
  indemnite_fonction: number | null;
  indemnite_representation: number | null;
  indemnite_caisse: number | null;
  indemnite_risque: number | null;
  indemnite_telephone: number | null;
  allocation_familiale: number | null;
  zone_fixe_01: number | null; zone_fixe_02: number | null; zone_fixe_03: number | null;
  zone_fixe_04: number | null; zone_fixe_05: number | null; zone_fixe_06: number | null;
  zone_fixe_07: number | null; zone_fixe_08: number | null; zone_fixe_09: number | null;
  zone_fixe_10: number | null; zone_fixe_11: number | null; zone_fixe_12: number | null;
  zone_fixe_13: number | null; zone_fixe_14: number | null; zone_fixe_15: number | null;
  zone_fixe_16: number | null; zone_fixe_17: number | null; zone_fixe_18: number | null;
  zone_fixe_19: number | null; zone_fixe_20: number | null;
  decision_ref: string | null;
  commentaire: string | null;
  archive: boolean;
}

const ALL_ZONE_KEYS = [
  "zone_fixe_01", "zone_fixe_02", "zone_fixe_03", "zone_fixe_04", "zone_fixe_05",
  "zone_fixe_06", "zone_fixe_07", "zone_fixe_08", "zone_fixe_09", "zone_fixe_10",
  "zone_fixe_11", "zone_fixe_12", "zone_fixe_13", "zone_fixe_14", "zone_fixe_15",
  "zone_fixe_16", "zone_fixe_17", "zone_fixe_18", "zone_fixe_19", "zone_fixe_20",
] as const;

const EMPTY_FORM: Record<string, string> = {
  date_debut: "", date_fin: "", salaire_base: "",
  salaire_horaire: "", salaire_journalier: "",
  prime_anciennete: "", prime_logement: "", prime_transport: "",
  indemnite_fonction: "", indemnite_representation: "",
  indemnite_caisse: "", indemnite_risque: "", indemnite_telephone: "",
  allocation_familiale: "",
  ...Object.fromEntries(ALL_ZONE_KEYS.map(k => [k, ""])),
  decision_ref: "", commentaire: "",
};

const FIELDS_STATIC: { key: string; label: string; type: "number" | "date" | "text" }[] = [
  { key: "salaire_base", label: "Salaire de base *", type: "number" },
  { key: "salaire_horaire", label: "Salaire horaire", type: "number" },
  { key: "salaire_journalier", label: "Salaire journalier", type: "number" },
  { key: "prime_anciennete", label: "Prime ancienneté", type: "number" },
  { key: "prime_logement", label: "Prime logement", type: "number" },
  { key: "prime_transport", label: "Prime transport", type: "number" },
  { key: "indemnite_fonction", label: "Ind. fonction", type: "number" },
  { key: "indemnite_representation", label: "Ind. représentation", type: "number" },
  { key: "indemnite_caisse", label: "Ind. caisse", type: "number" },
  { key: "indemnite_risque", label: "Ind. risque", type: "number" },
  { key: "indemnite_telephone", label: "Ind. téléphone", type: "number" },
  { key: "allocation_familiale", label: "Alloc. familiale", type: "number" },
];

interface Props {
  collaborateurId: string;
  readOnly?: boolean;
}

const SalaireFixeForm: React.FC<Props> = ({ collaborateurId, readOnly = false }) => {
  const [salaires, setSalaires] = useState<SalaireFixe[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [dateDebutContrat, setDateDebutContrat] = useState<string>("");
  const { labels: zoneLabels } = useZoneFixeLabels();

  // Only show zones linked to a rubrique
  const activeZoneFields = useMemo(() => {
    return ALL_ZONE_KEYS
      .filter(k => !!zoneLabels[k])
      .map(k => ({ key: k, label: zoneLabels[k], type: "number" as const }));
  }, [zoneLabels]);

  const FIELDS = useMemo(() => [...FIELDS_STATIC, ...activeZoneFields], [activeZoneFields]);

  // Load date début du contrat en cours
  useEffect(() => {
    (async () => {
      const data = []; const error = null; // Supabase desactive
      if (data && (data as any[]).length > 0) {
        setDateDebutContrat((data as any[])[0].date_debut || "");
      }
    })();
  }, [collaborateurId]);

  const load = useCallback(async () => {
    setLoading(true);
    const data = []; const error = null; // Supabase desactive
    setSalaires((data || []) as SalaireFixe[]);
    setLoading(false);
  }, [collaborateurId]);

  useEffect(() => { load(); }, [load]);

  const fmt = (v?: number | null) =>
    v != null ? new Intl.NumberFormat("fr-MA", { minimumFractionDigits: 2 }).format(v) : "—";

  const isFirstOccurrence = salaires.length === 0;

  const openNew = () => {
    setForm({ ...EMPTY_FORM, date_debut: isFirstOccurrence ? dateDebutContrat : "" });
    setEditingId(null);
    setShowForm(true);
  };

  const openEdit = (s: SalaireFixe) => {
    const f: Record<string, string> = {
      date_debut: s.date_debut || "",
      date_fin: s.date_fin || "",
      salaire_base: s.salaire_base != null ? String(s.salaire_base) : "",
      salaire_horaire: s.salaire_horaire != null ? String(s.salaire_horaire) : "",
      salaire_journalier: s.salaire_journalier != null ? String(s.salaire_journalier) : "",
      prime_anciennete: s.prime_anciennete != null ? String(s.prime_anciennete) : "",
      prime_logement: s.prime_logement != null ? String(s.prime_logement) : "",
      prime_transport: s.prime_transport != null ? String(s.prime_transport) : "",
      indemnite_fonction: s.indemnite_fonction != null ? String(s.indemnite_fonction) : "",
      indemnite_representation: s.indemnite_representation != null ? String(s.indemnite_representation) : "",
      indemnite_caisse: s.indemnite_caisse != null ? String(s.indemnite_caisse) : "",
      indemnite_risque: s.indemnite_risque != null ? String(s.indemnite_risque) : "",
      indemnite_telephone: s.indemnite_telephone != null ? String(s.indemnite_telephone) : "",
      allocation_familiale: s.allocation_familiale != null ? String(s.allocation_familiale) : "",
      decision_ref: s.decision_ref || "",
      commentaire: s.commentaire || "",
    };
    for (const k of ALL_ZONE_KEYS) {
      f[k] = (s as any)[k] != null ? String((s as any)[k]) : "";
    }
    setForm(f);
    setEditingId(s.id);
    setShowForm(true);
  };

  const cancel = () => { setShowForm(false); setEditingId(null); };
  const toNum = (v: string) => v ? parseFloat(v) : null;

  const save = async () => {
    const effectiveDate = form.date_debut || dateDebutContrat;
    if (!effectiveDate || !form.salaire_base) {
      toast.error("Date de début et salaire de base sont obligatoires");
      return;
    }
    setSaving(true);
    const payload: any = {
      collaborateur_id: collaborateurId,
      date_debut: effectiveDate,
      date_fin: form.date_fin || null,
      salaire_base: parseFloat(form.salaire_base),
      salaire_horaire: toNum(form.salaire_horaire),
      salaire_journalier: toNum(form.salaire_journalier),
      prime_anciennete: toNum(form.prime_anciennete),
      prime_logement: toNum(form.prime_logement),
      prime_transport: toNum(form.prime_transport),
      indemnite_fonction: toNum(form.indemnite_fonction),
      indemnite_representation: toNum(form.indemnite_representation),
      indemnite_caisse: toNum(form.indemnite_caisse),
      indemnite_risque: toNum(form.indemnite_risque),
      indemnite_telephone: toNum(form.indemnite_telephone),
      allocation_familiale: toNum(form.allocation_familiale),
      decision_ref: form.decision_ref || null,
      commentaire: form.commentaire || null,
    };
    for (const k of ALL_ZONE_KEYS) {
      payload[k] = toNum(form[k]);
    }

    if (editingId) {
      const { error } = await supabase.from("collaborateur_salaires_fixes").update(payload).eq("id", editingId);
      if (error) { toast.error(error.message); setSaving(false); return; }
      toast.success("Salaire fixe mis à jour");
    } else {
      const { error } = await supabase.from("collaborateur_salaires_fixes").insert(payload);
      if (error) { toast.error(error.message); setSaving(false); return; }
      toast.success("Salaire fixe ajouté");
    }
    setSaving(false);
    setShowForm(false);
    setEditingId(null);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Archiver cet enregistrement de salaire fixe ?")) return;
    await supabase.from("collaborateur_salaires_fixes").update({ archive: true } as any).eq("id", id);
    toast.success("Salaire fixe archivé");
    load();
  };

  const inputStyle = "w-full px-2 py-1.5 rounded-md border text-xs border-border bg-background text-foreground";

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin text-accent" /></div>;

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <CreditCard size={15} className="text-accent" />
          <h3 className="font-semibold text-sm text-foreground">Éléments fixes du salaire</h3>
        </div>
        {!readOnly && !showForm && (
          <button onClick={openNew} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-accent text-white">
            <Plus size={12} /> Nouveau
          </button>
        )}
      </div>

      {/* Formulaire */}
      {showForm && (
        <div className="rounded-xl border border-border p-4 mb-4 bg-card">
          <h4 className="text-xs font-semibold text-foreground mb-3">
            {editingId ? "Modifier le salaire fixe" : "Nouveau salaire fixe"}
          </h4>

          {/* Dates & Réf décision */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
            <div>
              <label className="block text-[11px] font-medium text-muted-foreground mb-0.5">Date début *</label>
              <input type="date" value={form.date_debut} onChange={e => setForm(f => ({ ...f, date_debut: e.target.value }))}
                placeholder={dateDebutContrat || ""}
                className={inputStyle} />
              {!editingId && isFirstOccurrence && dateDebutContrat && (
                <p className="text-[10px] text-accent mt-0.5 flex items-center gap-1">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-accent" />
                  Préremplie avec la date début du contrat en cours ({new Date(dateDebutContrat).toLocaleDateString("fr-FR")})
                </p>
              )}
            </div>
            <div>
              <label className="block text-[11px] font-medium text-muted-foreground mb-0.5">Date fin</label>
              <input type="date" value={form.date_fin} onChange={e => setForm(f => ({ ...f, date_fin: e.target.value }))}
                className={inputStyle} />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-muted-foreground mb-0.5">Réf. décision</label>
              <input type="text" value={form.decision_ref} onChange={e => setForm(f => ({ ...f, decision_ref: e.target.value }))}
                className={inputStyle} />
            </div>
            <div>
              <label className="block text-[11px] font-medium text-muted-foreground mb-0.5">Commentaire</label>
              <input type="text" value={form.commentaire} onChange={e => setForm(f => ({ ...f, commentaire: e.target.value }))}
                className={inputStyle} />
            </div>
          </div>

          {/* Montants */}
          <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-2 mb-3">
            {FIELDS.map(f => (
              <div key={f.key}>
                <label className="block text-[11px] font-medium text-muted-foreground mb-0.5 truncate" title={f.label}>{f.label}</label>
                <input
                  type="number" step="0.01"
                  value={form[f.key]}
                  onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  className={inputStyle}
                />
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="flex gap-2 justify-end">
            <button onClick={cancel} className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg border border-border font-semibold text-muted-foreground">
              <X size={13} /> Annuler
            </button>
            <button onClick={save} disabled={saving} className="flex items-center gap-1 text-xs px-4 py-1.5 rounded-lg font-semibold bg-accent text-white">
              <Save size={13} /> {saving ? "…" : "Enregistrer"}
            </button>
          </div>
        </div>
      )}

      {/* Liste */}
      {salaires.length === 0 ? (
        <p className="text-sm text-center py-6 text-muted-foreground">Aucun salaire fixe enregistré</p>
      ) : (
        salaires.map(s => (
          <div key={s.id} className="rounded-xl border border-border p-4 mb-3 bg-muted/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <span className="text-xs px-2 py-0.5 rounded-full bg-accent/15 text-accent font-medium">
                  {s.date_debut ? new Date(s.date_debut).toLocaleDateString("fr-FR") : ""} — {s.date_fin ? new Date(s.date_fin).toLocaleDateString("fr-FR") : "En cours"}
                </span>
                {s.decision_ref && <span className="text-xs text-muted-foreground">Réf. {s.decision_ref}</span>}
              </div>
              {!readOnly && (
                <div className="flex items-center gap-1">
                  <button onClick={() => openEdit(s)} className="p-1.5 rounded hover:bg-muted" title="Modifier">
                    <Pencil size={13} className="text-muted-foreground" />
                  </button>
                  <button onClick={() => remove(s.id)} className="p-1.5 rounded hover:bg-muted" title="Archiver">
                    <Trash2 size={13} className="text-destructive" />
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-2">
              <div className="rounded-lg p-2 text-center bg-primary/10">
                <p className="text-[11px] mb-0.5 text-muted-foreground">Salaire de base</p>
                <p className="text-sm font-bold text-primary">{fmt(s.salaire_base)}</p>
              </div>
              <div className="rounded-lg p-2 text-center bg-accent/10">
                <p className="text-[11px] mb-0.5 text-muted-foreground">Salaire horaire</p>
                <p className="text-sm font-bold text-accent">{fmt(s.salaire_horaire)}</p>
              </div>
              <div className="rounded-lg p-2 text-center bg-accent/10">
                <p className="text-[11px] mb-0.5 text-muted-foreground">Salaire journalier</p>
                <p className="text-sm font-bold text-accent">{fmt(s.salaire_journalier)}</p>
              </div>
              {[
                { label: "Prime ancienneté", value: s.prime_anciennete },
                { label: "Prime logement", value: s.prime_logement },
                { label: "Prime transport", value: s.prime_transport },
                { label: "Ind. fonction", value: s.indemnite_fonction },
                { label: "Ind. représentation", value: s.indemnite_representation },
                { label: "Ind. caisse", value: s.indemnite_caisse },
                { label: "Ind. risque", value: s.indemnite_risque },
                { label: "Ind. téléphone", value: s.indemnite_telephone },
                { label: "Alloc. familiale", value: s.allocation_familiale },
                ...ALL_ZONE_KEYS
                  .filter(k => !!zoneLabels[k])
                  .map(k => ({ label: zoneLabels[k], value: (s as any)[k] as number | null })),
              ].filter(x => x.value != null).map(x => (
                <div key={x.label} className="px-2">
                  <p className="text-[11px] text-muted-foreground">{x.label}</p>
                  <p className="text-sm font-medium text-foreground">{fmt(x.value)}</p>
                </div>
              ))}
            </div>
            {s.commentaire && <p className="text-[11px] text-muted-foreground mt-2">{s.commentaire}</p>}
          </div>
        ))
      )}
    </div>
  );
};

export default SalaireFixeForm;
