import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { X, DoorOpen, AlertTriangle, CalendarDays, Info } from "lucide-react";
import { format, isPast, isToday, parseISO } from "date-fns";
import { fr } from "date-fns/locale";

// =====================================================
// RG-DEP-FORM-01 (Adil DAIA) : Formulaire de saisie d'un départ
// - Date passée ou aujourd'hui → RG-DEP-01 (exécution immédiate)
// - Date future               → RG-DEP-02 (phase de départ planifiée)
// =====================================================

const MOTIFS_DEPART = [
  "Démission",
  "Fin de contrat (CDD)",
  "Licenciement",
  "Retraite",
  "Rupture conventionnelle",
  "Décès",
  "Invalidité",
  "Abandon de poste",
  "Mobilité externe",
  "Fin de mission",
  "Autre",
];

const schema = z.object({
  collaborateur_id: z.string().uuid("Collaborateur requis"),
  date_depart: z.string().min(1, "Date de départ requise"),
  motif_depart: z.string().min(1, "Motif requis"),
  commentaire: z.string().optional(),
  reference_decision: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

interface Props {
  collaborateurId?: string; // pré-rempli depuis la fiche collab
  onClose: () => void;
  onSuccess: () => void;
}

const DepartForm: React.FC<Props> = ({ collaborateurId, onClose, onSuccess }) => {
  const { user } = useAuth();
  const [submitting, setSubmitting] = useState(false);
  const [searchCollab, setSearchCollab] = useState("");

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      collaborateur_id: collaborateurId ?? "",
      date_depart: "",
      motif_depart: "",
      commentaire: "",
      reference_decision: "",
    },
  });

  const watchDate = watch("date_depart");
  const watchCollabId = watch("collaborateur_id");

  // Détermination du mode selon la date
  const isImmediate = watchDate
    ? isPast(parseISO(watchDate)) || isToday(parseISO(watchDate))
    : false;

  // Recherche de collaborateurs actifs
  const { data: collaborateurs = [] } = useQuery({
    queryKey: ["collabs-depart-search", searchCollab],
    queryFn: async () => {
      let q = supabase
        .from("collaborateurs")
        .select("id, nom, prenom, matricule, statut_collaborateur")
        .in("statut_collaborateur", ["ACTIF", "EN_DEPART"])
        .eq("archive", false)
        .order("nom")
        .limit(30);
      if (searchCollab.trim()) {
        // Découpage par mots pour gérer "NOM PRENOM" ou "PRENOM NOM"
        const words = searchCollab.trim().split(/\s+/);
        const conditions = words
          .flatMap(w => [`nom.ilike.%${w}%`, `prenom.ilike.%${w}%`, `matricule.ilike.%${w}%`])
          .join(",");
        q = q.or(conditions);
      }
      const { data } = await q;
      return data || [];
    },
  });

  const selectedCollab = collaborateurs.find(c => c.id === watchCollabId) ?? null;

  const onSubmit = async (data: FormData) => {
    setSubmitting(true);
    try {
      const { error } = await supabase
        .from("collaborateur_departs" as never)
        .insert({
          collaborateur_id: data.collaborateur_id,
          date_depart: data.date_depart,
          motif_depart: data.motif_depart,
          commentaire: data.commentaire || null,
          reference_decision: data.reference_decision || null,
          created_by: user?.id,
          updated_by: user?.id,
        } as never) as any;

      if (error) throw error;

      toast({
        title: isImmediate ? "Départ enregistré et traité" : "Départ planifié",
        description: isImmediate
          ? "Le collaborateur est marqué SORTI et tous ses éléments ont été clôturés."
          : `Le collaborateur sera traité le ${format(parseISO(data.date_depart), "dd/MM/yyyy", { locale: fr })}.`,
      });
      onSuccess();
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "hsl(var(--background) / 0.85)", backdropFilter: "blur(4px)" }}>
      <div className="w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden"
        style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b"
          style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted) / 0.3)" }}>
          <div className="flex items-center gap-2">
            <DoorOpen size={18} style={{ color: "hsl(var(--accent))" }} />
            <h2 className="text-base font-bold" style={{ color: "hsl(var(--foreground))" }}>
              Enregistrer un départ
            </h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:opacity-70 transition-opacity"
            style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}>
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-5">
          {/* Sélection collaborateur */}
          {collaborateurId ? (
            // Affiché en lecture seule si pré-rempli
            <div>
              <Label className="text-xs font-semibold mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
                Collaborateur
              </Label>
              {selectedCollab && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg"
                  style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))" }}>
                  <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))" }}>
                    {selectedCollab.prenom?.[0]}{selectedCollab.nom?.[0]}
                  </div>
                  <span className="text-sm font-medium" style={{ color: "hsl(var(--foreground))" }}>
                    {selectedCollab.prenom} {selectedCollab.nom}
                  </span>
                  <span className="text-xs ml-auto" style={{ color: "hsl(var(--muted-foreground))" }}>
                    #{selectedCollab.matricule}
                  </span>
                </div>
              )}
              <input type="hidden" {...register("collaborateur_id")} />
            </div>
          ) : (
            <div>
              <Label className="text-xs font-semibold mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
                Collaborateur *
              </Label>
              <Input
                placeholder="Rechercher un collaborateur…"
                value={searchCollab}
                onChange={e => setSearchCollab(e.target.value)}
                className="mb-2 h-9 text-sm"
              />
              <div className="max-h-40 overflow-y-auto rounded-lg border" style={{ borderColor: "hsl(var(--border))" }}>
                {collaborateurs.length === 0 ? (
                  <p className="text-xs text-center py-4" style={{ color: "hsl(var(--muted-foreground))" }}>
                    Aucun collaborateur trouvé
                  </p>
                ) : collaborateurs.map(c => (
                  <button key={c.id} type="button"
                    onClick={() => { setValue("collaborateur_id", c.id, { shouldValidate: true }); setSearchCollab(`${c.prenom} ${c.nom}`); }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-left text-sm hover:opacity-80 transition-opacity border-b last:border-0"
                    style={{
                      borderColor: "hsl(var(--border) / 0.4)",
                      background: watchCollabId === c.id ? "hsl(var(--accent) / 0.08)" : "hsl(var(--card))",
                      color: "hsl(var(--foreground))",
                    }}>
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0"
                      style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))" }}>
                      {c.prenom?.[0]}{c.nom?.[0]}
                    </div>
                    <span>{c.prenom} {c.nom}</span>
                    <span className="ml-auto text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>#{c.matricule}</span>
                    {c.statut_collaborateur === "EN_DEPART" && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full ml-1"
                        style={{ background: "hsl(45 100% 50% / 0.15)", color: "hsl(45 100% 30%)" }}>
                        En départ
                      </span>
                    )}
                  </button>
                ))}
              </div>
              {errors.collaborateur_id && (
                <p className="text-xs mt-1" style={{ color: "hsl(var(--destructive))" }}>{errors.collaborateur_id.message}</p>
              )}
            </div>
          )}

          {/* Date de départ */}
          <div>
            <Label className="text-xs font-semibold mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
              Date de départ *
            </Label>
            <Input type="date" {...register("date_depart")} className="h-9 text-sm" />
            {errors.date_depart && (
              <p className="text-xs mt-1" style={{ color: "hsl(var(--destructive))" }}>{errors.date_depart.message}</p>
            )}
            {/* Indicateur RG */}
            {watchDate && (
              <div className="mt-2 flex items-start gap-2 px-3 py-2 rounded-lg"
                style={{
                  background: isImmediate ? "hsl(0 70% 50% / 0.08)" : "hsl(45 100% 50% / 0.10)",
                  border: `1px solid ${isImmediate ? "hsl(0 70% 50% / 0.2)" : "hsl(45 100% 50% / 0.25)"}`,
                }}>
                {isImmediate ? (
                  <AlertTriangle size={14} style={{ color: "hsl(0 70% 40%)", flexShrink: 0, marginTop: 1 }} />
                ) : (
                  <Info size={14} style={{ color: "hsl(45 100% 35%)", flexShrink: 0, marginTop: 1 }} />
                )}
                <p className="text-xs" style={{ color: isImmediate ? "hsl(0 70% 40%)" : "hsl(45 100% 35%)" }}>
                  {isImmediate
                    ? "RG-DEP-01 : Date passée → Le départ sera exécuté immédiatement. Toutes les dates de fin seront clôturées et le poste libéré."
                    : "RG-DEP-02 : Date future → Le collaborateur sera mis en phase de départ. L'exécution se déclenchera automatiquement à l'échéance."}
                </p>
              </div>
            )}
          </div>

          {/* Motif */}
          <div>
            <Label className="text-xs font-semibold mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
              Motif de départ *
            </Label>
            <select {...register("motif_depart")}
              className="w-full h-9 text-sm rounded-lg border px-3"
              style={{ background: "hsl(var(--background))", borderColor: "hsl(var(--border))", color: "hsl(var(--foreground))" }}>
              <option value="">— Sélectionner —</option>
              {MOTIFS_DEPART.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
            {errors.motif_depart && (
              <p className="text-xs mt-1" style={{ color: "hsl(var(--destructive))" }}>{errors.motif_depart.message}</p>
            )}
          </div>

          {/* Référence décision */}
          <div>
            <Label className="text-xs font-semibold mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
              Référence de la décision
            </Label>
            <Input {...register("reference_decision")} placeholder="Ex : DRH/2025/042" className="h-9 text-sm" />
          </div>

          {/* Commentaire */}
          <div>
            <Label className="text-xs font-semibold mb-1.5 block" style={{ color: "hsl(var(--foreground))" }}>
              Commentaire
            </Label>
            <Textarea {...register("commentaire")} placeholder="Observations, circonstances particulières…" rows={3} className="text-sm resize-none" />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-2 border-t" style={{ borderColor: "hsl(var(--border))" }}>
            <Button type="button" variant="outline" onClick={onClose} disabled={submitting}>
              Annuler
            </Button>
            <Button type="submit" disabled={submitting}
              style={{ background: isImmediate ? "hsl(0 70% 45%)" : "hsl(var(--accent))", color: "white" }}>
              {submitting
                ? "Enregistrement…"
                : isImmediate
                  ? "Confirmer le départ"
                  : "Planifier le départ"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DepartForm;
