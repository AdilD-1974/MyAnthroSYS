import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useManagerPopulation } from "@/hooks/useManagerPopulation";
import {
  DoorOpen, Plus, Search, Calendar, User, FileText,
  AlertTriangle, CheckCircle2, Clock, X, RefreshCw, Eye
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";
import DepartForm from "@/components/depart/DepartForm";

// =====================================================
// RG-DEP-UI-01 (Adil DAIA) :
//   Page de gestion des départs
//   - Admin/RH : voient tous les départs, peuvent créer/annuler
//   - Manager  : voit uniquement les départs de son équipe (lecture seule)
// =====================================================

interface Depart {
  id: string;
  collaborateur_id: string;
  date_depart: string;
  motif_depart: string;
  commentaire: string | null;
  reference_decision: string | null;
  statut: string;
  traite_le: string | null;
  created_at: string;
  collaborateur?: {
    nom: string;
    prenom: string;
    matricule: string;
    statut_collaborateur: string;
  };
}

const STATUT_CONFIG: Record<string, { label: string; bg: string; color: string; icon: React.ReactNode }> = {
  PLANIFIE: {
    label: "Planifié",
    bg: "hsl(45 100% 50% / 0.12)",
    color: "hsl(45 100% 30%)",
    icon: <Clock size={12} />,
  },
  TRAITE: {
    label: "Traité",
    bg: "hsl(142 55% 45% / 0.12)",
    color: "hsl(142 55% 30%)",
    icon: <CheckCircle2 size={12} />,
  },
  ANNULE: {
    label: "Annulé",
    bg: "hsl(0 70% 50% / 0.10)",
    color: "hsl(0 70% 40%)",
    icon: <X size={12} />,
  },
};

const StatutBadge: React.FC<{ statut: string }> = ({ statut }) => {
  const cfg = STATUT_CONFIG[statut] ?? { label: statut, bg: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))", icon: null };
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
      style={{ background: cfg.bg, color: cfg.color }}>
      {cfg.icon}{cfg.label}
    </span>
  );
};

const GestionDepartsPage: React.FC = () => {
  const { role } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isManager = role === "manager";
  const isReadOnly = isManager;
  const { collaborateurIds: managerCollabIds, loading: popLoading } = useManagerPopulation();

  const [search, setSearch] = useState("");
  const [filterStatut, setFilterStatut] = useState<string>("TOUS");
  const [showForm, setShowForm] = useState(false);

  // RG-DEP-UI-01 : Chargement filtré selon le rôle
  const { data: departs = [], isLoading } = useQuery<Depart[]>({
    queryKey: ["departs", filterStatut, isManager, managerCollabIds],
    enabled: !isManager || !popLoading,
    queryFn: async () => {
      let q = supabase
        .from("collaborateur_departs" as never)
        .select(`
          *,
          collaborateur:collaborateurs(nom, prenom, matricule, statut_collaborateur)
        `)
        .order("date_depart", { ascending: false });

      if (filterStatut !== "TOUS") q = (q as any).eq("statut", filterStatut);
      if (isManager && managerCollabIds.length > 0) {
        q = (q as any).in("collaborateur_id", managerCollabIds);
      }
      const { data, error } = await (q as any);
      if (error) throw error;
      return (data || []) as Depart[];
    },
  });

  // Annulation d'un départ planifié
  const annulerMutation = useMutation({
    mutationFn: async (departId: string) => {
      // Récupérer le collaborateur_id
      const { data: dep } = await supabase
        .from("collaborateur_departs" as never)
        .select("collaborateur_id")
        .eq("id", departId)
        .single() as any;

      const { error } = await supabase
        .from("collaborateur_departs" as never)
        .update({ statut: "ANNULE", updated_at: new Date().toISOString() } as never)
        .eq("id", departId) as any;
      if (error) throw error;

      // Remettre le collaborateur en ACTIF
      if (dep?.collaborateur_id) {
        await supabase
          .from("collaborateurs")
          .update({ statut_collaborateur: "ACTIF" })
          .eq("id", dep.collaborateur_id);
      }
    },
    onSuccess: () => {
      toast({ title: "Départ annulé avec succès" });
      queryClient.invalidateQueries({ queryKey: ["departs"] });
    },
    onError: (err: any) => toast({ title: "Erreur", description: err.message, variant: "destructive" }),
  });

  const filtered = departs.filter(d => {
    const collab = (d as any).collaborateur;
    const term = search.toLowerCase();
    return (
      !search ||
      collab?.nom?.toLowerCase().includes(term) ||
      collab?.prenom?.toLowerCase().includes(term) ||
      collab?.matricule?.toLowerCase().includes(term) ||
      d.motif_depart.toLowerCase().includes(term)
    );
  });

  // KPIs
  const planifies = departs.filter(d => d.statut === "PLANIFIE").length;
  const traites   = departs.filter(d => d.statut === "TRAITE").length;
  const annules   = departs.filter(d => d.statut === "ANNULE").length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <DoorOpen size={20} style={{ color: "hsl(var(--accent))" }} />
            <h1 className="text-xl font-bold" style={{ color: "hsl(var(--foreground))" }}>
              Gestion des Départs
            </h1>
          </div>
          <p className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>
            {isManager
              ? "Suivi des départs de votre équipe"
              : "Enregistrement et suivi des départs de collaborateurs"}
          </p>
        </div>
        {!isReadOnly && (
          <Button onClick={() => setShowForm(true)} className="flex items-center gap-2" size="sm">
            <Plus size={15} /> Enregistrer un départ
          </Button>
        )}
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Planifiés",   value: planifies, icon: <Clock size={18} />,        bg: "hsl(45 100% 50% / 0.10)",  color: "hsl(45 100% 30%)" },
          { label: "Traités",     value: traites,   icon: <CheckCircle2 size={18} />, bg: "hsl(142 55% 45% / 0.10)", color: "hsl(142 55% 30%)" },
          { label: "Annulés",     value: annules,   icon: <X size={18} />,            bg: "hsl(0 70% 50% / 0.10)",   color: "hsl(0 70% 40%)" },
        ].map(kpi => (
          <div key={kpi.label} className="rounded-xl p-4 flex items-center gap-3"
            style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}>
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: kpi.bg, color: kpi.color }}>
              {kpi.icon}
            </div>
            <div>
              <p className="text-2xl font-bold" style={{ color: "hsl(var(--foreground))" }}>{kpi.value}</p>
              <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{kpi.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filtres */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "hsl(var(--muted-foreground))" }} />
          <Input
            placeholder="Rechercher…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-8 h-8 text-sm"
          />
        </div>
        <div className="flex gap-1">
          {["TOUS", "PLANIFIE", "TRAITE", "ANNULE"].map(s => (
            <button key={s} onClick={() => setFilterStatut(s)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={{
                background: filterStatut === s ? "hsl(var(--accent))" : "hsl(var(--muted))",
                color: filterStatut === s ? "hsl(var(--accent-foreground))" : "hsl(var(--muted-foreground))",
              }}>
              {s === "TOUS" ? "Tous" : STATUT_CONFIG[s]?.label ?? s}
            </button>
          ))}
        </div>
      </div>

      {/* Tableau */}
      <div className="rounded-xl border overflow-hidden" style={{ borderColor: "hsl(var(--border))" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "hsl(var(--muted) / 0.5)", borderBottom: "1px solid hsl(var(--border))" }}>
              {["Collaborateur", "Date de départ", "Motif", "Référence", "Statut", "Traité le", ""].map(h => (
                <th key={h} className="text-left px-4 py-2.5 text-xs font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={7} className="py-12 text-center text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>Chargement…</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7} className="py-12 text-center">
                <DoorOpen size={32} className="mx-auto mb-2 opacity-30" style={{ color: "hsl(var(--muted-foreground))" }} />
                <p className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>Aucun départ trouvé</p>
              </td></tr>
            ) : filtered.map((dep, i) => {
              const collab = (dep as any).collaborateur;
              const isPast = new Date(dep.date_depart) <= new Date();
              return (
                <tr key={dep.id}
                  style={{
                    background: i % 2 === 0 ? "hsl(var(--card))" : "hsl(var(--muted) / 0.2)",
                    borderBottom: "1px solid hsl(var(--border) / 0.5)",
                  }}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                        style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))" }}>
                        {collab?.prenom?.[0]}{collab?.nom?.[0]}
                      </div>
                      <div>
                        <p className="font-medium text-xs" style={{ color: "hsl(var(--foreground))" }}>
                          {collab?.prenom} {collab?.nom}
                        </p>
                        <p className="text-[11px]" style={{ color: "hsl(var(--muted-foreground))" }}>#{collab?.matricule}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <Calendar size={12} style={{ color: dep.statut === "PLANIFIE" && !isPast ? "hsl(45 100% 35%)" : "hsl(var(--muted-foreground))" }} />
                      <span className="text-xs font-medium" style={{ color: "hsl(var(--foreground))" }}>
                        {new Date(dep.date_depart).toLocaleDateString("fr-FR")}
                      </span>
                      {dep.statut === "PLANIFIE" && !isPast && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full"
                          style={{ background: "hsl(45 100% 50% / 0.15)", color: "hsl(45 100% 30%)" }}>
                          Dans {Math.ceil((new Date(dep.date_depart).getTime() - Date.now()) / 86400000)} j
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs max-w-[160px] truncate" style={{ color: "hsl(var(--foreground))" }}>
                    {dep.motif_depart}
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                    {dep.reference_decision || "—"}
                  </td>
                  <td className="px-4 py-3">
                    <StatutBadge statut={dep.statut} />
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                    {dep.traite_le ? new Date(dep.traite_le).toLocaleDateString("fr-FR") : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => navigate(`/collaborateurs/${dep.collaborateur_id}`)}
                        className="p-1.5 rounded-lg transition-colors hover:opacity-80"
                        style={{ background: "hsl(var(--accent) / 0.1)", color: "hsl(var(--accent))" }}
                        title="Voir la fiche">
                        <Eye size={13} />
                      </button>
                      {!isReadOnly && dep.statut === "PLANIFIE" && (
                        <button
                          onClick={() => {
                            if (confirm(`Annuler le départ de ${collab?.prenom} ${collab?.nom} ?`)) {
                              annulerMutation.mutate(dep.id);
                            }
                          }}
                          className="p-1.5 rounded-lg transition-colors hover:opacity-80"
                          style={{ background: "hsl(0 70% 50% / 0.10)", color: "hsl(0 70% 40%)" }}
                          title="Annuler le départ">
                          <X size={13} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Modal formulaire */}
      {showForm && (
        <DepartForm
          onClose={() => setShowForm(false)}
          onSuccess={() => {
            setShowForm(false);
            queryClient.invalidateQueries({ queryKey: ["departs"] });
          }}
        />
      )}
    </div>
  );
};

export default GestionDepartsPage;
