import React, { useState } from "react";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Users, BookOpen, LogOut,
  ChevronLeft, ChevronRight, Palette, UserCog,
  CreditCard, Briefcase, BarChart3, FileText, Building2, SlidersHorizontal,
  Target, ChevronDown, MapPin, UserPlus, Clock, ArrowRightLeft, Plus,
  Award, DoorOpen, Search, GraduationCap, Star, Network, Heart, PauseCircle,
  FolderOpen, Gift, Plane, TrendingUp, Shield, Settings, GitBranch,
  Database, BarChart2, ClipboardList, Activity, Lock, Eye, CalendarDays,
  CalendarCheck, RefreshCw,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import Logo from "./Logo";

type AppRole = "administrateur" | "gestionnaire_rh" | "gestionnaire_paie" | "manager" | "collaborateur";

interface NavChildDef {
  icon: React.ReactNode;
  label: string;
  to: string;
  roles?: AppRole[];
  children?: { icon: React.ReactNode; label: string; to: string; roles?: AppRole[] }[];
}

interface NavItemDef {
  icon: React.ReactNode;
  label: string;
  to: string;
  roles?: AppRole[];
  children?: NavChildDef[];
}

const navItems: NavItemDef[] = [
  {
    icon: <LayoutDashboard size={18} />,
    label: "Tableau de bord",
    to: "/dashboard",
  },
  {
    icon: <Building2 size={18} />,
    label: "Organisations",
    to: "/organisations",
    roles: ["administrateur", "gestionnaire_rh", "manager"],
  },
  {
    icon: <Users size={18} />,
    label: "Gestion Administrative",
    to: "/gestion-admin",
    roles: ["administrateur", "gestionnaire_rh", "manager"],
    children: [
      // RG-MGR-COLLAB-01 : le manager ne peut pas créer de collaborateur
      // L'entrée Collaborateurs est masquée pour le rôle manager
      { icon: <Users size={15} />, label: "Collaborateurs", to: "/collaborateurs", roles: ["administrateur", "gestionnaire_rh", "manager"] as AppRole[] },
      {
        icon: <Clock size={15} />, label: "Absences & Congés", to: "/absences",
        children: [
          { icon: <TrendingUp size={14} />, label: "Compteurs de congés", to: "/absences/compteurs", roles: ["administrateur", "gestionnaire_rh", "manager"] as AppRole[] },
          { icon: <Plus size={14} />, label: "Saisie & Gestion", to: "/absences/saisie" },
          { icon: <BarChart2 size={14} />, label: "Suivi des congés", to: "/absences/suivi" },
          { icon: <CalendarDays size={14} />, label: "Planning", to: "/absences/planning" },
          { icon: <CalendarCheck size={14} />, label: "Validation des demandes", to: "/absences/validation" },
        ],
      },
      { icon: <ArrowRightLeft size={15} />, label: "Mouvements internes", to: "/mouvements" },
      { icon: <DoorOpen size={15} />, label: "Gestion des Départs", to: "/departs" },
      { icon: <PauseCircle size={15} />, label: "Départs provisoires", to: "/departs-provisoires" },
      { icon: <FileText size={15} />, label: "Attestations & Certificats", to: "/attestations" },
    ],
  },
  {
    icon: <UserPlus size={18} />,
    label: "Recrutement & Intégration",
    to: "/recrutement",
    roles: ["administrateur", "gestionnaire_rh"],
    children: [
      { icon: <Search size={15} />, label: "Campagnes de recrutement", to: "/recrutement/campagnes" },
      { icon: <ClipboardList size={15} />, label: "Candidatures & Entretiens", to: "/recrutement/candidatures" },
      { icon: <GitBranch size={15} />, label: "Workflows d'onboarding", to: "/recrutement/onboarding" },
    ],
  },
  {
    icon: <Target size={18} />,
    label: "GPEC",
    to: "/gpec",
    roles: ["administrateur", "gestionnaire_rh"],
    children: [
      { icon: <BookOpen size={15} />, label: "Référentiel métiers", to: "/gpec/referentiel-metiers" },
      { icon: <MapPin size={15} />, label: "Postes", to: "/gpec/postes" },
      { icon: <Network size={15} />, label: "Cartographie des talents", to: "/gpec/cartographie" },
      { icon: <ArrowRightLeft size={15} />, label: "Plans de succession", to: "/gpec/succession" },
    ],
  },
  {
    icon: <GraduationCap size={18} />,
    label: "Formation & Développement",
    to: "/formation",
    roles: ["administrateur", "gestionnaire_rh", "manager"],
    children: [
      { icon: <BookOpen size={15} />, label: "Catalogue de formations", to: "/formation/catalogue" },
      { icon: <ClipboardList size={15} />, label: "Inscriptions & Validations", to: "/formation/inscriptions" },
      { icon: <BarChart2 size={15} />, label: "Suivi des acquis & Budgets", to: "/formation/suivi" },
    ],
  },
  {
    icon: <CreditCard size={18} />,
    label: "Paie & Rémunération",
    to: "/paie",
    roles: ["administrateur", "gestionnaire_rh", "gestionnaire_paie"],
    children: [
      { icon: <Database size={15} />, label: "Éléments fixes du salaire", to: "/paie/salaires-fixes" },
      { icon: <Settings size={15} />, label: "Paramétrage réglementaire", to: "/paie/parametrage" },
      {
        icon: <Briefcase size={15} />,
        label: "Traitement de la Paie",
        to: "/paie/traitement",
        children: [
          { icon: <ClipboardList size={14} />, label: "Préparation de la paie", to: "/paie/traitement/preparation" },
          { icon: <Activity size={14} />, label: "Calcul de la paie", to: "/paie/traitement/calcul" },
        ],
      },
      { icon: <Clock size={15} />, label: "Opérations fin de période", to: "/paie/fin-periode" },
      { icon: <FileText size={15} />, label: "Éditions de Paie", to: "/paie/editions" },
      { icon: <BarChart3 size={15} />, label: "Fin d'année", to: "/paie/fin-annee" },
      {
        icon: <Shield size={15} />,
        label: "Déclarations Réglementaires",
        to: "/paie/declarations",
        children: [
          { icon: <FileText size={14} />, label: "Déclaration CNSS", to: "/paie/declarations/cnss" },
        ],
      },
    ],
  },
  {
    icon: <Star size={18} />,
    label: "Performance & Évaluation",
    to: "/performance",
    roles: ["administrateur", "gestionnaire_rh", "manager"],
    children: [
      { icon: <Target size={15} />, label: "Objectifs par service", to: "/performance/objectifs" },
      { icon: <Award size={15} />, label: "Campagnes d'évaluation", to: "/performance/campagnes" },
      { icon: <BarChart3 size={15} />, label: "Tableaux de bord", to: "/performance/tableau-bord" },
    ],
  },
  {
    icon: <Users size={18} />,
    label: "Relations Sociales",
    to: "/relations-sociales",
    roles: ["administrateur", "gestionnaire_rh"],
    children: [
      { icon: <Network size={15} />, label: "Instances représentatives", to: "/relations-sociales/instances" },
      { icon: <FileText size={15} />, label: "Accords collectifs", to: "/relations-sociales/accords" },
      { icon: <Activity size={15} />, label: "Communication interne", to: "/relations-sociales/communication" },
      { icon: <ClipboardList size={15} />, label: "Enquêtes de satisfaction", to: "/relations-sociales/enquetes" },
    ],
  },
  {
    icon: <Heart size={18} />,
    label: "Santé, Sécurité & QVT",
    to: "/sante-securite",
    roles: ["administrateur", "gestionnaire_rh"],
    children: [
      { icon: <Activity size={15} />, label: "Santé au travail", to: "/sante-securite/sante" },
      { icon: <Shield size={15} />, label: "Sécurité", to: "/sante-securite/securite" },
      { icon: <Heart size={15} />, label: "Qualité de Vie au Travail", to: "/sante-securite/qvt" },
      { icon: <ClipboardList size={15} />, label: "Prévention & conformité", to: "/sante-securite/prevention" },
      { icon: <Users size={15} />, label: "Accompagnement & support", to: "/sante-securite/accompagnement" },
    ],
  },
  {
    icon: <FolderOpen size={18} />,
    label: "Gestion Documentaire RH",
    to: "/documents-rh",
    roles: ["administrateur", "gestionnaire_rh"],
  },
  {
    icon: <Gift size={18} />,
    label: "Avantages & Prévoyance",
    to: "/avantages",
    roles: ["administrateur", "gestionnaire_rh", "gestionnaire_paie"],
  },
  {
    icon: <Plane size={18} />,
    label: "Mobilité & Expatriation",
    to: "/mobilite",
    roles: ["administrateur", "gestionnaire_rh"],
  },
  {
    icon: <TrendingUp size={18} />,
    label: "Pilotage Stratégique RH",
    to: "/pilotage",
    roles: ["administrateur", "gestionnaire_rh"],
  },
  {
    icon: <Lock size={18} />,
    label: "Sécurité & Gouvernance IT",
    to: "/gouvernance",
    roles: ["administrateur"],
  },
  {
    icon: <BookOpen size={18} />,
    label: "Référentiels",
    to: "/referentiels",
    roles: ["administrateur", "gestionnaire_rh"],
  },
  {
    icon: <Settings size={18} />,
    label: "Configuration",
    to: "/configuration",
    roles: ["administrateur"],
    children: [
      { icon: <SlidersHorizontal size={15} />, label: "Paramètres RH", to: "/parametres-rh" },
      { icon: <GitBranch size={15} />, label: "Processus & Workflows", to: "/configuration/workflows" },
      { icon: <Database size={15} />, label: "Données & Reporting", to: "/configuration/reporting" },
      {
        icon: <Clock size={15} />,
        label: "Gestion des Temps",
        to: "/configuration/temps",
        children: [
          { icon: <FileText size={14} />, label: "Types de Congé", to: "/configuration/temps" },
          { icon: <CalendarDays size={14} />, label: "Jours Fériés", to: "/configuration/temps/feries" },
        ],
      },
      { icon: <PauseCircle size={15} />, label: "Motifs départ provisoire", to: "/configuration/departs-provisoires" },
      {
        icon: <Lock size={15} />,
        label: "Gestion des Accès",
        to: "/configuration/acces",
        children: [
          { icon: <Building2 size={14} />, label: "Espaces", to: "/configuration/acces/espaces" },
          { icon: <Shield size={14} />, label: "Rôles", to: "/configuration/acces/roles" },
          { icon: <UserCog size={14} />, label: "Utilisateurs", to: "/utilisateurs" },
        ],
      },
    ],
  },
  {
    icon: <Eye size={18} />,
    label: "Audit & Traçabilité",
    to: "/audit",
    roles: ["administrateur"],
    children: [
      { icon: <Activity size={15} />, label: "Historisation des modifications", to: "/audit/historisation" },
      { icon: <ClipboardList size={15} />, label: "Contrôles de cohérence", to: "/audit/controles" },
      { icon: <BarChart3 size={15} />, label: "Rapports d'audit", to: "/audit/rapports" },
    ],
  },
  {
    icon: <CalendarDays size={18} />,
    label: "Calendrier",
    to: "/calendrier",
    roles: ["administrateur", "gestionnaire_rh", "gestionnaire_paie", "manager"],
  },
  {
    icon: <Users size={18} />,
    label: "Trombinoscope",
    to: "/trombinoscope",
    roles: ["administrateur", "gestionnaire_rh", "gestionnaire_paie", "manager"],
  },
  { icon: <FileText size={18} />, label: "Mon profil", to: "/profil" },
  { icon: <Palette size={18} />, label: "Apparence", to: "/apparence" },
];

const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const { role, allRoles, activeRole, switchRole, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // RG : L'administrateur a accès à l'intégralité des menus et espaces sans restriction
  const filtered = navItems.filter(item =>
    role === "administrateur" || !item.roles || (role && item.roles.includes(role as AppRole))
  );

  const toggleGroup = (to: string) => {
    setExpandedGroups(prev => ({ ...prev, [to]: !prev[to] }));
  };

  const isGroupActive = (item: NavItemDef): boolean => {
    if (location.pathname === item.to) return true;
    if (item.children) {
      return item.children.some(c => {
        if (location.pathname.startsWith(c.to) && c.to !== "/") return true;
        if (c.children) return c.children.some(gc => location.pathname.startsWith(gc.to));
        return false;
      });
    }
    return false;
  };

  const getRoleLabel = (r: string | null) => {
    switch (r) {
      case "administrateur": return "Administrateur";
      case "gestionnaire_rh": return "Gestionnaire RH";
      case "gestionnaire_paie": return "Gestionnaire Paie";
      case "manager": return "Manager";
      default: return "Collaborateur";
    }
  };

  const renderChild = (child: NavChildDef, depth = 1) => {
    // RG : Filtrer les enfants selon les rôles
    if (role !== "administrateur" && child.roles && role && !child.roles.includes(role as AppRole)) return null;

    const paddingLeft = depth === 1 ? "ml-2" : "ml-4";
    const borderLeft = "border-l pl-3";
    const textSize = depth === 1 ? "text-xs" : "text-[11px]";

    if (child.children && !collapsed) {
      const visibleGrandChildren = child.children.filter(gc =>
        role === "administrateur" || !gc.roles || (role && gc.roles.includes(role as AppRole))
      );
      const isExpanded = expandedGroups[child.to] ?? false;
      const isActive = visibleGrandChildren.some(gc => location.pathname.startsWith(gc.to));
      return (
        <div key={child.to}>
          <button
            type="button"
            onClick={() => toggleGroup(child.to)}
            className={`nav-item w-full ${textSize} ${isActive ? "active" : ""}`}
            style={{ justifyContent: "space-between" }}
          >
            <span className="flex items-center gap-2">
              <span className="flex-shrink-0">{child.icon}</span>
              <span className="truncate">{child.label}</span>
            </span>
            <ChevronDown
              size={11}
              style={{
                transition: "transform 0.2s",
                transform: isExpanded ? "rotate(180deg)" : "rotate(0deg)",
                color: "hsl(var(--sidebar-foreground) / 0.5)",
                flexShrink: 0,
              }}
            />
          </button>
          {isExpanded && (
            <div className={`${paddingLeft} mt-0.5 space-y-0.5 ${borderLeft}`} style={{ borderColor: "hsl(var(--sidebar-border))" }}>
              {visibleGrandChildren.map(gc => (
                <NavLink
                  key={gc.to}
                  to={gc.to}
                  className={({ isActive }) => `nav-item text-[11px] ${isActive ? "active" : ""}`}
                >
                  <span className="flex-shrink-0">{gc.icon}</span>
                  <span className="truncate">{gc.label}</span>
                </NavLink>
              ))}
            </div>
          )}
        </div>
      );
    }

    return (
      <NavLink
        key={child.to}
        to={child.to}
        className={({ isActive }) => `nav-item ${textSize} ${isActive ? "active" : ""}`}
      >
        <span className="flex-shrink-0">{child.icon}</span>
        {!collapsed && <span className="truncate">{child.label}</span>}
      </NavLink>
    );
  };

  return (
    <aside
      className="flex flex-col h-screen transition-all duration-300 relative"
      style={{
        width: collapsed ? 64 : 240,
        background: "hsl(var(--sidebar-background))",
        borderRight: "1px solid hsl(var(--sidebar-border))",
        flexShrink: 0,
      }}
    >
      {/* Logo */}
      <div className="flex items-center justify-between px-4 py-5 border-b" style={{ borderColor: "hsl(var(--sidebar-border))" }}>
        <Logo collapsed={collapsed} />
      </div>

      {/* User info */}
      {!collapsed && (
        <div className="px-4 py-3 border-b" style={{ borderColor: "hsl(var(--sidebar-border))" }}>
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
              style={{ background: "hsl(var(--sidebar-primary))", color: "white" }}
            >
              {profile?.prenom?.[0]?.toUpperCase() || "U"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold truncate" style={{ color: "hsl(var(--sidebar-foreground))" }}>
                {profile?.prenom} {profile?.nom}
              </p>
              <p className="text-xs truncate" style={{ color: "hsl(var(--sidebar-foreground) / 0.55)" }}>
                {getRoleLabel(activeRole)}
              </p>
            </div>
          </div>
          {/* RG-MULTI-ROLE-01 : Switcher d'espace si l'utilisateur a plusieurs rôles */}
          {allRoles.length > 1 && (
            <div className="mt-2.5">
              <p className="text-[10px] font-medium mb-1.5" style={{ color: "hsl(var(--sidebar-foreground) / 0.4)" }}>
                CHANGER D'ESPACE
              </p>
              <div className="flex flex-col gap-1">
                {allRoles.map(r => (
                  <button
                    key={r}
                    onClick={() => {
                      switchRole(r);
                      navigate("/dashboard");
                    }}
                    className="flex items-center gap-1.5 px-2 py-1 rounded-lg text-[11px] font-medium transition-all text-left"
                    style={{
                      background: activeRole === r ? "hsl(var(--sidebar-primary) / 0.15)" : "transparent",
                      color: activeRole === r ? "hsl(var(--sidebar-primary))" : "hsl(var(--sidebar-foreground) / 0.6)",
                      border: activeRole === r ? "1px solid hsl(var(--sidebar-primary) / 0.3)" : "1px solid transparent",
                    }}
                  >
                    <RefreshCw size={10} />
                    {getRoleLabel(r)}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-0.5">
        {filtered.map(item => {
          if (item.children) {
            const active = isGroupActive(item);
            const expanded = expandedGroups[item.to] ?? false;
            return (
              <div key={item.to}>
                <button
                  type="button"
                  onClick={() => {
                    if (collapsed) {
                      navigate(item.to);
                    } else {
                      toggleGroup(item.to);
                    }
                  }}
                  className={`nav-item w-full ${active ? "active" : ""}`}
                  title={collapsed ? item.label : undefined}
                  style={{ justifyContent: "space-between" }}
                >
                  <span className="flex items-center gap-2">
                    <span className="flex-shrink-0">{item.icon}</span>
                    {!collapsed && <span className="truncate">{item.label}</span>}
                  </span>
                  {!collapsed && (
                    <ChevronDown
                      size={13}
                      style={{
                        transition: "transform 0.2s",
                        transform: expanded ? "rotate(180deg)" : "rotate(0deg)",
                        color: "hsl(var(--sidebar-foreground) / 0.5)",
                        flexShrink: 0,
                      }}
                    />
                  )}
                </button>
                {!collapsed && expanded && (
                  <div className="ml-2 mt-0.5 space-y-0.5 border-l pl-3"
                    style={{ borderColor: "hsl(var(--sidebar-border))" }}>
                    {item.children.map(child => renderChild(child, 1))}
                  </div>
                )}
              </div>
            );
          }

          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
              title={collapsed ? item.label : undefined}
            >
              <span className="flex-shrink-0">{item.icon}</span>
              {!collapsed && <span className="truncate">{item.label}</span>}
            </NavLink>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="px-2 py-3 border-t" style={{ borderColor: "hsl(var(--sidebar-border))" }}>
        <button
          onClick={() => { signOut(); navigate("/login"); }}
          className="nav-item w-full"
          title={collapsed ? "Déconnexion" : undefined}
        >
          <LogOut size={18} className="flex-shrink-0" />
          {!collapsed && <span>Déconnexion</span>}
        </button>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full flex items-center justify-center text-xs border shadow-sm z-10 transition-all"
        style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--border))", color: "hsl(var(--foreground))" }}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </aside>
  );
};

export default Sidebar;
