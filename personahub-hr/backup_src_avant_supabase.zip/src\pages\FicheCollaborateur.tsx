import React, { useEffect, useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useParams, useNavigate } from "react-router-dom";
import {
  ArrowLeft, User, FileText, Briefcase, Users, CreditCard,
  GraduationCap, Settings, Save, Plus, Pencil, Trash2,
  Phone, Mail, MapPin, Shield, AlertCircle, Award, Heart,
  Building2, Calendar, Hash, X, Check, Camera, DoorOpen,
  Users as UsersIcon, Plane, Clock
} from "lucide-react";
import { Button } from "@/components/ui/button";
import RefSelect from "@/components/RefSelect";
import ConjointForm from "@/components/famille/ConjointForm";
import EnfantForm from "@/components/famille/EnfantForm";
import ContactUrgenceForm from "@/components/famille/ContactUrgenceForm";
import ContratForm from "@/components/contrat/ContratForm";
import AffectationForm from "@/components/affectation/AffectationForm";
import WorkflowManagerForm from "@/components/affectation/WorkflowManagerForm";
import DepartForm from "@/components/depart/DepartForm";
import SyndicalMandatForm from "@/components/syndical/SyndicalMandatForm";
import PaiementForm from "@/components/paiement/PaiementForm";
import DiplomeForm from "@/components/formation/DiplomeForm";
import CompetenceForm from "@/components/formation/CompetenceForm";
import ClassificationForm from "@/components/affectation/ClassificationForm";
import SalaireFixeForm from "@/components/remuneration/SalaireFixeForm";
import AvantageForm from "@/components/remuneration/AvantageForm";
import CollaborateurPlanPaieForm from "@/components/remuneration/CollaborateurPlanPaieForm";

import { useQueryClient } from "@tanstack/react-query";

import { useAuth } from "@/contexts/AuthContext";

/* ──────────────── Types ──────────────── */
interface Collaborateur {
  id: string; matricule: string; ancien_matricule?: string; civilite?: string;
  nom: string; prenom: string; nom_jeune_fille?: string;
  date_naissance: string; lieu_naissance?: string;
  code_nationalite?: string; code_nationalite2?: string;
  code_genre: string;
  cin?: string; cin_date_debut?: string; cin_date_fin?: string;
  passeport?: string; passeport_date_debut?: string; passeport_date_fin?: string;
  num_cnss?: string; cnss_date_debut?: string; cnss_date_fin?: string;
  num_cimr?: string; cimr_date_debut?: string; cimr_date_fin?: string;
  num_amo?: string; amo_date_debut?: string; amo_date_fin?: string;
  num_fiscal?: string; fiscal_date_debut?: string; fiscal_date_fin?: string;
  telephone?: string; gsm?: string;
  email_personnel?: string; email_professionnel?: string;
  statut_collaborateur: string; photo_path?: string;
  created_at: string; updated_at: string; archive: boolean;
}

/* ──────────────── Onglets ──────────────── */
const TABS = [
  { id: "identite",       label: "Identité",      icon: <User size={15} /> },
  { id: "contrats",       label: "Contrats",       icon: <Briefcase size={15} /> },
  { id: "affectation",    label: "Affectation & Classification",    icon: <Building2 size={15} /> },
  
  { id: "famille",        label: "Famille",        icon: <Heart size={15} /> },
  { id: "remuneration",   label: "Rémunération",   icon: <CreditCard size={15} /> },
  { id: "formation",      label: "Formation & Compétences", icon: <GraduationCap size={15} /> },
  { id: "immatriculation",label: "Immatriculat°",  icon: <Shield size={15} /> },
  { id: "syndical",       label: "Syndical",       icon: <Users size={15} /> },
  { id: "divers",         label: "Divers",         icon: <Settings size={15} /> },
];

/* ──────────────── Helpers ──────────────── */
const Field: React.FC<{ label: string; value?: string | null; className?: string }> = ({ label, value, className }) => (
  <div className={className}>
    <p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>{label}</p>
    <p className="text-sm font-medium" style={{ color: value ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground) / 0.5)" }}>
      {value || "—"}
    </p>
  </div>
);

const SectionCard: React.FC<{ title: string; icon?: React.ReactNode; children: React.ReactNode; action?: React.ReactNode }> = ({ title, icon, children, action }) => (
  <div className="rounded-xl border p-5 mb-4" style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}>
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        {icon && <span style={{ color: "hsl(var(--accent))" }}>{icon}</span>}
        <h3 className="font-semibold text-sm" style={{ color: "hsl(var(--foreground))" }}>{title}</h3>
      </div>
      {action}
    </div>
    {children}
  </div>
);

/* ────────────────────────────────────────
   COMPOSANTS PAR ONGLET
──────────────────────────────────────── */

/* IDENTITE */
const TabIdentite: React.FC<{ collab: Collaborateur; onSave: () => void }> = ({ collab, onSave }) => {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(collab);
  const [saving, setSaving] = useState(false);
  // Maps de résolution des libellés pour l'affichage en lecture
  const [natMap, setNatMap] = useState<Record<string, string>>({});
  const [genreMap, setGenreMap] = useState<Record<string, string>>({});
  const GENRE_FALLBACKS: Record<string, string> = { F: "Femme", H: "Homme" };

  useEffect(() => {
    // Charger les libellés de nationalité et de genre depuis les référentiels
    Promise.all([
      supabase.from("ref_nationalite" as never).select("code, libelle").eq("actif" as never, true as never),
      supabase.from("ref_genre" as never).select("code, libelle").eq("actif" as never, true as never),
    ]).then(([nat, genre]) => {
      const nm: Record<string, string> = {};
      ((nat.data as any[]) || []).forEach((r: any) => { nm[String(r.code).trim()] = r.libelle; });
      setNatMap(nm);
      const gm: Record<string, string> = {};
      ((genre.data as any[]) || []).forEach((r: any) => { gm[String(r.code).trim().toUpperCase()] = r.libelle; });
      setGenreMap(gm);
    });
  }, []);

  const resolveGenreLabel = (code?: string | null) => {
    const normalizedCode = String(code || "").trim().toUpperCase();
    return genreMap[normalizedCode] || GENRE_FALLBACKS[normalizedCode] || code || "—";
  };

  const save = async () => {
    setSaving(true);
    await supabase.from("collaborateurs").update({
      nom: form.nom, prenom: form.prenom, nom_jeune_fille: form.nom_jeune_fille,
      date_naissance: form.date_naissance, lieu_naissance: form.lieu_naissance,
      code_nationalite: form.code_nationalite, code_nationalite2: form.code_nationalite2,
      code_genre: form.code_genre, telephone: form.telephone, gsm: form.gsm,
      email_personnel: form.email_personnel, email_professionnel: form.email_professionnel,
      statut_collaborateur: form.statut_collaborateur,
      civilite: (form as any).civilite || null,
      cin: form.cin || null, cin_date_debut: form.cin_date_debut || null, cin_date_fin: form.cin_date_fin || null,
      passeport: form.passeport || null, passeport_date_debut: form.passeport_date_debut || null, passeport_date_fin: form.passeport_date_fin || null,
      num_fiscal: form.num_fiscal || null, fiscal_date_debut: form.fiscal_date_debut || null, fiscal_date_fin: form.fiscal_date_fin || null,
    }).eq("id", collab.id);
    setSaving(false);
    setEditing(false);
    onSave();
  };

  const F = (key: keyof Collaborateur) => (
    editing
      ? <input value={(form[key] as string) || ""} onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          className="w-full px-2 py-1 rounded border text-sm"
          style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
      : <p className="text-sm font-medium" style={{ color: (form[key] as string) ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground) / 0.4)" }}>
          {(form[key] as string) || "—"}
        </p>
  );

  return (
    <div>
      {/* État civil */}
      <SectionCard title="État civil" icon={<User size={15} />} action={
        editing
          ? <div className="flex gap-2">
              <button onClick={() => { setEditing(false); setForm(collab); }} className="p-1.5 rounded text-xs" style={{ color: "hsl(var(--muted-foreground))" }}><X size={14} /></button>
              <button onClick={save} disabled={saving} className="px-3 py-1 rounded text-xs font-semibold" style={{ background: "hsl(var(--accent))", color: "white" }}>
                {saving ? "…" : <><Check size={12} className="inline mr-1" />Enregistrer</>}
              </button>
            </div>
          : <button onClick={() => setEditing(true)} className="p-1.5 rounded hover:bg-blue-50 transition-all" style={{ color: "hsl(var(--accent))" }}><Pencil size={14} /></button>
      }>
        {/* Ligne 1 : Matricule, Civilité, Nom, Prénom */}
        <div className="grid grid-cols-4 gap-4 mb-4">
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Matricule</p>
            <p className="text-sm font-bold" style={{ color: "hsl(var(--accent))" }}>#{collab.matricule}</p></div>
          <div>
            {editing
              ? <RefSelect
                  table=""
                  staticOptions={[
                    { value: "M.", label: "M." }, { value: "Mme", label: "Mme" },
                    { value: "Dr.", label: "Dr." }, { value: "Pr.", label: "Pr." }, { value: "Me.", label: "Me." },
                  ]}
                  value={form.civilite || ""}
                  onChange={v => setForm(f => ({ ...f, civilite: v }))}
                  label="Civilité"
                />
              : <><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Civilité</p>
                  <p className="text-sm font-medium" style={{ color: "hsl(var(--foreground))" }}>{form.civilite || "—"}</p></>
            }
          </div>
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Nom</p>{F("nom")}</div>
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Prénom</p>{F("prenom")}</div>
        </div>
        {/* Ligne 2 : Genre, Nom de jeune fille, Date de Naissance, Lieu de Naissance, Nationalité, Nationalité 2 */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div>
            {editing
              ? <RefSelect
                  table="ref_genre"
                  staticOptions={[
                    { value: "F", label: "Femme" },
                    { value: "H", label: "Homme" },
                  ]}
                  value={String(form.code_genre || "").trim().toUpperCase()}
                  onChange={v => setForm(f => ({ ...f, code_genre: v }))}
                  label="Genre"
                />
              : <><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Genre</p>
                  <p className="text-sm font-medium">{resolveGenreLabel(form.code_genre)}</p></>
            }
          </div>
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Nom de jeune fille</p>{F("nom_jeune_fille")}</div>
          <div>
            {editing
              ? <><label className="block text-xs font-medium mb-1" style={{ color: "hsl(var(--muted-foreground))" }}>Date de naissance</label>
                  <input type="date" value={form.date_naissance || ""} onChange={e => setForm(f => ({ ...f, date_naissance: e.target.value }))}
                  className="w-full px-2 py-1.5 rounded-lg border text-sm" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} /></>
              : <><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Date de naissance</p>
                  <p className="text-sm font-medium">{form.date_naissance ? new Date(form.date_naissance).toLocaleDateString("fr-FR") : "—"}</p></>
            }
          </div>
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Lieu de naissance</p>{F("lieu_naissance")}</div>
          <div>
            {editing
              ? <RefSelect
                  table="ref_nationalite"
                  value={form.code_nationalite || ""}
                  onChange={v => setForm(f => ({ ...f, code_nationalite: v }))}
                  label="Nationalité"
                />
              : <><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Nationalité</p>
                  <p className="text-sm font-medium" style={{ color: form.code_nationalite ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground) / 0.4)" }}>{natMap[form.code_nationalite || ""] || form.code_nationalite || "—"}</p></>
            }
          </div>
          <div>
            {editing
              ? <RefSelect
                  table="ref_nationalite"
                  value={form.code_nationalite2 || ""}
                  onChange={v => setForm(f => ({ ...f, code_nationalite2: v }))}
                  label="Nationalité 2"
                />
              : <><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Nationalité 2</p>
                  <p className="text-sm font-medium" style={{ color: form.code_nationalite2 ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground) / 0.4)" }}>{natMap[form.code_nationalite2 || ""] || form.code_nationalite2 || "—"}</p></>
            }
          </div>
        </div>
      </SectionCard>

      {/* Contact */}
      <SectionCard title="Coordonnées" icon={<Phone size={15} />} action={
        editing
          ? null
          : <button onClick={() => setEditing(true)} className="p-1.5 rounded hover:bg-blue-50 transition-all" style={{ color: "hsl(var(--accent))" }}><Pencil size={14} /></button>
      }>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Téléphone</p>{F("telephone")}</div>
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>GSM</p>{F("gsm")}</div>
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Email personnel</p>{F("email_personnel")}</div>
          <div><p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Email professionnel</p>{F("email_professionnel")}</div>
        </div>
      </SectionCard>

      {/* Documents d'identité */}
      <SectionCard title="Documents d'identité" icon={<FileText size={15} />} action={
        editing
          ? null
          : <button onClick={() => setEditing(true)} className="p-1.5 rounded hover:bg-blue-50 transition-all" style={{ color: "hsl(var(--accent))" }}><Pencil size={14} /></button>
      }>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* CIN */}
          <div className="rounded-lg p-3 space-y-2" style={{ background: "hsl(var(--muted) / 0.5)" }}>
            <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "hsl(var(--accent))" }}>CIN</p>
            {editing ? (
              <>
                <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Numéro</label>{F("cin")}</div>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Date début</label>
                    <input type="date" value={form.cin_date_debut || ""} onChange={e => setForm(f => ({ ...f, cin_date_debut: e.target.value }))}
                      className="w-full px-2 py-1 rounded border text-sm" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} /></div>
                  <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Date fin</label>
                    <input type="date" value={form.cin_date_fin || ""} onChange={e => setForm(f => ({ ...f, cin_date_fin: e.target.value }))}
                      className="w-full px-2 py-1 rounded border text-sm" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} /></div>
                </div>
              </>
            ) : (
              <>
                <Field label="Numéro" value={collab.cin} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Date début" value={collab.cin_date_debut ? new Date(collab.cin_date_debut).toLocaleDateString("fr-FR") : undefined} />
                  <Field label="Date fin" value={collab.cin_date_fin ? new Date(collab.cin_date_fin).toLocaleDateString("fr-FR") : undefined} />
                </div>
              </>
            )}
          </div>
          {/* Passeport */}
          <div className="rounded-lg p-3 space-y-2" style={{ background: "hsl(var(--muted) / 0.5)" }}>
            <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "hsl(var(--accent))" }}>Passeport</p>
            {editing ? (
              <>
                <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Numéro</label>{F("passeport")}</div>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Date début</label>
                    <input type="date" value={form.passeport_date_debut || ""} onChange={e => setForm(f => ({ ...f, passeport_date_debut: e.target.value }))}
                      className="w-full px-2 py-1 rounded border text-sm" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} /></div>
                  <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Date fin</label>
                    <input type="date" value={form.passeport_date_fin || ""} onChange={e => setForm(f => ({ ...f, passeport_date_fin: e.target.value }))}
                      className="w-full px-2 py-1 rounded border text-sm" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} /></div>
                </div>
              </>
            ) : (
              <>
                <Field label="Numéro" value={collab.passeport} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Date début" value={collab.passeport_date_debut ? new Date(collab.passeport_date_debut).toLocaleDateString("fr-FR") : undefined} />
                  <Field label="Date fin" value={collab.passeport_date_fin ? new Date(collab.passeport_date_fin).toLocaleDateString("fr-FR") : undefined} />
                </div>
              </>
            )}
          </div>
          {/* Fiscal */}
          <div className="rounded-lg p-3 space-y-2" style={{ background: "hsl(var(--muted) / 0.5)" }}>
            <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "hsl(var(--accent))" }}>Identifiant fiscal</p>
            {editing ? (
              <>
                <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Numéro</label>{F("num_fiscal")}</div>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Date début</label>
                    <input type="date" value={form.fiscal_date_debut || ""} onChange={e => setForm(f => ({ ...f, fiscal_date_debut: e.target.value }))}
                      className="w-full px-2 py-1 rounded border text-sm" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} /></div>
                  <div><label className="text-xs font-medium mb-0.5 block" style={{ color: "hsl(var(--muted-foreground))" }}>Date fin</label>
                    <input type="date" value={form.fiscal_date_fin || ""} onChange={e => setForm(f => ({ ...f, fiscal_date_fin: e.target.value }))}
                      className="w-full px-2 py-1 rounded border text-sm" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} /></div>
                </div>
              </>
            ) : (
              <>
                <Field label="Numéro" value={collab.num_fiscal} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Date début" value={collab.fiscal_date_debut ? new Date(collab.fiscal_date_debut).toLocaleDateString("fr-FR") : undefined} />
                  <Field label="Date fin" value={collab.fiscal_date_fin ? new Date(collab.fiscal_date_fin).toLocaleDateString("fr-FR") : undefined} />
                </div>
              </>
            )}
          </div>
        </div>
      </SectionCard>
    </div>
  );
};

/* CONTRATS */
// Map code → libelle pour un référentiel donné
type RefMap = Record<string, string>;

const TabContrats: React.FC<{ collaborateurId: string; ancienMatricule?: string }> = ({ collaborateurId, ancienMatricule }) => {
  const [contrats, setContrats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editContrat, setEditContrat] = useState<any | null>(null);
  const [refs, setRefs] = useState<{
    typeContrat: RefMap; motifRecrutement: RefMap; sourceRecrutement: RefMap;
    tempsTravail: RefMap; devise: RefMap; uniteDuree: RefMap; motifSortie: RefMap; societes: RefMap;
  }>({ typeContrat: {}, motifRecrutement: {}, sourceRecrutement: {}, tempsTravail: {}, devise: {}, uniteDuree: {}, motifSortie: {}, societes: {} });

  // Charge les référentiels en parallèle
  useEffect(() => {
    const toMap = (data: any[] | null) =>
      (data || []).reduce((acc, r) => ({ ...acc, [r.code]: r.libelle }), {} as RefMap);

    Promise.all([
      supabase.from("ref_type_contrat" as never).select("code, libelle"),
      supabase.from("ref_motif_recrutement").select("code, libelle"),
      supabase.from("ref_source_recrutement" as never).select("code, libelle"),
      supabase.from("ref_temps_travail" as never).select("code, libelle"),
      supabase.from("ref_devise").select("code, libelle"),
      supabase.from("ref_unite_duree_contrat" as never).select("code, libelle"),
      supabase.from("ref_motif_sortie").select("code, libelle"),
      supabase.from("societes" as never).select("id, raison_sociale"),
    ]).then(([tc, mr, sr, tt, dv, ud, ms, soc]) => {
      setRefs({
        typeContrat: toMap(tc.data as any),
        motifRecrutement: toMap(mr.data as any),
        sourceRecrutement: toMap(sr.data as any),
        tempsTravail: toMap(tt.data as any),
        devise: toMap(dv.data as any),
        uniteDuree: toMap(ud.data as any),
        motifSortie: toMap(ms.data as any),
        societes: (soc.data as any[] || []).reduce((acc, s) => ({ ...acc, [s.id]: s.raison_sociale }), {} as RefMap),
      });
    });
  }, []);

  const load = async () => {
    setLoading(true);
    // Charger les contrats du collaborateur courant
    const { data: current, error } = await supabase
      .from("collaborateur_contrats")
      .select("*")
      .eq("collaborateur_id", collaborateurId)
      .eq("archive", false);

    let allContrats = current || [];

    // Si un ancien matricule est connu, charger aussi ses contrats historiques
    if (ancienMatricule) {
      const { data: ancienCollab } = await supabase
        .from("collaborateurs")
        .select("id, matricule")
        .eq("matricule", ancienMatricule)
        .maybeSingle();

      if (ancienCollab) {
        const { data: ancienContrats } = await supabase
          .from("collaborateur_contrats")
          .select("*")
          .eq("collaborateur_id", (ancienCollab as any).id)
          .eq("archive", false);

        if (ancienContrats && ancienContrats.length > 0) {
          allContrats = [
            ...allContrats,
            ...ancienContrats.map((c: any) => ({ ...c, _from_ancien: (ancienCollab as any).matricule })),
          ];
        }
      }
    }

    allContrats.sort((a: any, b: any) => (b.date_debut || "").localeCompare(a.date_debut || ""));
    setContrats(allContrats);
    setLoading(false);
  };

  useEffect(() => { load(); }, [collaborateurId, ancienMatricule]);

  const handleEdit = (c: any) => { setEditContrat(c); setShowForm(true); };
  const handleNew = () => { setEditContrat(null); setShowForm(true); };

  // Résout code → libelle, avec fallback sur le code brut si non trouvé
  const lbl = (map: RefMap, code?: string | null) => code ? (map[code] || code) : "—";

  const getStatutContrat = (c: any) => {
    const isEnCours = ["ACTIF", "EN_COURS"].includes(c.code_statut_contrat);
    const isEchu = c.code_statut_contrat === "ECHU" || (c.date_fin && new Date(c.date_fin) < new Date());
    if (isEnCours && !isEchu) return { label: "En cours", bg: "hsl(84 55% 50% / 0.15)", color: "hsl(84 55% 35%)" };
    if (isEchu) return { label: "Échu", bg: "hsl(215 20% 55% / 0.15)", color: "hsl(215 20% 40%)" };
    return { label: c.code_statut_contrat, bg: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" };
  };

  const contratEnCours = contrats.find(c => ["ACTIF", "EN_COURS"].includes(c.code_statut_contrat) && !c._from_ancien && !(c.date_fin && new Date(c.date_fin) < new Date()));

  return (
    <>
      {/* Alerte contrat en cours */}
      {contratEnCours && (
        <div className="mb-4 px-4 py-2.5 rounded-lg text-xs flex items-center gap-2 border" style={{ background: "hsl(84 55% 50% / 0.08)", borderColor: "hsl(84 55% 50% / 0.25)", color: "hsl(84 55% 32%)" }}>
          <span className="text-base">✅</span>
          <span>Contrat en cours actif depuis le <strong>{new Date(contratEnCours.date_debut).toLocaleDateString("fr-FR")}</strong>
          {contratEnCours.date_fin ? ` — jusqu'au ${new Date(contratEnCours.date_fin).toLocaleDateString("fr-FR")}` : " — sans date de fin"}
          . Un nouveau contrat clôturera automatiquement celui-ci.</span>
        </div>
      )}

      <SectionCard title="Historique des contrats" icon={<Briefcase size={15} />} action={
        <button
          onClick={handleNew}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold"
          style={{ background: "hsl(var(--accent))", color: "white" }}
        >
          <Plus size={12} />Nouveau contrat
        </button>
      }>
        {loading
          ? <div className="h-20 flex items-center justify-center"><div className="w-5 h-5 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: "hsl(var(--accent))", borderTopColor: "transparent" }} /></div>
          : contrats.length === 0
            ? <p className="text-sm text-center py-8" style={{ color: "hsl(var(--muted-foreground))" }}>Aucun contrat enregistré</p>
            : <div className="space-y-3">
                {contrats.map(c => {
                  const statutStyle = getStatutContrat(c);
                  return (
                    <div key={c.id} className="rounded-lg p-4 border" style={{ borderColor: c._from_ancien ? "hsl(35 90% 55% / 0.4)" : statutStyle.color + "40", background: c._from_ancien ? "hsl(35 90% 55% / 0.06)" : "hsl(var(--muted) / 0.3)" }}>
                      {c._from_ancien && (
                        <div className="flex items-center gap-1.5 mb-2 text-xs font-semibold" style={{ color: "hsl(35 90% 45%)" }}>
                          <Hash size={11} />Historique — Ancien matricule {c._from_ancien}
                        </div>
                      )}
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
                          <div>
                            <p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Type de contrat</p>
                            <p className="text-sm font-medium" style={{ color: "hsl(var(--foreground))" }}>{lbl(refs.typeContrat, c.code_type_contrat)}</p>
                          </div>
                          <div>
                            <p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Statut</p>
                            <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ background: statutStyle.bg, color: statutStyle.color }}>
                              {statutStyle.label}
                            </span>
                          </div>
                          <Field label="Date début" value={c.date_debut ? new Date(c.date_debut).toLocaleDateString("fr-FR") : undefined} />
                          <Field label="Date fin" value={c.date_fin ? new Date(c.date_fin).toLocaleDateString("fr-FR") : "—"} />
                          <div>
                            <p className="text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Date fin prévue</p>
                            <p className="text-sm font-medium flex items-center gap-1" style={{ color: c.date_depart_previsionnelle ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground) / 0.5)" }}>
                              {c.date_depart_previsionnelle ? new Date(c.date_depart_previsionnelle).toLocaleDateString("fr-FR") : "—"}
                            </p>
                          </div>
                          <Field label="Société" value={lbl(refs.societes, c.societe_id)} />
                          <Field label="Référence" value={c.reference_contrat} />
                          <Field label="Temps de travail" value={lbl(refs.tempsTravail, c.code_temps)} />
                          <Field label="Devise" value={lbl(refs.devise, c.code_devise)} />
                          <Field label="Durée" value={c.duree_contrat ? `${c.duree_contrat} ${lbl(refs.uniteDuree, c.code_unite_duree)}` : undefined} />
                          <Field label="Motif recrutement" value={lbl(refs.motifRecrutement, c.code_motif_recrutement)} />
                          <Field label="Source recrutement" value={lbl(refs.sourceRecrutement, c.code_source_recrutement)} />
                          <Field label="Responsable recrutement" value={c.responsable_recrutement} />
                          {(c.motif_sortie || c.date_sortie) && <>
                            <Field label="Motif sortie" value={lbl(refs.motifSortie, c.motif_sortie)} />
                            <Field label="Date sortie" value={c.date_sortie ? new Date(c.date_sortie).toLocaleDateString("fr-FR") : undefined} />
                          </>}
                        </div>
                        {!c._from_ancien && (
                          <button onClick={() => handleEdit(c)} className="p-1.5 rounded" style={{ color: "hsl(var(--accent))" }}>
                            <Pencil size={14} />
                          </button>
                        )}
                      </div>
                      {c.commentaire_sortie && (
                        <div className="mt-3 pt-3 border-t" style={{ borderColor: "hsl(var(--border))" }}>
                          <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}><span className="font-semibold">Commentaire sortie :</span> {c.commentaire_sortie}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
        }
      </SectionCard>

      {showForm && (
        <ContratForm
          collaborateurId={collaborateurId}
          contrat={editContrat}
          onClose={() => setShowForm(false)}
          onSaved={load}
        />
      )}
    </>
  );
};

/* AFFECTATION */
const TabAffectation: React.FC<{ collaborateurId: string; ancienMatricule?: string }> = ({ collaborateurId, ancienMatricule }) => {
  return (
    <div>
      <SectionCard title="Affectations UO / Poste" icon={<Building2 size={15} />}>
        <AffectationForm collaborateurId={collaborateurId} ancienMatricule={ancienMatricule} />
      </SectionCard>

      {/* Forçage workflow */}
      <SectionCard title="Forçage workflow de validation" icon={<Users size={15} />}>
        <WorkflowManagerForm collaborateurId={collaborateurId} />
      </SectionCard>

      {/* Classification - sous-formulaire complet */}
      <ClassificationForm collaborateurId={collaborateurId} />
    </div>
  );
};

/* FAMILLE */
const TabFamille: React.FC<{ collaborateurId: string }> = ({ collaborateurId }) => {
  return (
    <div className="space-y-4">
      <SectionCard title="Conjoint(e)" icon={<Heart size={15} />}>
        <ConjointForm collaborateurId={collaborateurId} />
      </SectionCard>
      <SectionCard title="Enfants" icon={<Users size={15} />}>
        <EnfantForm collaborateurId={collaborateurId} />
      </SectionCard>
      <SectionCard title="Contacts d'urgence" icon={<AlertCircle size={15} />}>
        <ContactUrgenceForm collaborateurId={collaborateurId} />
      </SectionCard>
    </div>
  );
};

/* REMUNERATION */
const TabRemuneration: React.FC<{ collaborateurId: string }> = ({ collaborateurId }) => {
  return (
    <div>
      {/* RG-REM-03 : Plan de paie d'affectation – Auteur : Adil DAIA */}
      <SectionCard title="Plan de paie" icon={<CreditCard size={15} />}>
        <CollaborateurPlanPaieForm collaborateurId={collaborateurId} />
      </SectionCard>

      {/* RG-REM-01 : Ordre d'affichage – Éléments fixes, Avantages, Coordonnées bancaires – Auteur : Adil DAIA */}
      <SectionCard title="Éléments fixes du salaire" icon={<CreditCard size={15} />}>
        <SalaireFixeForm collaborateurId={collaborateurId} />
      </SectionCard>

      {/* RG-REM-02 : Pas de SectionCard title pour éviter la duplication du titre "Avantages" – Auteur : Adil DAIA */}
      <div className="rounded-2xl border border-border bg-card p-5 mb-4">
        <AvantageForm collaborateurId={collaborateurId} />
      </div>

      <SectionCard title="Coordonnées bancaires" icon={<Hash size={15} />}>
        <PaiementForm collaborateurId={collaborateurId} />
      </SectionCard>
    </div>
  );
};

/* FORMATION & COMPÉTENCES */
const TabFormation: React.FC<{ collaborateurId: string }> = ({ collaborateurId }) => (
  <>
    <DiplomeForm collaborateurId={collaborateurId} />
    <CompetenceForm collaborateurId={collaborateurId} />
  </>
);

/* IMMATRICULATION */
const TabImmatriculation: React.FC<{ collaborateurId: string; collab: Collaborateur; onSave?: () => void }> = ({ collaborateurId, collab, onSave }) => {
  const [immatriculations, setImmatriculations] = useState<any[]>([]);
  const [editingSocial, setEditingSocial] = useState(false);
  const [socialForm, setSocialForm] = useState({
    num_cnss: "", cnss_date_debut: "", cnss_date_fin: "",
    num_cimr: "", cimr_date_debut: "", cimr_date_fin: "",
    num_amo: "", amo_date_debut: "", amo_date_fin: "",
  });

  useEffect(() => {
    supabase.from("collaborateur_immatriculations").select("*").eq("collaborateur_id", collaborateurId).eq("archive", false)
      .then(({ data }) => { if (data) setImmatriculations(data); });
  }, [collaborateurId]);

  const startEditSocial = () => {
    setSocialForm({
      num_cnss: collab.num_cnss || "", cnss_date_debut: collab.cnss_date_debut || "", cnss_date_fin: collab.cnss_date_fin || "",
      num_cimr: collab.num_cimr || "", cimr_date_debut: collab.cimr_date_debut || "", cimr_date_fin: collab.cimr_date_fin || "",
      num_amo: collab.num_amo || "", amo_date_debut: collab.amo_date_debut || "", amo_date_fin: collab.amo_date_fin || "",
    });
    setEditingSocial(true);
  };

  const saveSocial = async () => {
    const { error } = await supabase.from("collaborateurs").update({
      num_cnss: socialForm.num_cnss || null, cnss_date_debut: socialForm.cnss_date_debut || null, cnss_date_fin: socialForm.cnss_date_fin || null,
      num_cimr: socialForm.num_cimr || null, cimr_date_debut: socialForm.cimr_date_debut || null, cimr_date_fin: socialForm.cimr_date_fin || null,
      num_amo: socialForm.num_amo || null, amo_date_debut: socialForm.amo_date_debut || null, amo_date_fin: socialForm.amo_date_fin || null,
    }).eq("id", collaborateurId);
    if (error) { toast.error(error.message); return; }
    toast.success("Immatriculations sociales mises à jour");
    setEditingSocial(false);
    onSave?.();
  };

  const sSet = (key: string, val: string) => setSocialForm(f => ({ ...f, [key]: val }));
  const inputStyle = { borderColor: "hsl(var(--border))", background: "hsl(var(--background))", height: 38 };

  const socialOrgs = [
    { label: "CNSS", numKey: "num_cnss", debutKey: "cnss_date_debut", finKey: "cnss_date_fin" },
    { label: "CIMR", numKey: "num_cimr", debutKey: "cimr_date_debut", finKey: "cimr_date_fin" },
    { label: "AMO", numKey: "num_amo", debutKey: "amo_date_debut", finKey: "amo_date_fin" },
  ];

  return (
    <div>
      <SectionCard title="Immatriculations sociales (fiche principale)" icon={<Shield size={15} />} action={
        !editingSocial ? (
          <button onClick={startEditSocial} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background: "hsl(var(--accent))", color: "white" }}>
            <Pencil size={12} /> Modifier
          </button>
        ) : null
      }>
        {editingSocial ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {socialOrgs.map(org => (
                <div key={org.label} className="rounded-lg p-3 space-y-2" style={{ background: "hsl(var(--muted) / 0.5)" }}>
                  <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "hsl(var(--accent))" }}>{org.label}</p>
                  <div>
                    <label className="block text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Numéro</label>
                    <input type="text" value={(socialForm as any)[org.numKey]} onChange={e => sSet(org.numKey, e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border text-sm" style={inputStyle} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Début</label>
                      <input type="date" value={(socialForm as any)[org.debutKey]} onChange={e => sSet(org.debutKey, e.target.value)}
                        min="1950-01-01" max="2099-12-31" className="w-full px-3 py-2 rounded-lg border text-sm" style={inputStyle} />
                    </div>
                    <div>
                      <label className="block text-xs font-medium mb-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Fin</label>
                      <input type="date" value={(socialForm as any)[org.finKey]} onChange={e => sSet(org.finKey, e.target.value)}
                        min="1950-01-01" max="2099-12-31" className="w-full px-3 py-2 rounded-lg border text-sm" style={inputStyle} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setEditingSocial(false)} className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg border font-semibold"
                style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground))" }}>
                <X size={13} /> Annuler
              </button>
              <button onClick={saveSocial} className="flex items-center gap-1 text-xs px-4 py-1.5 rounded-lg font-semibold"
                style={{ background: "hsl(var(--accent))", color: "white" }}>
                <Save size={13} /> Enregistrer
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { label: "CNSS", num: collab.num_cnss, debut: collab.cnss_date_debut, fin: collab.cnss_date_fin },
              { label: "CIMR", num: collab.num_cimr, debut: collab.cimr_date_debut, fin: collab.cimr_date_fin },
              { label: "AMO", num: collab.num_amo, debut: collab.amo_date_debut, fin: collab.amo_date_fin },
            ].map(org => (
              <div key={org.label} className="rounded-lg p-3 space-y-2" style={{ background: "hsl(var(--muted) / 0.5)" }}>
                <p className="text-xs font-bold uppercase tracking-wide" style={{ color: "hsl(var(--accent))" }}>{org.label}</p>
                <Field label="Numéro" value={org.num} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Début" value={org.debut ? new Date(org.debut).toLocaleDateString("fr-FR") : undefined} />
                  <Field label="Fin" value={org.fin ? new Date(org.fin).toLocaleDateString("fr-FR") : undefined} />
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      {/* Immatriculations supplémentaires */}
      <SectionCard title="Autres immatriculations" icon={<Shield size={15} />} action={
        <button className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background: "hsl(var(--accent))", color: "white" }}>
          <Plus size={12} />Ajouter
        </button>
      }>
        {immatriculations.length === 0
          ? <p className="text-sm text-center py-4" style={{ color: "hsl(var(--muted-foreground))" }}>Aucune immatriculation supplémentaire</p>
          : immatriculations.map(i => (
            <div key={i.id} className="p-3 rounded-lg border mb-2" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted) / 0.3)" }}>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <Field label="Numéro" value={i.numero_immatriculation} />
                <Field label="Organisme" value={i.code_organisme} />
                <Field label="Début" value={i.date_debut ? new Date(i.date_debut).toLocaleDateString("fr-FR") : undefined} />
                <Field label="Statut" value={i.statut_immatriculation} />
              </div>
            </div>
          ))
        }
      </SectionCard>
    </div>
  );
};

/* SYNDICAL — délégué au composant SyndicalMandatForm */
const TabSyndical: React.FC<{ collaborateurId: string }> = ({ collaborateurId }) => (
  <SyndicalMandatForm collaborateurId={collaborateurId} />
);

/* DIVERS */
const DIVERS_EMPTY = {
  metier_base: "",
  communication_autorisee: false,
  technicien: false,
  premier_emploi: false,
  permis_conduire: false,
  secouriste: false,
  pompier: false,
  electeur: false,
  eligible: false,
  membre_association: false,
  est_handicape: false,
  est_mutile: false,
  taux_ipp: "" as string,
  pension: "" as string,
  rente: "" as string,
  code_statut: "",
  code_situation: "",
};

const TabDivers: React.FC<{ collaborateurId: string }> = ({ collaborateurId }) => {
  const [divers, setDivers] = useState<any>(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(DIVERS_EMPTY);
  const [existingId, setExistingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("collaborateur_divers")
      .select("*")
      .eq("collaborateur_id", collaborateurId)
      .maybeSingle();

    if (data) {
      setDivers(data);
      setExistingId((data as any).id);
    } else {
      setDivers(null);
      setExistingId(null);
    }
  }, [collaborateurId]);

  useEffect(() => { load(); }, [load]);

  const startEdit = () => {
    if (divers) {
      setForm({
        metier_base: divers.metier_base || "",
        communication_autorisee: divers.communication_autorisee,
        technicien: divers.technicien,
        premier_emploi: divers.premier_emploi,
        permis_conduire: divers.permis_conduire,
        secouriste: divers.secouriste,
        pompier: divers.pompier,
        electeur: divers.electeur,
        eligible: divers.eligible,
        membre_association: divers.membre_association,
        est_handicape: divers.est_handicape,
        est_mutile: divers.est_mutile,
        taux_ipp: divers.taux_ipp != null ? String(divers.taux_ipp) : "",
        pension: divers.pension != null ? String(divers.pension) : "",
        rente: divers.rente != null ? String(divers.rente) : "",
        code_statut: divers.code_statut || "",
        code_situation: divers.code_situation || "",
      });
    } else {
      setForm(DIVERS_EMPTY);
    }
    setEditing(true);
  };

  const save = async () => {
    const payload: any = {
      collaborateur_id: collaborateurId,
      metier_base: form.metier_base || null,
      communication_autorisee: form.communication_autorisee,
      technicien: form.technicien,
      premier_emploi: form.premier_emploi,
      permis_conduire: form.permis_conduire,
      secouriste: form.secouriste,
      pompier: form.pompier,
      electeur: form.electeur,
      eligible: form.eligible,
      membre_association: form.membre_association,
      est_handicape: form.est_handicape,
      est_mutile: form.est_mutile,
      taux_ipp: form.taux_ipp ? parseFloat(form.taux_ipp) : null,
      pension: form.pension ? parseFloat(form.pension) : null,
      rente: form.rente ? parseFloat(form.rente) : null,
      code_statut: form.code_statut || null,
      code_situation: form.code_situation || null,
    };
    if (existingId) {
      const { error } = await supabase.from("collaborateur_divers").update(payload as any).eq("id", existingId);
      if (error) { toast.error(error.message); return; }
      toast.success("Informations diverses mises à jour");
    } else {
      const { error } = await supabase.from("collaborateur_divers").insert(payload as any);
      if (error) { toast.error(error.message); return; }
      toast.success("Informations diverses enregistrées");
    }
    setEditing(false);
    load();
  };

  const set = (key: string, val: any) => setForm(f => ({ ...f, [key]: val }));

  const inputStyle = { borderColor: "hsl(var(--border))", background: "hsl(var(--background))", height: 38 };

  const BoolToggle: React.FC<{ label: string; field: string }> = ({ label, field }) => (
    <div className="flex items-center justify-between py-1.5 px-2 rounded cursor-pointer"
      style={{ background: (form as any)[field] ? "hsl(84 55% 50% / 0.08)" : "transparent" }}
      onClick={() => set(field, !(form as any)[field])}>
      <span className="text-xs" style={{ color: "hsl(var(--foreground))" }}>{label}</span>
      <div className="w-5 h-5 rounded border flex items-center justify-center transition-colors"
        style={{
          borderColor: (form as any)[field] ? "hsl(var(--accent))" : "hsl(var(--border))",
          background: (form as any)[field] ? "hsl(var(--accent))" : "transparent",
        }}>
        {(form as any)[field] && <Check size={12} style={{ color: "white" }} />}
      </div>
    </div>
  );

  const BoolField: React.FC<{ label: string; value?: boolean }> = ({ label, value }) => (
    <div className="flex items-center justify-between py-1.5 px-2 rounded" style={{ background: value ? "hsl(84 55% 50% / 0.08)" : "transparent" }}>
      <span className="text-xs" style={{ color: "hsl(var(--foreground))" }}>{label}</span>
      <span className="text-xs font-semibold" style={{ color: value ? "hsl(84 55% 40%)" : "hsl(var(--muted-foreground))" }}>{value ? "Oui" : "Non"}</span>
    </div>
  );

  return (
    <div>
      <SectionCard title="Informations diverses" icon={<Settings size={15} />} action={
        !editing ? (
          <button onClick={startEdit} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background: "hsl(var(--accent))", color: "white" }}>
            {divers ? <><Pencil size={12} /> Modifier</> : <><Plus size={12} /> Saisir</>}
          </button>
        ) : null
      }>
        {editing ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Indicateurs */}
              <div>
                <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "hsl(var(--accent))" }}>Indicateurs</p>
                <div className="space-y-1 rounded-lg p-2" style={{ background: "hsl(var(--muted) / 0.3)" }}>
                  <BoolToggle label="Communication autorisée" field="communication_autorisee" />
                  <BoolToggle label="Technicien" field="technicien" />
                  <BoolToggle label="Premier emploi" field="premier_emploi" />
                  <BoolToggle label="Permis de conduire" field="permis_conduire" />
                  <BoolToggle label="Secouriste" field="secouriste" />
                  <BoolToggle label="Pompier" field="pompier" />
                  <BoolToggle label="Électeur" field="electeur" />
                  <BoolToggle label="Éligible" field="eligible" />
                  <BoolToggle label="Membre association" field="membre_association" />
                </div>
              </div>
              {/* Handicap */}
              <div>
                <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "hsl(0 84% 60%)" }}>Handicap / Invalidité</p>
                <div className="space-y-1 rounded-lg p-2 mb-3" style={{ background: "hsl(var(--muted) / 0.3)" }}>
                  <BoolToggle label="Est handicapé" field="est_handicape" />
                  <BoolToggle label="Est mutilé" field="est_mutile" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium mb-1" style={{ color: "hsl(var(--muted-foreground))" }}>Taux IPP (%)</label>
                    <input type="number" step="0.01" min="0" max="100" value={form.taux_ipp} onChange={e => set("taux_ipp", e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border text-sm" style={inputStyle} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1" style={{ color: "hsl(var(--muted-foreground))" }}>Pension</label>
                    <input type="number" step="0.01" min="0" value={form.pension} onChange={e => set("pension", e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border text-sm" style={inputStyle} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1" style={{ color: "hsl(var(--muted-foreground))" }}>Rente</label>
                    <input type="number" step="0.01" min="0" value={form.rente} onChange={e => set("rente", e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border text-sm" style={inputStyle} />
                  </div>
                  <div>
                    <label className="block text-xs font-medium mb-1" style={{ color: "hsl(var(--muted-foreground))" }}>Métier de base</label>
                    <input type="text" value={form.metier_base} onChange={e => set("metier_base", e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border text-sm" style={inputStyle} />
                  </div>
                </div>
              </div>
            </div>
            {/* Statut & Situation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <RefSelect label="Statut" table="ref_statut" value={form.code_statut} onChange={v => set("code_statut", v)} />
              <RefSelect label="Situation" table="ref_situation" value={form.code_situation} onChange={v => set("code_situation", v)} />
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setEditing(false)} className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg border font-semibold"
                style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground))" }}>
                <X size={13} /> Annuler
              </button>
              <button onClick={save} className="flex items-center gap-1 text-xs px-4 py-1.5 rounded-lg font-semibold"
                style={{ background: "hsl(var(--accent))", color: "white" }}>
                <Save size={13} /> Enregistrer
              </button>
            </div>
          </div>
        ) : !divers ? (
          <p className="text-sm text-center py-8" style={{ color: "hsl(var(--muted-foreground))" }}>Aucune information diverse enregistrée</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "hsl(var(--accent))" }}>Indicateurs</p>
              <div className="space-y-1 rounded-lg p-2" style={{ background: "hsl(var(--muted) / 0.3)" }}>
                <BoolField label="Communication autorisée" value={divers.communication_autorisee} />
                <BoolField label="Technicien" value={divers.technicien} />
                <BoolField label="Premier emploi" value={divers.premier_emploi} />
                <BoolField label="Permis de conduire" value={divers.permis_conduire} />
                <BoolField label="Secouriste" value={divers.secouriste} />
                <BoolField label="Pompier" value={divers.pompier} />
                <BoolField label="Électeur" value={divers.electeur} />
                <BoolField label="Éligible" value={divers.eligible} />
                <BoolField label="Membre association" value={divers.membre_association} />
              </div>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-wide mb-2" style={{ color: "hsl(0 84% 60%)" }}>Handicap / Invalidité</p>
              <div className="space-y-1 rounded-lg p-2 mb-3" style={{ background: "hsl(var(--muted) / 0.3)" }}>
                <BoolField label="Est handicapé" value={divers.est_handicape} />
                <BoolField label="Est mutilé" value={divers.est_mutile} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Taux IPP (%)" value={divers.taux_ipp != null ? `${divers.taux_ipp}%` : undefined} />
                <Field label="Pension" value={divers.pension != null ? `${divers.pension}` : undefined} />
                <Field label="Rente" value={divers.rente != null ? `${divers.rente}` : undefined} />
                <Field label="Métier de base" value={divers.metier_base} />
              </div>
            </div>
          </div>
        )}
      </SectionCard>
    </div>
  );
};

/* ──────────────── HEADER AVEC PHOTO ──────────────── */
const CollabHeader: React.FC<{
  collab: Collaborateur;
  statutStyle: { bg: string; color: string };
  onPhotoUpdated: () => void;
}> = ({ collab, statutStyle, onPhotoUpdated }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handlePhotoClick = () => fileInputRef.current?.click();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `${collab.id}/photo.${ext}`;
      // Supprimer l'ancienne photo si elle existe
      await supabase.storage.from("photos_collaborateurs").remove([path]);
      const { error: uploadError } = await supabase.storage
        .from("photos_collaborateurs")
        .upload(path, file, { upsert: true });
      if (!uploadError) {
        const { data } = supabase.storage.from("photos_collaborateurs").getPublicUrl(path);
        await supabase.from("collaborateurs")
          .update({ photo_path: data.publicUrl })
          .eq("id", collab.id);
        onPhotoUpdated();
      }
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const initials = `${collab.prenom?.[0] || ""}${collab.nom?.[0] || ""}`.toUpperCase();

  return (
    <div className="rounded-xl p-5 mb-5 flex items-start gap-5" style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", boxShadow: "var(--shadow-md)" }}>
      {/* Avatar cliquable */}
      <div className="relative flex-shrink-0 group cursor-pointer" onClick={handlePhotoClick} title="Changer la photo">
        {collab.photo_path ? (
          <img
            src={collab.photo_path}
            alt={`${collab.prenom} ${collab.nom}`}
            className="w-20 h-20 rounded-full object-cover border-2"
            style={{ borderColor: "hsl(var(--border))" }}
          />
        ) : (
          <div className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold border-2"
            style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))", borderColor: "hsl(var(--border))" }}>
            {initials}
          </div>
        )}
        {/* Overlay au hover */}
        <div className="absolute inset-0 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ background: "hsl(var(--foreground) / 0.45)" }}>
          {uploading
            ? <div className="w-5 h-5 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: "white", borderTopColor: "transparent" }} />
            : <Camera size={18} style={{ color: "white" }} />
          }
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-3 flex-wrap">
          <h1 className="text-xl font-bold" style={{ color: "hsl(var(--foreground))" }}>
            {collab.civilite ? `${collab.civilite} ` : ""}{collab.prenom} {collab.nom}
          </h1>
          <span className="text-sm px-2.5 py-0.5 rounded-full font-medium" style={{ background: statutStyle.bg, color: statutStyle.color }}>
            {collab.statut_collaborateur}
          </span>
        </div>
        <div className="flex items-center gap-4 mt-1.5 flex-wrap">
          <span className="text-sm font-semibold" style={{ color: "hsl(var(--accent))" }}>#{collab.matricule}</span>
          {collab.email_professionnel && <span className="text-sm flex items-center gap-1" style={{ color: "hsl(var(--muted-foreground))" }}><Mail size={12} />{collab.email_professionnel}</span>}
          {collab.gsm && <span className="text-sm flex items-center gap-1" style={{ color: "hsl(var(--muted-foreground))" }}><Phone size={12} />{collab.gsm}</span>}
          {collab.date_naissance && <span className="text-sm flex items-center gap-1" style={{ color: "hsl(var(--muted-foreground))" }}><Calendar size={12} />{new Date(collab.date_naissance).toLocaleDateString("fr-FR")}</span>}
        </div>
        <p className="text-xs mt-1" style={{ color: "hsl(var(--muted-foreground))" }}>
          <Camera size={10} className="inline mr-1 opacity-50" />Cliquer sur la photo pour la modifier
        </p>
      </div>
    </div>
  );
};

// RG-MGR-FICHE-01 : Le manager n'accède qu'aux onglets Identité, Contrats, Affectation, Rémunération en lecture seule
const TABS_MANAGER = ["identite", "contrats", "affectation", "remuneration"];

/* ──────────────── PAGE PRINCIPALE ──────────────── */
const FicheCollaborateur: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { role } = useAuth();
  const queryClient = useQueryClient();
  const [collab, setCollab] = useState<Collaborateur | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("identite");
  const [showDepartForm, setShowDepartForm] = useState(false);

  const isManager = role === "manager";
  const visibleTabs = isManager ? TABS.filter(t => TABS_MANAGER.includes(t.id)) : TABS;

  const [accessBlocked, setAccessBlocked] = useState(false);

  const loadCollab = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      // Charger le collaborateur depuis l'API
      const { data, error } = await supabase
        .from("collaborateurs")
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (error) {
        console.error("Erreur chargement collaborateur:", error);
        setCollab(null);
        setLoading(false);
        return;
      }

      if (data) {
        const c = data as Collaborateur;
        // CNDP : vérifier la rétention si le collaborateur est SORTI
        if (c.statut_collaborateur === "SORTI") {
          const [{ data: retParam }, { data: depData }] = await Promise.all([
            supabase.from("parametres_rh").select("valeur").eq("code", "DUREE_RETENTION_SORTIS").eq("actif", true).single(),
            supabase.from("collaborateur_departs").select("date_depart").eq("collaborateur_id", id).eq("statut", "TRAITE").order("date_depart", { ascending: false }).limit(1),
          ]);
          const retYears = (retParam as any)?.valeur ? parseInt((retParam as any).valeur, 10) : null;
          if (retYears && retYears > 0 && depData && depData.length > 0) {
            const cutoff = new Date();
            cutoff.setFullYear(cutoff.getFullYear() - retYears);
            if (new Date((depData as any[])[0].date_depart) < cutoff) {
              setAccessBlocked(true);
              setLoading(false);
              return;
            }
          }
        }
        setCollab(c);
      } else {
        setCollab(null);
      }
    } catch (e) {
      console.error("Exception chargement collaborateur:", e);
      setCollab(null);
    }
    setLoading(false);
  }, [id]);

  useEffect(() => { loadCollab(); }, [loadCollab]);

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: "hsl(var(--accent))", borderTopColor: "transparent" }} />
    </div>
  );

  if (accessBlocked) return (
    <div className="p-6 text-center">
      <AlertCircle size={40} className="mx-auto mb-3" style={{ color: "hsl(var(--destructive))" }} />
      <p className="font-semibold mb-1" style={{ color: "hsl(var(--foreground))" }}>Accès restreint</p>
      <p className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>
        La durée de rétention des données de ce collaborateur sorti a expiré (conformité CNDP).
      </p>
      <button onClick={() => navigate("/collaborateurs")} className="mt-4 text-sm underline" style={{ color: "hsl(var(--accent))" }}>Retour à la liste</button>
    </div>
  );

  if (!collab) return (
    <div className="p-6 text-center">
      <p style={{ color: "hsl(var(--muted-foreground))" }}>Collaborateur introuvable</p>
      <button onClick={() => navigate("/collaborateurs")} className="mt-4 text-sm underline" style={{ color: "hsl(var(--accent))" }}>Retour à la liste</button>
    </div>
  );

  const statutStyle =
    collab.statut_collaborateur === "ACTIF"
      ? { bg: "hsl(84 55% 50% / 0.15)", color: "hsl(84 55% 35%)" }
      : collab.statut_collaborateur === "EN_DEPART"
        ? { bg: "hsl(45 100% 50% / 0.15)", color: "hsl(45 100% 30%)" }
        : { bg: "hsl(215 20% 55% / 0.15)", color: "hsl(215 20% 40%)" };

  return (
    <div className="p-6">
      {/* Breadcrumb & Back */}
      <div className="flex items-center justify-between mb-4">
        <button onClick={() => navigate(isManager ? "/dashboard" : "/collaborateurs")} className="flex items-center gap-1.5 text-sm hover:underline" style={{ color: "hsl(var(--accent))" }}>
          <ArrowLeft size={15} />{isManager ? "Retour au tableau de bord" : "Retour à la liste"}
        </button>
        <div className="flex items-center gap-2">
          {isManager && (
            <span className="text-xs px-2 py-1 rounded-full font-medium" style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}>
              👁 Lecture seule
            </span>
          )}
          {/* RG-DEP-BTN-01 : Bouton départ disponible pour Admin/RH uniquement, sauf si déjà SORTI */}
          {!isManager && collab.statut_collaborateur !== "SORTI" && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(`/absences/saisie?collaborateur=${collab.id}`)}
                className="flex items-center gap-1.5 text-xs"
                style={{ borderColor: "hsl(var(--accent) / 0.4)", color: "hsl(var(--accent))" }}
              >
                <Plane size={13} />
                Saisir un congé
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(`/departs-provisoires?collaborateur=${collab.id}`)}
                className="flex items-center gap-1.5 text-xs"
                style={{ borderColor: "hsl(25 90% 48% / 0.4)", color: "hsl(25 90% 48%)" }}
              >
                <Clock size={13} />
                Départ provisoire
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDepartForm(true)}
                className="flex items-center gap-1.5 text-xs"
                style={{ borderColor: "hsl(0 70% 50% / 0.4)", color: "hsl(0 70% 40%)" }}
              >
                <DoorOpen size={13} />
                {collab.statut_collaborateur === "EN_DEPART" ? "Voir le départ" : "Enregistrer un départ"}
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Bandeau EN_DEPART */}
      {collab.statut_collaborateur === "EN_DEPART" && (
        <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl mb-4"
          style={{ background: "hsl(45 100% 50% / 0.10)", border: "1px solid hsl(45 100% 50% / 0.25)" }}>
          <DoorOpen size={15} style={{ color: "hsl(45 100% 30%)", flexShrink: 0 }} />
          <p className="text-xs font-medium" style={{ color: "hsl(45 100% 30%)" }}>
            Ce collaborateur est en phase de départ. Le traitement automatique s'exécutera à la date de départ planifiée.
          </p>
        </div>
      )}

      {/* Header fiche */}
      <CollabHeader collab={collab} statutStyle={statutStyle} onPhotoUpdated={isManager ? () => {} : loadCollab} />

      {/* Onglets */}
      <div className="flex gap-1 overflow-x-auto pb-1 mb-5 border-b" style={{ borderColor: "hsl(var(--border))" }}>
        {visibleTabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-t-lg whitespace-nowrap transition-all border-b-2"
            style={{
              borderBottomColor: activeTab === tab.id ? "hsl(var(--accent))" : "transparent",
              color: activeTab === tab.id ? "hsl(var(--accent))" : "hsl(var(--muted-foreground))",
              background: activeTab === tab.id ? "hsl(var(--accent) / 0.06)" : "transparent",
            }}>
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {/* Contenu onglet — manager : lecture seule via pointer-events-none */}
      <div className={isManager ? "pointer-events-none select-none opacity-90" : ""}>
        {activeTab === "identite" && <TabIdentite collab={collab} onSave={loadCollab} />}
        {activeTab === "contrats" && <TabContrats collaborateurId={collab.id} ancienMatricule={collab.ancien_matricule} />}
        {activeTab === "affectation" && <TabAffectation collaborateurId={collab.id} ancienMatricule={collab.ancien_matricule} />}
        
        {!isManager && activeTab === "famille" && <TabFamille collaborateurId={collab.id} />}
        {activeTab === "remuneration" && <TabRemuneration collaborateurId={collab.id} />}
        {!isManager && activeTab === "formation" && <TabFormation collaborateurId={collab.id} />}
        {!isManager && activeTab === "immatriculation" && <TabImmatriculation collaborateurId={collab.id} collab={collab} onSave={loadCollab} />}
        {!isManager && activeTab === "syndical" && <TabSyndical collaborateurId={collab.id} />}
        {!isManager && activeTab === "divers" && <TabDivers collaborateurId={collab.id} />}
      </div>

      {/* Modal départ */}
      {showDepartForm && (
        <DepartForm
          collaborateurId={collab.id}
          onClose={() => setShowDepartForm(false)}
          onSuccess={() => {
            setShowDepartForm(false);
            loadCollab();
            queryClient.invalidateQueries({ queryKey: ["departs"] });
          }}
        />
      )}
    </div>
  );
};

export default FicheCollaborateur;
