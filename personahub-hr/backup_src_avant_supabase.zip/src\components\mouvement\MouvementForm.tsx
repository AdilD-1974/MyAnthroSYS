import React, { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, Save, X, Copy, ArrowRightLeft, AlertCircle } from "lucide-react";
import RefSelect from "@/components/RefSelect";
import { toast } from "sonner";

interface Mouvement {
  id: string;
  collaborateur_id: string;
  code_type_mouvement: string;
  date_effet: string;
  date_fin_prevue: string | null;
  date_fin_effective: string | null;
  ancien_poste: string | null;
  ancienne_unite_id: string | null;
  nouveau_poste: string | null;
  nouvelle_unite_id: string | null;
  reference_decision: string | null;
  date_decision: string | null;
  commentaire: string | null;
  statut: string;
  archive: boolean;
}

interface Props {
  collaborateurId: string;
}

const EMPTY: Partial<Mouvement> = {
  code_type_mouvement: "",
  date_effet: "",
  date_fin_prevue: null,
  date_fin_effective: null,
  ancien_poste: null,
  ancienne_unite_id: null,
  nouveau_poste: null,
  nouvelle_unite_id: null,
  reference_decision: null,
  date_decision: null,
  commentaire: null,
  statut: "ACTIF",
};

const MouvementForm: React.FC<Props> = ({ collaborateurId }) => {
  const [rows, setRows] = useState<Mouvement[]>([]);
  const [editing, setEditing] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<Mouvement>>({});
  const [adding, setAdding] = useState(false);
  const [loading, setLoading] = useState(true);
  const [uoMap, setUoMap] = useState<Record<string, string>>({});
  const [typeMap, setTypeMap] = useState<Record<string, { libelle: string; est_temporaire: boolean; est_definitif: boolean }>>({});
  const [currentAffectation, setCurrentAffectation] = useState<{ code_poste: string | null; unite_id: string | null; poste_libelle: string; uo_libelle: string; emploi_libelle: string }>({ code_poste: null, unite_id: null, poste_libelle: "", uo_libelle: "", emploi_libelle: "" });
  const [allPostes, setAllPostes] = useState<{ code: string; libelle: string; unite_id: string | null; code_emploi: string | null }[]>([]);
  const [filteredPostes, setFilteredPostes] = useState<{ code: string; libelle: string; code_emploi: string | null }[]>([]);
  const [emploiMap, setEmploiMap] = useState<Record<string, string>>({});
  const [posteLibelleMap, setPosteLibelleMap] = useState<Record<string, string>>({});

  const load = async () => {
    setLoading(true);
    const data = []; const error = null; // Supabase desactive
    setRows((data as any[]) || []);
    setLoading(false);
  };

  // Fetch current affectation for auto-fill of ancien poste/UO
  const loadCurrentAffectation = async () => {
    const data = []; const error = null; // Supabase desactive
    const aff = (data as any[])?.[0];
    if (aff) {
      let posteLib = aff.code_poste || "";
      let uoLib = "";
      let emploiLib = "";
      if (aff.code_poste) {
        // code_poste in affectations is an instance code (e.g. RSADM-001)
        // Resolve: instance -> parent poste -> emploi
        const data = []; const error = null; // Supabase desactive
        const parentCode = (inst as any[])?.[0]?.code_poste || aff.code_poste;
        const data = []; const error = null; // Supabase desactive
        if ((p as any[])?.[0]) {
          posteLib = (p as any[])[0].libelle;
          const codeEmploi = (p as any[])[0].code_emploi;
          if (codeEmploi) {
            const data = []; const error = null; // Supabase desactive
            if ((e as any[])?.[0]) emploiLib = (e as any[])[0].libelle;
          }
        }
      }
      if (aff.unite_id) {
        const data = []; const error = null; // Supabase desactive
        if ((u as any[])?.[0]) uoLib = (u as any[])[0].libelle;
      }
      setCurrentAffectation({ code_poste: aff.code_poste, unite_id: aff.unite_id, poste_libelle: posteLib, uo_libelle: uoLib, emploi_libelle: emploiLib });
    }
  };

  useEffect(() => {
    load();
    loadCurrentAffectation();
    // Load UO map
    supabase.from("unites_organisationnelles" as any).select("id, libelle").then(({ data }) => {
      const m: Record<string, string> = {};
      ((data as any[]) || []).forEach((r: any) => { m[r.id] = r.libelle; });
      setUoMap(m);
    });
    // Load type mouvement map
    supabase.from("ref_type_mouvement" as any).select("code, libelle, est_temporaire, est_definitif").eq("actif", true).then(({ data }) => {
      const m: Record<string, { libelle: string; est_temporaire: boolean; est_definitif: boolean }> = {};
      ((data as any[]) || []).forEach((r: any) => { m[r.code] = { libelle: r.libelle, est_temporaire: r.est_temporaire, est_definitif: !!r.est_definitif }; });
      setTypeMap(m);
    });
    // Load all postes with code_emploi
    supabase.from("ref_poste" as any).select("code, libelle, unite_id, code_emploi").eq("actif", true).then(({ data }) => {
      setAllPostes((data as any[]) || []);
      // Build poste libelle map for display
      const pm: Record<string, string> = {};
      ((data as any[]) || []).forEach((r: any) => { pm[r.code] = r.libelle; });
      setPosteLibelleMap(pm);
    });
    // Load emploi map
    supabase.from("ref_emploi" as any).select("code, libelle").eq("actif", true).then(({ data }) => {
      const m: Record<string, string> = {};
      ((data as any[]) || []).forEach((r: any) => { m[r.code] = r.libelle; });
      setEmploiMap(m);
    });
  }, [collaborateurId]);

  // Filter postes when nouvelle_unite_id changes
  useEffect(() => {
    if (form.nouvelle_unite_id) {
      setFilteredPostes(allPostes.filter(p => p.unite_id === form.nouvelle_unite_id));
    } else {
      setFilteredPostes([]);
    }
  }, [form.nouvelle_unite_id, allPostes]);

  const startAdd = () => {
    setForm({
      ...EMPTY,
      ancien_poste: currentAffectation.code_poste,
      ancienne_unite_id: currentAffectation.unite_id,
    });
    setAdding(true);
    setEditing(null);
  };

  const save = async () => {
    if (!form.code_type_mouvement || !form.date_effet) {
      toast.error("Type de mouvement et date d'effet sont obligatoires");
      return;
    }
    const isDefinitif = typeMap[form.code_type_mouvement]?.est_definitif ?? false;

    if (isDefinitif && !form.nouvelle_unite_id) {
      toast.error("La nouvelle UO est obligatoire pour un mouvement définitif");
      return;
    }

    if (editing) {
      const { error } = await supabase.from("collaborateur_mouvements" as any)
        .update({ ...form, updated_at: new Date().toISOString() } as any)
        .eq("id", editing);
      if (error) { toast.error(error.message); return; }
      toast.success("Mouvement mis à jour");
    } else {
      const { error } = await supabase.from("collaborateur_mouvements" as any)
        .insert({ ...form, collaborateur_id: collaborateurId } as any);
      if (error) { toast.error(error.message); return; }

      // Si mouvement définitif → clôturer ancienne affectation et créer la nouvelle
      if (isDefinitif) {
        await handleDefinitifAffectation();
      }

      toast.success("Mouvement ajouté");
    }
    setEditing(null);
    setAdding(false);
    setForm({});
    load();
    loadCurrentAffectation();
  };

  const recalcParentPosteState = async (codeInstance: string) => {
    const codeParent = codeInstance.includes("-") ? codeInstance.split("-").slice(0, -1).join("-") : codeInstance;
    const { data: instances } = await (supabase.from("ref_poste_instances" as never)
      .select("code_etat").eq("code_poste" as never, codeParent as never) as any);
    const etats = ((instances as any[]) || []).map((i: any) => i.code_etat);
    let newEtat = "VA";
    if (etats.some((e: string) => e === "AT")) newEtat = "AT";
    else if (etats.some((e: string) => e === "EC")) newEtat = "EC";
    await (supabase.from("ref_poste" as never)
      .update({ code_etat_poste: newEtat } as never)
      .eq("code" as never, codeParent as never) as any);
  };

  const handleDefinitifAffectation = async () => {
    const dateEffet = form.date_effet!;
    const dEffet = new Date(dateEffet);
    const dCloture = new Date(dEffet.getFullYear(), dEffet.getMonth(), dEffet.getDate() - 1);
    const dateCloture = `${dCloture.getFullYear()}-${String(dCloture.getMonth() + 1).padStart(2, "0")}-${String(dCloture.getDate()).padStart(2, "0")}`;

    // 1. Clôturer l'affectation active
    await supabase.from("collaborateur_affectations")
      .update({
        date_fin_uo: dateCloture,
        date_fin_poste: dateCloture,
        updated_at: new Date().toISOString(),
      })
      .eq("collaborateur_id", collaborateurId)
      .eq("archive", false)
      .is("date_fin_uo", null);

    // 2. Libérer l'ancienne instance de poste → Vacant (VA)
    if (currentAffectation.code_poste) {
      await (supabase.from("ref_poste_instances" as never)
        .update({ code_etat: "VA", collaborateur_id: null } as never)
        .eq("code_instance" as never, currentAffectation.code_poste as never) as any);
      await recalcParentPosteState(currentAffectation.code_poste);
    }

    // 3. Trouver une instance vacante du nouveau poste sélectionné (form.nouveau_poste = code parent)
    let instanceCode: string | null = null;
    if (form.nouveau_poste) {
      const { data: vacantInstances } = await (supabase.from("ref_poste_instances" as never)
        .select("code_instance" as never)
        .eq("code_poste" as never, form.nouveau_poste as never)
        .eq("code_etat" as never, "VA" as never)
        .eq("archive" as never, false as never)
        .limit(1) as any);
      instanceCode = (vacantInstances as any[])?.[0]?.code_instance || null;

      if (!instanceCode) {
        toast.error("Aucune instance vacante pour le poste sélectionné");
        return;
      }

      // Attribuer l'instance → AT
      await (supabase.from("ref_poste_instances" as never)
        .update({ code_etat: "AT", collaborateur_id: collaborateurId } as never)
        .eq("code_instance" as never, instanceCode as never) as any);
      await recalcParentPosteState(instanceCode);
    }

    // 4. Mettre à jour le mouvement avec le code instance réel
    if (instanceCode && form.nouveau_poste) {
      // Update the mouvement record to store the instance code
      const data = []; const error = null; // Supabase desactive
      if ((lastMvt as any[])?.[0]) {
        await supabase.from("collaborateur_mouvements" as any)
          .update({ nouveau_poste: instanceCode } as any)
          .eq("id", (lastMvt as any[])[0].id);
      }
    }

    // 5. Créer la nouvelle affectation avec le code instance
    const newAff: any = {
      collaborateur_id: collaborateurId,
      unite_id: form.nouvelle_unite_id,
      date_debut_uo: dateEffet,
      date_debut_poste: instanceCode ? dateEffet : null,
      code_poste: instanceCode || null,
      motif_affectation: form.code_type_mouvement,
      commentaire: `Mouvement définitif — ${typeMap[form.code_type_mouvement]?.libelle || form.code_type_mouvement}`,
    };

    const { error: affErr } = await supabase.from("collaborateur_affectations").insert(newAff);
    if (affErr) {
      toast.error("Mouvement enregistré, mais erreur lors de la création de l'affectation : " + affErr.message);
    } else {
      toast.success("Nouvelle affectation créée automatiquement");
    }

    // 6. RG-UO-RESP-DYNAMIC : Mise à jour dynamique des responsables des UO impactées
    await updateUoResponsables(currentAffectation.unite_id, form.nouvelle_unite_id, instanceCode);
  };

  const updateUoResponsables = async (ancienneUoId: string | null, nouvelleUoId: string | null | undefined, nouveauPosteInstance: string | null) => {
    // a) Si le collaborateur quitte son ancienne UO, vérifier s'il était le responsable
    if (ancienneUoId) {
      const data = []; const error = null; // Supabase desactive
      if (ancienneUo && (ancienneUo as any).responsable_id === collaborateurId) {
        // Le collaborateur était le responsable → mettre à null
        await supabase.from("unites_organisationnelles" as any)
          .update({ responsable_id: null, responsable_temporaire: null } as any)
          .eq("id", ancienneUoId);
        toast.info("Le responsable de l'ancienne UO a été libéré automatiquement");
      }
    }

    // b) Si le nouveau poste est le poste_responsable_code de la nouvelle UO → le collaborateur devient responsable
    if (nouvelleUoId && nouveauPosteInstance) {
      const codePosteParent = nouveauPosteInstance.includes("-") ? nouveauPosteInstance.split("-").slice(0, -1).join("-") : nouveauPosteInstance;
      const data = []; const error = null; // Supabase desactive
      if (nouvelleUo && (nouvelleUo as any).poste_responsable_code === codePosteParent) {
        await supabase.from("unites_organisationnelles" as any)
          .update({ responsable_id: collaborateurId, responsable_temporaire: false } as any)
          .eq("id", nouvelleUoId);
        toast.info("Le collaborateur est devenu responsable de la nouvelle UO");
      }
    }
  };

  const remove = async (id: string) => {
    if (!confirm("Supprimer ce mouvement ?")) return;
    await supabase.from("collaborateur_mouvements" as any).update({ archive: true } as any).eq("id", id);
    toast.success("Mouvement archivé");
    load();
  };

  const duplicate = (row: Mouvement) => {
    setForm({
      ...EMPTY,
      code_type_mouvement: row.code_type_mouvement,
      ancien_poste: row.nouveau_poste,
      ancienne_unite_id: row.nouvelle_unite_id,
      date_effet: "",
    });
    setAdding(true);
    setEditing(null);
  };

  const cloturer = async (id: string) => {
    const today = new Date().toISOString().split("T")[0];
    await supabase.from("collaborateur_mouvements" as any)
      .update({ statut: "CLOTURE", date_fin_effective: today } as any)
      .eq("id", id);
    toast.success("Mouvement clôturé");
    load();
  };

  const isTemporaire = (code: string) => typeMap[code]?.est_temporaire ?? false;

  // Alerte: mouvements temporaires sans date fin prévue ou dépassée
  const alertes = rows.filter(r => {
    if (r.statut !== "ACTIF" || !isTemporaire(r.code_type_mouvement)) return false;
    if (!r.date_fin_prevue) return true;
    const today = new Date();
    const fin = new Date(r.date_fin_prevue);
    const diff = (fin.getTime() - today.getTime()) / (1000 * 60 * 60 * 24);
    return diff <= 30; // Alerte 30 jours avant
  });

  const labelStyle: React.CSSProperties = { fontSize: 11, fontWeight: 600, color: "hsl(var(--muted-foreground))", marginBottom: 2 };
  const inputStyle: React.CSSProperties = {
    width: "100%", padding: "6px 10px", borderRadius: 8, fontSize: 13,
    border: "1px solid hsl(var(--border))", background: "hsl(var(--background))",
    color: "hsl(var(--foreground))",
  };

  const renderForm = () => (
    <div className="rounded-xl border p-4 mb-3" style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <p style={labelStyle}>Type de mouvement *</p>
          <RefSelect table="ref_type_mouvement" value={form.code_type_mouvement || ""} onChange={v => setForm(f => ({ ...f, code_type_mouvement: v }))} label="" />
        </div>
        <div>
          <p style={labelStyle}>Date d'effet *</p>
          <input type="date" style={inputStyle} value={form.date_effet || ""} onChange={e => setForm(f => ({ ...f, date_effet: e.target.value }))} />
        </div>
        <div>
          <p style={labelStyle}>Statut</p>
          <select style={inputStyle} value={form.statut || "ACTIF"} onChange={e => setForm(f => ({ ...f, statut: e.target.value }))}>
            <option value="ACTIF">Actif</option>
            <option value="CLOTURE">Clôturé</option>
            <option value="ANNULE">Annulé</option>
          </select>
        </div>
      </div>

      {/* Temporaire: dates fin */}
      {isTemporaire(form.code_type_mouvement || "") && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
          <div>
            <p style={labelStyle}>Date fin prévue</p>
            <input type="date" style={inputStyle} value={form.date_fin_prevue || ""} onChange={e => setForm(f => ({ ...f, date_fin_prevue: e.target.value || null }))} />
          </div>
          <div>
            <p style={labelStyle}>Date fin effective</p>
            <input type="date" style={inputStyle} value={form.date_fin_effective || ""} onChange={e => setForm(f => ({ ...f, date_fin_effective: e.target.value || null }))} />
          </div>
        </div>
      )}

      {/* Ancienne situation (lecture seule) */}
      <p className="text-[11px] font-semibold mt-4 mb-1" style={{ color: "hsl(var(--accent))" }}>Ancienne situation (affectation actuelle)</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <p style={labelStyle}>Ancienne UO</p>
          <input style={{ ...inputStyle, background: "hsl(var(--muted) / 0.3)", cursor: "not-allowed" }} readOnly
            value={currentAffectation.uo_libelle || (form.ancienne_unite_id ? uoMap[form.ancienne_unite_id] || "" : "—")} />
        </div>
        <div>
          <p style={labelStyle}>Ancien poste</p>
          <input style={{ ...inputStyle, background: "hsl(var(--muted) / 0.3)", cursor: "not-allowed" }} readOnly
            value={currentAffectation.emploi_libelle || currentAffectation.poste_libelle || form.ancien_poste || "—"} />
        </div>
      </div>

      {/* Nouvelle situation */}
      <p className="text-[11px] font-semibold mt-4 mb-1" style={{ color: "hsl(var(--accent))" }}>Nouvelle situation</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <p style={labelStyle}>Nouvelle UO *</p>
          <select style={inputStyle} value={form.nouvelle_unite_id || ""} onChange={e => setForm(f => ({ ...f, nouvelle_unite_id: e.target.value || null, nouveau_poste: null }))}>
            <option value="">— Sélectionner une UO —</option>
            {Object.entries(uoMap).map(([id, lib]) => <option key={id} value={id}>{lib}</option>)}
          </select>
        </div>
        <div>
          <p style={labelStyle}>Nouveau poste</p>
          <select style={inputStyle} value={form.nouveau_poste || ""} onChange={e => setForm(f => ({ ...f, nouveau_poste: e.target.value || null }))}
            disabled={!form.nouvelle_unite_id}>
            <option value="">{form.nouvelle_unite_id ? "— Sélectionner un poste —" : "— Choisir d'abord une UO —"}</option>
            {filteredPostes.map(p => <option key={p.code} value={p.code}>{p.libelle}</option>)}
          </select>
          {form.nouveau_poste && (() => {
            const poste = allPostes.find(p => p.code === form.nouveau_poste);
            const emploiLib = poste?.code_emploi ? emploiMap[poste.code_emploi] : null;
            return emploiLib ? (
              <p className="text-[10px] mt-1 italic" style={{ color: "hsl(var(--muted-foreground))" }}>
                Emploi : <strong>{emploiLib}</strong>
              </p>
            ) : null;
          })()}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
        <div>
          <p style={labelStyle}>Réf. décision</p>
          <input style={inputStyle} value={form.reference_decision || ""} onChange={e => setForm(f => ({ ...f, reference_decision: e.target.value }))} />
        </div>
        <div>
          <p style={labelStyle}>Date décision</p>
          <input type="date" style={inputStyle} value={form.date_decision || ""} onChange={e => setForm(f => ({ ...f, date_decision: e.target.value || null }))} />
        </div>
      </div>

      <div className="mt-3">
        <p style={labelStyle}>Commentaire</p>
        <textarea style={{ ...inputStyle, minHeight: 60 }} value={form.commentaire || ""} onChange={e => setForm(f => ({ ...f, commentaire: e.target.value }))} />
      </div>

      <div className="flex gap-2 mt-3">
        <Button size="sm" onClick={save}><Save size={13} className="mr-1" />{editing ? "Mettre à jour" : "Enregistrer"}</Button>
        <Button size="sm" variant="ghost" onClick={() => { setEditing(null); setAdding(false); setForm({}); }}><X size={13} className="mr-1" />Annuler</Button>
      </div>
    </div>
  );

  const statutBadge = (statut: string) => {
    const colors: Record<string, { bg: string; text: string }> = {
      ACTIF: { bg: "hsl(142 70% 45% / 0.12)", text: "hsl(142 70% 30%)" },
      CLOTURE: { bg: "hsl(220 15% 50% / 0.12)", text: "hsl(220 15% 40%)" },
      ANNULE: { bg: "hsl(0 70% 50% / 0.12)", text: "hsl(0 70% 35%)" },
    };
    const c = colors[statut] || colors.ACTIF;
    return <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold" style={{ background: c.bg, color: c.text }}>{statut}</span>;
  };

  return (
    <div>
      {/* Alertes retour */}
      {alertes.length > 0 && (
        <div className="flex items-start gap-2 px-4 py-3 rounded-xl mb-4" style={{ background: "hsl(45 100% 50% / 0.10)", border: "1px solid hsl(45 100% 50% / 0.25)" }}>
          <AlertCircle size={15} style={{ color: "hsl(45 100% 30%)", flexShrink: 0, marginTop: 2 }} />
          <div>
            <p className="text-xs font-semibold" style={{ color: "hsl(45 100% 30%)" }}>
              {alertes.length} mouvement(s) temporaire(s) à surveiller
            </p>
            {alertes.map(a => (
              <p key={a.id} className="text-[11px] mt-1" style={{ color: "hsl(45 100% 25%)" }}>
                • {typeMap[a.code_type_mouvement]?.libelle || a.code_type_mouvement}
                {a.date_fin_prevue ? ` — fin prévue le ${new Date(a.date_fin_prevue).toLocaleDateString("fr-FR")}` : " — aucune date de fin prévue"}
                <Button size="sm" variant="ghost" className="ml-2 h-5 text-[10px]" onClick={() => cloturer(a.id)}>Clôturer</Button>
              </p>
            ))}
          </div>
        </div>
      )}

      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-sm flex items-center gap-2" style={{ color: "hsl(var(--foreground))" }}>
          <ArrowRightLeft size={15} style={{ color: "hsl(var(--accent))" }} />
          Mouvements internes
        </h3>
        {!adding && !editing && (
          <Button size="sm" variant="outline" onClick={startAdd}>
            <Plus size={13} className="mr-1" />Ajouter
          </Button>
        )}
      </div>

      {(adding || editing) && renderForm()}

      {loading ? (
        <p className="text-xs text-muted-foreground py-4 text-center">Chargement…</p>
      ) : rows.length === 0 && !adding ? (
        <p className="text-xs text-muted-foreground py-8 text-center">Aucun mouvement enregistré</p>
      ) : (
        <div className="space-y-2">
          {rows.map(row => (
            <div key={row.id} className="rounded-lg border p-3 flex items-start justify-between gap-3"
              style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-xs" style={{ color: "hsl(var(--foreground))" }}>
                    {typeMap[row.code_type_mouvement]?.libelle || row.code_type_mouvement}
                  </span>
                  {statutBadge(row.statut)}
                  {isTemporaire(row.code_type_mouvement) && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-medium" style={{ background: "hsl(280 65% 50% / 0.12)", color: "hsl(280 65% 40%)" }}>
                      Temporaire
                    </span>
                  )}
                  {typeMap[row.code_type_mouvement]?.est_definitif && (
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-medium" style={{ background: "hsl(210 70% 50% / 0.12)", color: "hsl(210 70% 35%)" }}>
                      Définitif
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-1 text-[11px]" style={{ color: "hsl(var(--muted-foreground))" }}>
                  <span>Date d'effet : <strong>{row.date_effet ? new Date(row.date_effet).toLocaleDateString("fr-FR") : "—"}</strong></span>
                  {row.date_fin_prevue && <span>Fin prévue : <strong>{new Date(row.date_fin_prevue).toLocaleDateString("fr-FR")}</strong></span>}
                  {row.date_fin_effective && <span>Fin effective : <strong>{new Date(row.date_fin_effective).toLocaleDateString("fr-FR")}</strong></span>}
                  {row.ancien_poste && <span>De : {(() => {
                    const parentCode = row.ancien_poste.includes("-") ? row.ancien_poste.split("-").slice(0, -1).join("-") : row.ancien_poste;
                    return posteLibelleMap[parentCode] || row.ancien_poste;
                  })()}</span>}
                  {row.nouveau_poste && <span>Vers : {(() => {
                    const parentCode = row.nouveau_poste.includes("-") ? row.nouveau_poste.split("-").slice(0, -1).join("-") : row.nouveau_poste;
                    return posteLibelleMap[parentCode] || row.nouveau_poste;
                  })()}</span>}
                  {row.ancienne_unite_id && <span>Anc. UO : {uoMap[row.ancienne_unite_id] || "—"}</span>}
                  {row.nouvelle_unite_id && <span>Nouv. UO : {uoMap[row.nouvelle_unite_id] || "—"}</span>}
                  {row.reference_decision && <span>Décision : {row.reference_decision}</span>}
                </div>
                {row.commentaire && <p className="text-[11px] mt-1 italic" style={{ color: "hsl(var(--muted-foreground) / 0.7)" }}>{row.commentaire}</p>}
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button size="icon" variant="ghost" className="h-7 w-7" title="Dupliquer" onClick={() => duplicate(row)}><Copy size={13} /></Button>
                <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setEditing(row.id); setForm(row); setAdding(false); }}><Pencil size={13} /></Button>
                {row.statut === "ACTIF" && isTemporaire(row.code_type_mouvement) && (
                  <Button size="icon" variant="ghost" className="h-7 w-7" title="Clôturer" onClick={() => cloturer(row.id)}>
                    <X size={13} />
                  </Button>
                )}
                <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => remove(row.id)}><Trash2 size={13} /></Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MouvementForm;
