/**
 * useFormatMasks – Hook centralisé pour les masques d'affichage (dates, nombres, devises, %).
 * Charge la config depuis parametres_rh (catégorie 'affichage') et expose des fonctions de formatage.
 */
import { useState, useEffect, useCallback, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";

// Map separator codes to actual characters
const SEP_MAP: Record<string, string> = { SPACE: " ", DOT: ".", COMMA: ",", NONE: "" };
const decodeSep = (v: string): string => SEP_MAP[v] ?? v;

interface FormatConfig {
  FORMAT_DATE: string;
  FORMAT_NOMBRE_DECIMALES: number;
  FORMAT_NOMBRE_SEPARATEUR_MILLIERS: string;
  FORMAT_NOMBRE_SEPARATEUR_DECIMAL: string;
  FORMAT_DEVISE_SYMBOLE: string;
  FORMAT_DEVISE_POSITION: "AVANT" | "APRES";
  FORMAT_POURCENTAGE_DECIMALES: number;
  FORMAT_MATRICULE: string;
}

const DEFAULTS: FormatConfig = {
  FORMAT_DATE: "DD/MM/YYYY",
  FORMAT_NOMBRE_DECIMALES: 2,
  FORMAT_NOMBRE_SEPARATEUR_MILLIERS: " ",
  FORMAT_NOMBRE_SEPARATEUR_DECIMAL: ",",
  FORMAT_DEVISE_SYMBOLE: "MAD",
  FORMAT_DEVISE_POSITION: "APRES",
  FORMAT_POURCENTAGE_DECIMALES: 2,
  FORMAT_MATRICULE: "######",
};

export const useFormatMasks = () => {
  const [config, setConfig] = useState<FormatConfig>(DEFAULTS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from("parametres_rh")
        .select("code, valeur")
        .eq("categorie", "affichage")
        .eq("actif", true);

      if (data) {
        const map: Record<string, string> = {};
        data.forEach((r: any) => { map[r.code] = r.valeur; });
        setConfig({
          FORMAT_DATE: map.FORMAT_DATE || DEFAULTS.FORMAT_DATE,
          FORMAT_NOMBRE_DECIMALES: parseInt(map.FORMAT_NOMBRE_DECIMALES) || DEFAULTS.FORMAT_NOMBRE_DECIMALES,
          FORMAT_NOMBRE_SEPARATEUR_MILLIERS: decodeSep(map.FORMAT_NOMBRE_SEPARATEUR_MILLIERS ?? "SPACE"),
          FORMAT_NOMBRE_SEPARATEUR_DECIMAL: map.FORMAT_NOMBRE_SEPARATEUR_DECIMAL || DEFAULTS.FORMAT_NOMBRE_SEPARATEUR_DECIMAL,
          FORMAT_DEVISE_SYMBOLE: map.FORMAT_DEVISE_SYMBOLE || DEFAULTS.FORMAT_DEVISE_SYMBOLE,
          FORMAT_DEVISE_POSITION: (map.FORMAT_DEVISE_POSITION as "AVANT" | "APRES") || DEFAULTS.FORMAT_DEVISE_POSITION,
          FORMAT_POURCENTAGE_DECIMALES: parseInt(map.FORMAT_POURCENTAGE_DECIMALES) || DEFAULTS.FORMAT_POURCENTAGE_DECIMALES,
          FORMAT_MATRICULE: map.FORMAT_MATRICULE || DEFAULTS.FORMAT_MATRICULE,
        });
      }
      setLoading(false);
    };
    load();
  }, []);

  const formatDate = useCallback((dateStr: string | null | undefined): string => {
    if (!dateStr) return "—";
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    const dd = String(d.getDate()).padStart(2, "0");
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const yyyy = String(d.getFullYear());
    return config.FORMAT_DATE
      .replace("DD", dd)
      .replace("MM", mm)
      .replace("YYYY", yyyy)
      .replace("YY", yyyy.slice(-2));
  }, [config.FORMAT_DATE]);

  const formatNumber = useCallback((val: number | null | undefined, decimals?: number): string => {
    if (val == null) return "—";
    const dec = decimals ?? config.FORMAT_NOMBRE_DECIMALES;
    const parts = Math.abs(val).toFixed(dec).split(".");
    const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, config.FORMAT_NOMBRE_SEPARATEUR_MILLIERS);
    const decPart = parts[1] ? config.FORMAT_NOMBRE_SEPARATEUR_DECIMAL + parts[1] : "";
    return (val < 0 ? "-" : "") + intPart + decPart;
  }, [config.FORMAT_NOMBRE_DECIMALES, config.FORMAT_NOMBRE_SEPARATEUR_MILLIERS, config.FORMAT_NOMBRE_SEPARATEUR_DECIMAL]);

  const formatCurrency = useCallback((val: number | null | undefined): string => {
    if (val == null) return "—";
    const num = formatNumber(val);
    return config.FORMAT_DEVISE_POSITION === "AVANT"
      ? `${config.FORMAT_DEVISE_SYMBOLE} ${num}`
      : `${num} ${config.FORMAT_DEVISE_SYMBOLE}`;
  }, [formatNumber, config.FORMAT_DEVISE_SYMBOLE, config.FORMAT_DEVISE_POSITION]);

  const formatPercent = useCallback((val: number | null | undefined): string => {
    if (val == null) return "—";
    return formatNumber(val, config.FORMAT_POURCENTAGE_DECIMALES) + " %";
  }, [formatNumber, config.FORMAT_POURCENTAGE_DECIMALES]);

  return { config, loading, formatDate, formatNumber, formatCurrency, formatPercent };
};
