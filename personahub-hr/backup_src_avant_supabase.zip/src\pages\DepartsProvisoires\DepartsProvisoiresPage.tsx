import React, { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Plus, Search, Clock, CheckCircle2, X, Eye, RefreshCw,
  PauseCircle, PlayCircle, RotateCcw, UserCheck, Calendar,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { differenceInDays, format, parseISO } from "date-fns";
import { fr } from "date-fns/locale";

// =====================================================
// RG-DEP-PROV-02 (Adil DAIA) :
//   Gestion des départs provisoires
// =====================================================

interface DepartProv {
  id: string;
  collaborateur_id: string;
  code_motif: string;
  date_debut: string;
  date_fin_prevue: string;
  date_fin_effective: string | null;
  reference_decision: string | null;
  date_decision: string | null;
  commentaire: string | null;
  numero_reconduction: number;
  depart_original_id: string | null;
  statut: string;
  created_at: string;
  collaborateur?: { nom: string; prenom: string; matricule: string; statut_collaborateur: string };
  motif?: { libelle: string; reconductible: boolean; nombre_reconductions_max: number | null; duree_max_periode_jours: number | null; duree_globale_max_jours: number | null; reste_dans_effectif: boolean };
}

interface Motif {
  code: string;
  libelle: string;
  reconductible: boolean;
  nombre_reconductions_max: number | null;
  duree_max_periode_jours: number | null;
  duree_globale_max_jours: number | null;
  reste_dans_effectif: boolean;
}

const STATUT_CFG: Record<string, { label: string; bg: string; color: string; icon: React.ReactNode }> = {
  ACTIF: { label: "En cours", bg: "hsl(45 100% 50% / 0.12)", color: "hsl(45 100% 30%)", icon: <PauseCircle size={12} /> },
  TERMINE: { label: "Terminé", bg: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))", icon: <Clock size={12} /> },
  RECONDUIT: { label: "Reconduit", bg: "hsl(200 70% 50% / 0.12)", color: "hsl(200 70% 30%)", icon: <RefreshCw size={12} /> },
  REINTEGRE: { label: "Réintégré", bg: "hsl(142 55% 45% / 0.12)", color: "hsl(142 55% 30%)", icon: <UserCheck size={12} /> },
  ANNULE: { label: "Annulé", bg: "hsl(0 70% 50% / 0.10)", color: "hsl(0 70% 40%)", icon: <X size={12} /> },
};

const Badge: React.FC<{ statut: string }> = ({ statut }) => {
  const c = STATUT_CFG[statut] ?? { label: statut, bg: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))", icon: null };
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium" style={{ background: c.bg, color: c.color }}>
      {c.icon}{c.label}
    </span>
  );
};

const DepartsProvisoiresPage: React.FC = () => {
  const { user, role } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterStatut, setFilterStatut] = useState("TOUS");
  const [showForm, setShowForm] = useState(false);

  // Form state
  const [formCollabSearch, setFormCollabSearch] = useState("");
  const [formCollabId, setFormCollabId] = useState("");
  const [formMotif, setFormMotif] = useState("");
  const [formDateDebut, setFormDateDebut] = useState("");
  const [formDateFinPrevue, setFormDateFinPrevue] = useState("");
  const [formRefDecision, setFormRefDecision] = useState("");
  const [formDateDecision, setFormDateDecision] = useState("");
  const [formCommentaire, setFormCommentaire] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Reconduction dialog
  const [reconductionTarget, setReconductionTarget] = useState<DepartProv | null>(null);
  const [reconDateFin, setReconDateFin] = useState("");
  const [reconRef, setReconRef] = useState("");

  // Réintégration dialog
  const [reintegrationTarget, setReintegrationTarget] = useState<DepartProv | null>(null);
  const [reintDateEffective, setReintDateEffective] = useState("");

  const { data: motifs = [] } = useQuery<Motif[]>({
    queryKey: ["ref_motif_depart_provisoire_actifs"],
    queryFn: async () => {
      const data = []; const error = null; // Supabase desactive
      return data || [];
    },
  });

  const { data: departs = [], isLoading } = useQuery<DepartProv[]>({
    queryKey: ["departs_provisoires", filterStatut],
    queryFn: async () => {
      let q = supabase
        .from("collaborateur_departs_provisoires" as never)
        .select(`*, collaborateur:collaborateurs(nom, prenom, matricule, statut_collaborateur), motif:ref_motif_depart_provisoire(libelle, reconductible, nombre_reconductions_max, duree_max_periode_jours, duree_globale_max_jours, reste_dans_effectif)`)
        .eq("archive", false)
        .order("date_debut", { ascending: false });
      if (filterStatut !== "TOUS") q = (q as any).eq("statut", filterStatut);
      const { data, error } = await (q as any);
      if (error) throw error;
      return data || [];
    },
  });

  // Collaborateurs search for form
  const { data: collabList = [] } = useQuery({
    queryKey: ["collabs-depart-prov", formCollabSearch],
    enabled: showForm || !!new URLSearchParams(window.location.search).get("collaborateur"),
    queryFn: async () => {
      let q = supabase
        .from("collaborateurs")
        .select("id, nom, prenom, matricule, statut_collaborateur")
        .in("statut_collaborateur", ["ACTIF"])
        .eq("archive", false)
        .order("nom").limit(20);
      if (formCollabSearch.trim()) {
        const words = formCollabSearch.trim().split(/\s+/);
        const conds = words.flatMap(w => [`nom.ilike.%${w}%`, `prenom.ilike.%${w}%`, `matricule.ilike.%${w}%`]).join(",");
        q = q.or(conds);
      }
      const { data } = await q;
      return data || [];
    },
  });

  const selectedCollab = collabList.find(c => c.id === formCollabId);

  // ── Pré-sélection collaborateur via URL (?collaborateur=UUID) ──
  const [urlParamHandled, setUrlParamHandled] = useState(false);
  useEffect(() => {
    if (urlParamHandled) return;
    const params = new URLSearchParams(window.location.search);
    const collabParam = params.get("collaborateur");
    if (collabParam && collabList.length > 0) {
      const found = collabList.find((c: any) => c.id === collabParam);
      if (found) {
        setFormCollabId(collabParam);
        setShowForm(true);
        setUrlParamHandled(true);
        window.history.replaceState({}, "", window.location.pathname);
      }
    }
  }, [collabList, urlParamHandled]);

  const resetForm = () => {
    setFormCollabSearch(""); setFormCollabId(""); setFormMotif("");
    setFormDateDebut(""); setFormDateFinPrevue(""); setFormRefDecision("");
    setFormDateDecision(""); setFormCommentaire("");
  };

  // Validation des contraintes de durée
  const validateDuration = (motifCode: string, collabId: string, dateDebut: string, dateFinPrevue: string): string | null => {
    const motif = motifs.find(m => m.code === motifCode);
    if (!motif) return null;
    const jours = differenceInDays(parseISO(dateFinPrevue), parseISO(dateDebut));
    if (motif.duree_max_periode_jours && jours > motif.duree_max_periode_jours) {
      return `La durée (${jours}j) dépasse la durée max par période (${motif.duree_max_periode_jours}j)`;
    }
    return null;
  };

  const handleSubmit = async () => {
    if (!formCollabId || !formMotif || !formDateDebut || !formDateFinPrevue) {
      toast({ title: "Veuillez remplir tous les champs obligatoires", variant: "destructive" });
      return;
    }
    const durationErr = validateDuration(formMotif, formCollabId, formDateDebut, formDateFinPrevue);
    if (durationErr) {
      toast({ title: "Contrainte de durée", description: durationErr, variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const { error } = await supabase
        .from("collaborateur_departs_provisoires" as never)
        .insert({
          collaborateur_id: formCollabId,
          code_motif: formMotif,
          date_debut: formDateDebut,
          date_fin_prevue: formDateFinPrevue,
          reference_decision: formRefDecision || null,
          date_decision: formDateDecision || null,
          commentaire: formCommentaire || null,
          created_by: user?.id,
          updated_by: user?.id,
        } as never) as any;
      if (error) throw error;

      // Suspendre le collaborateur (statut SUSPENDU)
      const motif = motifs.find(m => m.code === formMotif);
      await supabase.from("collaborateurs")
        .update({ statut_collaborateur: "SUSPENDU" })
        .eq("id", formCollabId);

      toast({ title: "Départ provisoire enregistré" });
      qc.invalidateQueries({ queryKey: ["departs_provisoires"] });
      setShowForm(false);
      resetForm();
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  // Reconduction
  const handleReconduction = async () => {
    if (!reconductionTarget || !reconDateFin) return;
    const dep = reconductionTarget;
    const motif = dep.motif as any;

    // Vérifier nombre max de reconductions
    if (motif?.nombre_reconductions_max && dep.numero_reconduction >= motif.nombre_reconductions_max) {
      toast({ title: "Limite atteinte", description: `Nombre maximum de reconductions (${motif.nombre_reconductions_max}) atteint`, variant: "destructive" });
      return;
    }

    // Vérifier durée globale
    if (motif?.duree_globale_max_jours) {
      const data = []; const error = null; // Supabase desactive
      const totalJours = (allDeps || []).reduce((acc: number, d: any) => {
        const fin = d.date_fin_effective || d.date_fin_prevue;
        return acc + differenceInDays(parseISO(fin), parseISO(d.date_debut));
      }, 0);
      const newJours = differenceInDays(parseISO(reconDateFin), parseISO(dep.date_fin_prevue));
      if (totalJours + newJours > motif.duree_globale_max_jours) {
        toast({ title: "Durée globale dépassée", description: `Total (${totalJours + newJours}j) dépasse la limite globale (${motif.duree_globale_max_jours}j)`, variant: "destructive" });
        return;
      }
    }

    setSubmitting(true);
    try {
      // Marquer l'ancien comme RECONDUIT
      await supabase
        .from("collaborateur_departs_provisoires" as never)
        .update({ statut: "RECONDUIT", date_fin_effective: dep.date_fin_prevue, updated_by: user?.id } as never)
        .eq("id", dep.id) as any;

      // Créer la reconduction
      const { error } = await supabase
        .from("collaborateur_departs_provisoires" as never)
        .insert({
          collaborateur_id: dep.collaborateur_id,
          code_motif: dep.code_motif,
          date_debut: dep.date_fin_prevue,
          date_fin_prevue: reconDateFin,
          reference_decision: reconRef || null,
          numero_reconduction: dep.numero_reconduction + 1,
          depart_original_id: dep.depart_original_id || dep.id,
          created_by: user?.id,
          updated_by: user?.id,
        } as never) as any;
      if (error) throw error;

      toast({ title: "Reconduction enregistrée", description: `Reconduction n°${dep.numero_reconduction + 1}` });
      qc.invalidateQueries({ queryKey: ["departs_provisoires"] });
      setReconductionTarget(null);
      setReconDateFin(""); setReconRef("");
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  // Réintégration
  const handleReintegration = async () => {
    if (!reintegrationTarget || !reintDateEffective) return;
    setSubmitting(true);
    try {
      await supabase
        .from("collaborateur_departs_provisoires" as never)
        .update({ statut: "REINTEGRE", date_fin_effective: reintDateEffective, updated_by: user?.id } as never)
        .eq("id", reintegrationTarget.id) as any;

      // Remettre le collaborateur en ACTIF
      await supabase.from("collaborateurs")
        .update({ statut_collaborateur: "ACTIF" })
        .eq("id", reintegrationTarget.collaborateur_id);

      toast({ title: "Réintégration effectuée", description: "Le collaborateur est de nouveau actif" });
      qc.invalidateQueries({ queryKey: ["departs_provisoires"] });
      setReintegrationTarget(null);
      setReintDateEffective("");
    } catch (err: any) {
      toast({ title: "Erreur", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = departs.filter(d => {
    const c = (d as any).collaborateur;
    const t = search.toLowerCase();
    return !search || c?.nom?.toLowerCase().includes(t) || c?.prenom?.toLowerCase().includes(t) || c?.matricule?.toLowerCase().includes(t);
  });

  const actifs = departs.filter(d => d.statut === "ACTIF").length;
  const reintegres = departs.filter(d => d.statut === "REINTEGRE").length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <PauseCircle size={20} style={{ color: "hsl(var(--accent))" }} />
            <h1 className="text-xl font-bold" style={{ color: "hsl(var(--foreground))" }}>
              Départs provisoires
            </h1>
          </div>
          <p className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>
            Détachements, mises en disponibilité, congés spécifiques
          </p>
        </div>
        <Button size="sm" onClick={() => { setShowForm(true); resetForm(); }}>
          <Plus size={15} className="mr-1" /> Nouveau départ provisoire
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-4">
        {[
          { label: "En cours", value: actifs, icon: <PauseCircle size={18} />, bg: "hsl(45 100% 50% / 0.10)", color: "hsl(45 100% 30%)" },
          { label: "Réintégrés", value: reintegres, icon: <UserCheck size={18} />, bg: "hsl(142 55% 45% / 0.10)", color: "hsl(142 55% 30%)" },
        ].map(k => (
          <div key={k.label} className="rounded-xl p-4 flex items-center gap-3"
            style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}>
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: k.bg, color: k.color }}>{k.icon}</div>
            <div>
              <p className="text-2xl font-bold" style={{ color: "hsl(var(--foreground))" }}>{k.value}</p>
              <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>{k.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filtres */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "hsl(var(--muted-foreground))" }} />
          <Input placeholder="Rechercher…" value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-sm" />
        </div>
        <div className="flex gap-1">
          {["TOUS", "ACTIF", "REINTEGRE", "RECONDUIT", "TERMINE", "ANNULE"].map(s => (
            <button key={s} onClick={() => setFilterStatut(s)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={{
                background: filterStatut === s ? "hsl(var(--accent))" : "hsl(var(--muted))",
                color: filterStatut === s ? "hsl(var(--accent-foreground))" : "hsl(var(--muted-foreground))",
              }}>
              {s === "TOUS" ? "Tous" : STATUT_CFG[s]?.label ?? s}
            </button>
          ))}
        </div>
      </div>

      {/* Tableau */}
      <div className="rounded-xl border overflow-hidden" style={{ borderColor: "hsl(var(--border))" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "hsl(var(--muted) / 0.5)", borderBottom: "1px solid hsl(var(--border))" }}>
              {["Collaborateur", "Motif", "Début", "Fin prévue", "Fin effective", "N° recon.", "Statut", ""].map(h => (
                <th key={h} className="text-left px-4 py-2.5 text-xs font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={8} className="py-12 text-center text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>Chargement…</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={8} className="py-12 text-center">
                <PauseCircle size={32} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm" style={{ color: "hsl(var(--muted-foreground))" }}>Aucun départ provisoire</p>
              </td></tr>
            ) : filtered.map((dep, i) => {
              const c = (dep as any).collaborateur;
              const m = (dep as any).motif;
              const isActive = dep.statut === "ACTIF";
              return (
                <tr key={dep.id} style={{
                  background: i % 2 === 0 ? "hsl(var(--card))" : "hsl(var(--muted) / 0.2)",
                  borderBottom: "1px solid hsl(var(--border) / 0.5)",
                }}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                        style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))" }}>
                        {c?.prenom?.[0]}{c?.nom?.[0]}
                      </div>
                      <div>
                        <p className="font-medium text-xs" style={{ color: "hsl(var(--foreground))" }}>{c?.prenom} {c?.nom}</p>
                        <p className="text-[11px]" style={{ color: "hsl(var(--muted-foreground))" }}>#{c?.matricule}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: "hsl(var(--foreground))" }}>{m?.libelle || dep.code_motif}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: "hsl(var(--foreground))" }}>{format(parseISO(dep.date_debut), "dd/MM/yyyy")}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: "hsl(var(--foreground))" }}>{format(parseISO(dep.date_fin_prevue), "dd/MM/yyyy")}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                    {dep.date_fin_effective ? format(parseISO(dep.date_fin_effective), "dd/MM/yyyy") : "—"}
                  </td>
                  <td className="px-4 py-3 text-xs text-center" style={{ color: "hsl(var(--foreground))" }}>
                    {dep.numero_reconduction > 0 ? dep.numero_reconduction : "—"}
                  </td>
                  <td className="px-4 py-3"><Badge statut={dep.statut} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => navigate(`/collaborateurs/${dep.collaborateur_id}`)}
                        className="p-1.5 rounded-lg hover:opacity-70" style={{ background: "hsl(var(--accent) / 0.1)", color: "hsl(var(--accent))" }} title="Voir fiche">
                        <Eye size={13} />
                      </button>
                      {isActive && m?.reconductible && (
                        <button onClick={() => { setReconductionTarget(dep); setReconDateFin(""); setReconRef(""); }}
                          className="p-1.5 rounded-lg hover:opacity-70" style={{ background: "hsl(200 70% 50% / 0.10)", color: "hsl(200 70% 35%)" }} title="Reconduire">
                          <RefreshCw size={13} />
                        </button>
                      )}
                      {isActive && (
                        <button onClick={() => { setReintegrationTarget(dep); setReintDateEffective(new Date().toISOString().split("T")[0]); }}
                          className="p-1.5 rounded-lg hover:opacity-70" style={{ background: "hsl(142 55% 45% / 0.10)", color: "hsl(142 55% 30%)" }} title="Réintégrer">
                          <UserCheck size={13} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Formulaire de création */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "hsl(var(--background) / 0.85)", backdropFilter: "blur(4px)" }}>
          <div className="w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden"
            style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}>
            <div className="flex items-center justify-between px-6 py-4 border-b"
              style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted) / 0.3)" }}>
              <h2 className="text-base font-bold" style={{ color: "hsl(var(--foreground))" }}>Nouveau départ provisoire</h2>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:opacity-70"
                style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}><X size={16} /></button>
            </div>
            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              {/* Collab search */}
              <div>
                <Label className="text-xs font-semibold mb-1.5 block">Collaborateur *</Label>
                <Input placeholder="Rechercher…" value={formCollabSearch} onChange={e => setFormCollabSearch(e.target.value)} className="mb-2 h-9 text-sm" />
                {selectedCollab ? (
                  <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))" }}>
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{ background: "hsl(var(--primary) / 0.1)", color: "hsl(var(--primary))" }}>
                      {selectedCollab.prenom?.[0]}{selectedCollab.nom?.[0]}
                    </div>
                    <span className="text-sm font-medium" style={{ color: "hsl(var(--foreground))" }}>{selectedCollab.prenom} {selectedCollab.nom}</span>
                    <span className="ml-auto text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>#{selectedCollab.matricule}</span>
                    <button onClick={() => setFormCollabId("")} className="ml-1"><X size={14} /></button>
                  </div>
                ) : (
                  <div className="max-h-32 overflow-y-auto rounded-lg border" style={{ borderColor: "hsl(var(--border))" }}>
                    {collabList.map(c => (
                      <button key={c.id} type="button"
                        onClick={() => { setFormCollabId(c.id); setFormCollabSearch(`${c.prenom} ${c.nom}`); }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-left text-sm hover:opacity-80 border-b last:border-0"
                        style={{ borderColor: "hsl(var(--border) / 0.4)", background: "hsl(var(--card))", color: "hsl(var(--foreground))" }}>
                        <span>{c.prenom} {c.nom}</span>
                        <span className="ml-auto text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>#{c.matricule}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {/* Motif */}
              <div>
                <Label className="text-xs font-semibold mb-1.5 block">Motif *</Label>
                <select value={formMotif} onChange={e => setFormMotif(e.target.value)}
                  className="w-full h-9 text-sm rounded-lg border px-3"
                  style={{ background: "hsl(var(--background))", borderColor: "hsl(var(--border))", color: "hsl(var(--foreground))" }}>
                  <option value="">— Sélectionner —</option>
                  {motifs.map(m => <option key={m.code} value={m.code}>{m.libelle}</option>)}
                </select>
              </div>
              {/* Dates */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs font-semibold mb-1.5 block">Date début *</Label>
                  <Input type="date" value={formDateDebut} onChange={e => setFormDateDebut(e.target.value)} className="h-9 text-sm" />
                </div>
                <div>
                  <Label className="text-xs font-semibold mb-1.5 block">Date fin prévue *</Label>
                  <Input type="date" value={formDateFinPrevue} onChange={e => setFormDateFinPrevue(e.target.value)} className="h-9 text-sm" />
                </div>
              </div>
              {/* Durée info */}
              {formDateDebut && formDateFinPrevue && formMotif && (() => {
                const motif = motifs.find(m => m.code === formMotif);
                const jours = differenceInDays(parseISO(formDateFinPrevue), parseISO(formDateDebut));
                return (
                  <div className="text-xs px-3 py-2 rounded-lg" style={{ background: "hsl(var(--muted) / 0.5)", color: "hsl(var(--muted-foreground))" }}>
                    Durée : <strong>{jours} jours</strong>
                    {motif?.duree_max_periode_jours && <> (max par période : {motif.duree_max_periode_jours}j)</>}
                    {motif?.reconductible && <> · Reconductible{motif.nombre_reconductions_max ? ` (${motif.nombre_reconductions_max} fois max)` : ""}</>}
                    {motif?.reste_dans_effectif ? " · Reste dans l'effectif" : " · Hors effectif"}
                  </div>
                );
              })()}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs font-semibold mb-1.5 block">Référence décision</Label>
                  <Input value={formRefDecision} onChange={e => setFormRefDecision(e.target.value)} className="h-9 text-sm" placeholder="DRH/2026/…" />
                </div>
                <div>
                  <Label className="text-xs font-semibold mb-1.5 block">Date décision</Label>
                  <Input type="date" value={formDateDecision} onChange={e => setFormDateDecision(e.target.value)} className="h-9 text-sm" />
                </div>
              </div>
              <div>
                <Label className="text-xs font-semibold mb-1.5 block">Commentaire</Label>
                <Textarea value={formCommentaire} onChange={e => setFormCommentaire(e.target.value)} rows={2} className="text-sm resize-none" />
              </div>
            </div>
            <div className="flex justify-end gap-2 px-6 py-4 border-t" style={{ borderColor: "hsl(var(--border))" }}>
              <Button variant="outline" onClick={() => setShowForm(false)} disabled={submitting}>Annuler</Button>
              <Button onClick={handleSubmit} disabled={submitting}>
                {submitting ? "Enregistrement…" : "Enregistrer"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal reconduction */}
      {reconductionTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "hsl(var(--background) / 0.85)", backdropFilter: "blur(4px)" }}>
          <div className="w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden"
            style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}>
            <div className="flex items-center justify-between px-6 py-4 border-b"
              style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted) / 0.3)" }}>
              <h2 className="text-base font-bold" style={{ color: "hsl(var(--foreground))" }}>Reconduction</h2>
              <button onClick={() => setReconductionTarget(null)} className="p-1.5 rounded-lg hover:opacity-70"
                style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}><X size={16} /></button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                Reconduction n°{reconductionTarget.numero_reconduction + 1} à partir du {format(parseISO(reconductionTarget.date_fin_prevue), "dd/MM/yyyy")}
              </p>
              <div>
                <Label className="text-xs font-semibold mb-1.5 block">Nouvelle date de fin *</Label>
                <Input type="date" value={reconDateFin} onChange={e => setReconDateFin(e.target.value)} className="h-9 text-sm" />
              </div>
              <div>
                <Label className="text-xs font-semibold mb-1.5 block">Référence décision</Label>
                <Input value={reconRef} onChange={e => setReconRef(e.target.value)} className="h-9 text-sm" />
              </div>
            </div>
            <div className="flex justify-end gap-2 px-6 py-4 border-t" style={{ borderColor: "hsl(var(--border))" }}>
              <Button variant="outline" onClick={() => setReconductionTarget(null)} disabled={submitting}>Annuler</Button>
              <Button onClick={handleReconduction} disabled={submitting || !reconDateFin}>
                {submitting ? "…" : "Reconduire"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Modal réintégration */}
      {reintegrationTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "hsl(var(--background) / 0.85)", backdropFilter: "blur(4px)" }}>
          <div className="w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden"
            style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))" }}>
            <div className="flex items-center justify-between px-6 py-4 border-b"
              style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted) / 0.3)" }}>
              <h2 className="text-base font-bold" style={{ color: "hsl(var(--foreground))" }}>Réintégration</h2>
              <button onClick={() => setReintegrationTarget(null)} className="p-1.5 rounded-lg hover:opacity-70"
                style={{ background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))" }}><X size={16} /></button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs" style={{ color: "hsl(var(--muted-foreground))" }}>
                Le collaborateur sera remis en statut ACTIF.
              </p>
              <div>
                <Label className="text-xs font-semibold mb-1.5 block">Date effective de réintégration *</Label>
                <Input type="date" value={reintDateEffective} onChange={e => setReintDateEffective(e.target.value)} className="h-9 text-sm" />
              </div>
            </div>
            <div className="flex justify-end gap-2 px-6 py-4 border-t" style={{ borderColor: "hsl(var(--border))" }}>
              <Button variant="outline" onClick={() => setReintegrationTarget(null)} disabled={submitting}>Annuler</Button>
              <Button onClick={handleReintegration} disabled={submitting || !reintDateEffective}
                style={{ background: "hsl(142 55% 40%)", color: "white" }}>
                {submitting ? "…" : "Réintégrer"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DepartsProvisoiresPage;
